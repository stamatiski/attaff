# SABRE 9018 HYB4.107 audio-safe Milan counters

HYB4.107 returns to the proven HYB4.104 audio and FIFO engine after HYB4.106
showed continuous presentation-time compensation resets on the second device.
The controller dump for 70:B3:D5:12:F2:20 showed a valid CRF connection and
accepted AAF frames, but AAF `MEDIA_LOCKED=0` and an impossible
`MEDIA_RESET=252385`.  The per-FIFO telemetry added in HYB4.105/4.106 was in
the timing-critical media-clock buffer-management loop.

This revision:

- preserves HYB4.104 deterministic listener re-arm, CRF isolation, AAF sample
  path, gPTP selection, dynamic mappings, and Milan advertisement;
- removes all added bookkeeping from the real-time FIFO loop;
- initializes every listener state/counter field before the first query;
- reports actual accepted `FRAMES_RX` values without synthetic advancement;
- retains the complete Milan-required STREAM_INPUT counter-valid set;
- reports CRF lock/unlock transitions from the isolated CRF estimator;
- reports AAF packet/media acquisition from listener-owned counters;
- does not modify or process audio samples.

The objective is to recover immediate bit-transparent audio while keeping the
controller-facing counter shape that fixed HYB4.105's Milan compatibility
regression.

## HYB4.104 base notes

This revision preserves HYB4.103's standards-clean live BMCA/gPTP reporting,
48 kHz listener-only CRF-to-DAC architecture, 32-valid-bit AAF declaration,
Milan AEM/MVU compatibility, dynamic mappings, and bit-transparent audio path.
It corrects the delayed listener/FIFO activation observed with HYB4.103.

HYB4.103 correctly received the Joyned 48 kHz / INT32 / 32-valid-bit AAF
format, matched the elected gPTP grandmaster, received CRF, and eventually
produced audio. The remaining long delay was caused by listener re-arming:
repeated CONNECT_RX for the same Stream ID could leave the sink POTENTIAL,
making the XMOS guarded setters reject updates and preventing the mandatory
DISABLED -> POTENTIAL transition which configures the router and media FIFOs.

Protocol-facing behavior:

- The local port participates in ordinary IEEE 802.1AS BMCA using the legacy
  stack's supported grandmaster-capable mode. It does not force the local
  clock to win and contains no external grandmaster identity. The better
  advertised clock is selected by the existing priority/quality comparison.
- ADP reads the elected grandmaster from the gPTP task and re-advertises when
  that live identity changes.
- GET_AVB_INFO and GET_AS_PATH read the same cached live gPTP state as ADP;
  the former success-without-data stubs are no longer used.
- Propagation delay is sampled from the gPTP task rather than being returned
  from an uninitialized output parameter.
- AAF is advertised and accepted as INT_32 with 32 valid bits at 48 kHz,
  matching the active Joyned talker and the AEM supported-format list. The
  internal XMOS/I2S path remains the proven lossless 24-significant-bit path;
  no DSP, gain, dither, truncation, or sample-rate conversion is introduced.
  96 kHz is not advertised.
- A successful CONNECT_RX configures the disabled sink in the proven XMOS
  order on every connection, including a repeated connection to the same
  Stream ID. It first commits DISABLED, then atomically publishes the live
  Stream ID, destination MAC, VLAN, format, channel map and POTENTIAL state.
  This guarantees the listener/router/FIFO task sees a real re-arm transition.
- GET_STREAM_INFO derives CONNECTED from the same authoritative AVB-manager
  sink reservation and state. It no longer depends only on file-static state
  shared across separate XMOS tasks.
- No grandmaster identity, Stream ID, multicast destination, VLAN assignment,
  or controller-specific state is hardcoded.
- AAF and CRF remain limited to 48 kHz. No talker capability is enabled.

This is a standards-aligned engineering candidate, not a claim of Avnu Milan
certification. Hardware/controller validation is required on the target SABRE
device.

Suggested validation order:

1. Cold-start the approved AVB switch, talkers, and SABRE with no connections.
2. Confirm the SABRE GM ID converges to the same BMCA-selected GM as the Joyned
   devices; it must not remain zero and must not select a fixed historical ID.
3. Connect CRF to `Input Stream CRF`; confirm MCR lock and increasing CRF RX.
4. Connect 48 kHz AAF to `Input Stream AAF`; confirm both channels start
   together within the normal AVB acquisition interval, without the former
   minute-long delayed/staggered start.
5. Verify GET_STREAM_INFO contains the connected talker's real Stream ID,
   destination MAC, VLAN, and connected/running flags for each input.
6. Confirm Hive matrix state and Milan compatibility remain stable after
   restarting Hive and Milan Manager.
