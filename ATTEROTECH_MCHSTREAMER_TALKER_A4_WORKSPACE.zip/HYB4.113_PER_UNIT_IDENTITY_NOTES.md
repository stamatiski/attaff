# SABRE 9018 2 Channel HYB4.113 — Per-unit AVDECC identity

## Purpose

HYB4.113 is a narrow control-plane correction based on the working HYB4.112
audio/CRF/Milan firmware.

Direct Nebra monitoring with two SABRE boards online showed both physical
entities being alternately disconnected and reconnected. Nebra reported the
duplicate key `MILAN.SABRE 9018 2 Channel`, and its exported system database
omitted both SABRE entities even while their audio status remained Ready.

## Change

The runtime AEM entity name now appends the last two MAC octets:

- MAC ending `36:E1` advertises `SABRE 9018 2 Channel [36:E1]`
- MAC ending `F2:20` advertises `SABRE 9018 2 Channel [F2:20]`

The suffix is deterministic and comes from the same immutable MAC address used
to form the entity ID. The serial number remains the board OTP serial.

## Explicitly unchanged

- AAF receive and sample path
- CRF receive and media-clock/DAC path
- FIFO acquisition and recovery
- I2S output and channel/sample mapping
- gPTP/BMCA selection
- ACMP connection state
- Milan profile/version and model identifier
- stream formats, VLAN, priority, gain and bit depth
- HYB4.112 unsolicited live-state reporting

## Test focus

Flash the same HYB4.113 image to both boards, power-cycle them, then reopen
Hive, Milan Manager and Nebra. Confirm that Nebra lists two uniquely named
SABRE entities without duplicate-name events or periodic reconnect cycles.

## Build verification

- Toolchain: XMOS xTIMEcomposer Community 14.4.1
- Clean compile/link: PASS
- Tile 0: 7/8 cores, 8/10 timers, 23/32 chanends, 43,644/65,536 bytes
- Tile 1: 6/8 cores, 7/10 timers, 22/32 chanends, 63,332/65,536 bytes
- Constraint checks: PASS
- Static timing analysis: PASS (the inherited XMOS unknown-path warnings remain)
- XE SHA-256: `C566C73757379A8571B98E69BAD25A72C59AB6DC1E02A493586A9A94B63EBF6F`

## Rollback

If audio, CRF, Milan discovery or routing differs from HYB4.112, immediately
restore `SABRE_9018_2_Channel_HYB4.112_UNSOLICITED_LIVE_STATE_20260719.xe`.
