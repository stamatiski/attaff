#include <xccompat.h>
#include <print.h>
#include "debug_print.h"
#include "avb.h"
#include "avb_conf.h"
#include "avb_1722_common.h"
#include "avb_control_types.h"
#include "avb_1722_1_common.h"
#include "avb_1722_1_protocol.h"
#include "avb_1722_1_acmp.h"
#include "avb_1722_1_adp.h"
#include "avb_1722_1_app_hooks.h"

/*** ADP ***/
void avb_entity_on_new_entity_available_default(client interface avb_interface avb, const_guid_ref_t my_guid, avb_1722_1_entity_record *entity, chanend c_tx)
{
  // Do nothing in the core stack
}

/*** ACMP ***/

/* The controller has indicated that a listener is connecting to this talker stream */
void avb_talker_on_listener_connect_default(client interface avb_interface avb, int source_num, const_guid_ref_t listener_guid, int connection_count)
{
#if AVB_NUM_SOURCES > 0
  unsigned stream_id[2];
  enum avb_source_state_t state;
  avb.get_source_state(source_num, state);
  avb.get_source_id(source_num, stream_id);

  debug_printf("CONNECTING Talker stream #%d (%x%x) -> Listener %x:%x:%x:%x:%x:%x:%x:%x\n", source_num, stream_id[0], stream_id[1],
                                                                                              listener_guid.c[7],
                                                                                              listener_guid.c[6],
                                                                                              listener_guid.c[5],
                                                                                              listener_guid.c[4],
                                                                                              listener_guid.c[3],
                                                                                              listener_guid.c[2],
                                                                                              listener_guid.c[1],
                                                                                              listener_guid.c[0]);

  /* A previous reservation attempt may have left a source POTENTIAL even
   * though there were no real listeners. On the first newly accepted listener,
   * force the normal DISABLED -> POTENTIAL transition so the AVB manager
   * re-registers MSRP and re-enables the talker FIFO/packetizer. */
  if (connection_count == 1 && state == AVB_SOURCE_STATE_POTENTIAL)
  {
    debug_printf("REARMING stale POTENTIAL Talker stream #%d\n", source_num);
    avb.set_source_state(source_num, AVB_SOURCE_STATE_DISABLED);
    state = AVB_SOURCE_STATE_DISABLED;
  }

  // If this is the first listener to connect to this talker stream, do the
  // normal stream registration first so MSRP/VLAN state is established.
  if (state == AVB_SOURCE_STATE_DISABLED)
  {
    avb_1722_1_talker_set_stream_id(source_num, stream_id);

    avb.set_source_state(source_num, AVB_SOURCE_STATE_POTENTIAL);
  }

#else
  __builtin_unreachable();
#endif
}

/* The controller has indicated that a listener has returned an error on connection attempt */
void avb_talker_on_listener_connect_failed_default(client interface avb_interface avb, const_guid_ref_t my_guid, int source_num,
        const_guid_ref_t listener_guid, avb_1722_1_acmp_status_t status, chanend c_tx)
{
}

/* The controller has indicated to connect this listener sink to a talker stream */
avb_1722_1_acmp_status_t avb_listener_on_talker_connect_default(client interface avb_interface avb,
                                                                int sink_num,
                                                                const_guid_ref_t talker_guid,
                                                                unsigned char dest_addr[6],
                                                                unsigned int stream_id[2],
                                                                unsigned short vlan_id,
                                                                const_guid_ref_t my_guid)
{
#if AVB_NUM_SINKS > 0
  const int channels_per_stream = (sink_num == 1) ? AVB_NUM_MEDIA_OUTPUTS : 0;
  int map[AVB_NUM_MEDIA_OUTPUTS];
  for (int i = 0; i < channels_per_stream; i++) map[i] = i;

  debug_printf("CONNECTING Listener sink #%d -> Talker stream %x%x, DA: %x:%x:%x:%x:%x:%x\n", sink_num, stream_id[0], stream_id[1],
                                                                                              dest_addr[0], dest_addr[1], dest_addr[2],
                                                                                              dest_addr[3], dest_addr[4], dest_addr[5]);

  /* HYB4.34: update listener stream and SRP reservation atomically so
   * GET_STREAM_INFO reports the real stream_id, dest_mac and VLAN exactly as
   * controllers/Hive expect after ACMP connect. The previous sequence used
   * several high-level setters that can silently refuse updates unless the
   * sink is already disabled, leaving GET_STREAM_INFO with zero reservation
   * fields despite a connected ACMP state.
   */
  avb_sink_info_t sink;
  sink = avb._get_sink_info(sink_num);
  sink.stream.state = AVB_SINK_STATE_DISABLED;
  avb._set_sink_info(sink_num, sink);

  sink = avb._get_sink_info(sink_num);
  sink.stream.sync = 0;
  sink.stream.num_channels = channels_per_stream;
  sink.stream.format = sink_num == 0 ? AVB_SOURCE_FORMAT_CRF : AVB_SOURCE_FORMAT_MBLA_24BIT;
  sink.stream.rate = 48000;
  memcpy(sink.map, map, channels_per_stream << 2);
  memcpy(sink.reservation.stream_id, stream_id, 8);
  memcpy(sink.reservation.dest_mac_addr, dest_addr, 6);
  sink.reservation.vlan_id = vlan_id;
  sink.stream.state = AVB_SINK_STATE_POTENTIAL;
  avb._set_sink_info(sink_num, sink);
  return ACMP_STATUS_SUCCESS;
#else
  __builtin_unreachable();
  return ACMP_STATUS_LISTENER_UNKNOWN_ID;
#endif
}

/* The controller has indicated to disconnect this listener sink from a talker stream */
void avb_listener_on_talker_disconnect_default(client interface avb_interface avb,
                                               int sink_num,
                                               const_guid_ref_t talker_guid,
                                               unsigned char dest_addr[6],
                                               unsigned int stream_id[2],
                                               const_guid_ref_t my_guid)
{
  debug_printf("DISCONNECTING Listener sink #%d -> Talker stream %x%x, DA: %x:%x:%x:%x:%x:%x\n", sink_num, stream_id[0], stream_id[1],
                                                                                              dest_addr[0], dest_addr[1], dest_addr[2],
                                                                                              dest_addr[3], dest_addr[4], dest_addr[5]);

  avb.set_sink_state(sink_num, AVB_SINK_STATE_DISABLED);
}

void avb_talker_on_listener_disconnect_default(client interface avb_interface avb,
                                               int source_num,
                                               const_guid_ref_t listener_guid,
                                               int connection_count)
{
  unsigned stream_id[2];
  enum avb_source_state_t state;
  avb.get_source_state(source_num, state);
  avb.get_source_id(source_num, stream_id);

  debug_printf("DISCONNECTING Talker stream #%d (%x%x) -> Listener %x:%x:%x:%x:%x:%x:%x:%x\n", source_num, stream_id[0], stream_id[1],
                                                                                              listener_guid.c[7],
                                                                                              listener_guid.c[6],
                                                                                              listener_guid.c[5],
                                                                                              listener_guid.c[4],
                                                                                              listener_guid.c[3],
                                                                                              listener_guid.c[2],
                                                                                              listener_guid.c[1],
                                                                                              listener_guid.c[0]);

  if (connection_count == 0)
  {
    if (state > AVB_SOURCE_STATE_DISABLED) {
      avb.set_source_state(source_num, AVB_SOURCE_STATE_DISABLED);
      avb.set_source_vlan(source_num, 0);
    }
  }
}
