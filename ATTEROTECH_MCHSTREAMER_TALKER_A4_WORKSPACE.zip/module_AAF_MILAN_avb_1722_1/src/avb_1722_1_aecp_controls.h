#ifndef __AVB_1722_1_AECP_CONTROLS_H__
#define __AVB_1722_1_AECP_CONTROLS_H__

#include "avb_1722_1_aecp_pdu.h"
#include "xc2compat.h"
#include "avb_api.h"
#include "avb_1722_1_callbacks.h"

/* Runtime bridge between the successful ACMP CONNECT_RX transaction and AEM
 * GET_STREAM_INFO. The legacy task split does not reliably publish the sink
 * reservation to the AECP task, so retain only the values supplied by the
 * actual talker. No topology-, vendor-, stream-, or switch-specific value is
 * introduced here. */
void avb_1722_1_listener_stream_info_cache_set(unsigned stream_index,
                                                unsigned stream_id[2],
                                                unsigned char dest_mac[6],
                                                unsigned short vlan_id,
                                                unsigned short acmp_flags);
void avb_1722_1_listener_stream_info_cache_clear(unsigned stream_index);

unsafe unsigned short process_aem_cmd_getset_control(avb_1722_1_aecp_packet_t *unsafe pkt,
                                                     REFERENCE_PARAM(unsigned char, status),
                                                     unsigned short command_type,
                                                     CLIENT_INTERFACE(avb_1722_1_control_callbacks, i_1722_1_entity));

unsafe void process_aem_cmd_getset_stream_info(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          REFERENCE_PARAM(unsigned char, status),
                                          unsigned short command_type,
                                          CLIENT_INTERFACE(avb_interface, i_avb));

unsafe void process_aem_cmd_getset_stream_format(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          REFERENCE_PARAM(unsigned char, status),
                                          unsigned short command_type,
                                          CLIENT_INTERFACE(avb_interface, i_avb));

unsafe void process_aem_cmd_getset_sampling_rate(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          REFERENCE_PARAM(unsigned char, status),
                                          unsigned short command_type,
                                          CLIENT_INTERFACE(avb_interface, i_avb));

unsafe void process_aem_cmd_getset_clock_source(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         REFERENCE_PARAM(unsigned char, status),
                                         unsigned short command_type,
                                         CLIENT_INTERFACE(avb_interface, i_avb));

unsafe void process_aem_cmd_startstop_streaming(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         REFERENCE_PARAM(unsigned char, status),
                                         unsigned short command_type,
                                         CLIENT_INTERFACE(avb_interface, i_avb));

unsafe void process_aem_cmd_get_counters(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         REFERENCE_PARAM(unsigned char, status),
                                         CLIENT_INTERFACE(avb_interface, i_avb));

#endif
