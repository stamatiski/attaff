#include "avb_1722_1_aecp_controls.h"
#include "avb.h"
#include "avb_api.h"
#include "avb_1722_1_common.h"
#include "avb_1722_1_aecp.h"
#include "misc_timer.h"
#include "avb_srp_pdu.h"
#include <string.h>
#include <print.h>
#include "debug_print.h"
#include "xccompat.h"
#include "avb_1722_1.h"
#include "avb_1722_1_acmp.h"

extern avb_1722_1_acmp_listener_stream_info acmp_listener_streams[AVB_1722_1_MAX_LISTENERS];

typedef struct listener_stream_info_cache_t {
  unsigned valid;
  unsigned stream_id[2];
  unsigned char dest_mac[6];
  unsigned short vlan_id;
  unsigned short acmp_flags;
} listener_stream_info_cache_t;

static listener_stream_info_cache_t listener_stream_info_cache[AVB_1722_1_MAX_LISTENERS];

void avb_1722_1_listener_stream_info_cache_set(unsigned stream_index,
                                                unsigned stream_id[2],
                                                unsigned char dest_mac[6],
                                                unsigned short vlan_id,
                                                unsigned short acmp_flags)
{
  if (stream_index < AVB_1722_1_MAX_LISTENERS) {
    listener_stream_info_cache[stream_index].stream_id[0] = stream_id[0];
    listener_stream_info_cache[stream_index].stream_id[1] = stream_id[1];
    memcpy(listener_stream_info_cache[stream_index].dest_mac, dest_mac, 6);
    listener_stream_info_cache[stream_index].vlan_id = vlan_id;
    listener_stream_info_cache[stream_index].acmp_flags = acmp_flags;
    listener_stream_info_cache[stream_index].valid =
        (stream_id[0] != 0) || (stream_id[1] != 0);
  }
}

void avb_1722_1_listener_stream_info_cache_clear(unsigned stream_index)
{
  if (stream_index < AVB_1722_1_MAX_LISTENERS)
    memset(&listener_stream_info_cache[stream_index], 0,
           sizeof(listener_stream_info_cache_t));
}

#if AVB_1722_1_AEM_ENABLED
#include "aem_descriptor_types.h"
#endif

unsafe unsigned short process_aem_cmd_getset_control(avb_1722_1_aecp_packet_t *unsafe pkt,
                                                     unsigned char &status,
                                                     unsigned short command_type,
                                                     client interface avb_1722_1_control_callbacks i_1722_1_entity)
{
  avb_1722_1_aem_getset_control_t *cmd = (avb_1722_1_aem_getset_control_t *)(pkt->data.aem.command.payload);
  unsigned short control_index = ntoh_16(cmd->descriptor_id);
  unsigned short control_type = ntoh_16(cmd->descriptor_type);
  unsigned char *values = pkt->data.aem.command.payload + sizeof(avb_1722_1_aem_getset_control_t);
  unsigned short values_length = GET_1722_1_DATALENGTH(&(pkt->header)) - sizeof(avb_1722_1_aem_getset_control_t) - AVB_1722_1_AECP_COMMAND_DATA_OFFSET;

  if (control_type != AEM_CONTROL_TYPE)
  {
    status = AECP_AEM_STATUS_BAD_ARGUMENTS;
    return values_length;
  }

  if (command_type == AECP_AEM_CMD_GET_CONTROL)
  {
    status = i_1722_1_entity.get_control_value(control_index, values_length, values);
  }
  else // AECP_AEM_CMD_SET_CONTROL
  {
    status = i_1722_1_entity.set_control_value(control_index, values_length, values);
  }
  return values_length;
}

static void stream_format_bytes(unsigned char bytes[8], enum avb_stream_format_t stream_format,
                                 int rate, int channels)
{
  (void)rate;
  if (stream_format == AVB_SOURCE_FORMAT_CRF)
  {
    const unsigned char crf48[8] = {0x04, 0x10, 0x60, 0x01, 0x00, 0x00, 0xbb, 0x80};
    memcpy(bytes, crf48, 8);
    return;
  }
  unsigned packed = (channels << 22) | (6 << 12);
  bytes[0] = 0x02;
  bytes[1] = 0x05;
  bytes[2] = 0x02;
  /* The Joyned/Milan network stream is AAF INT_32 with 32 valid bits.
   * The XMOS audio engine still transports the 24 significant PCM bits
   * losslessly to I2S; network valid-bit metadata must match the talker. */
  bytes[3] = 32;
  hton_32(&bytes[4], packed);
}

unsafe void process_aem_cmd_getset_stream_format(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          unsigned char &status,
                                          unsigned short command_type,
                                          client interface avb_interface avb)
{
  avb_1722_1_aem_getset_stream_format_t *cmd =
    (avb_1722_1_aem_getset_stream_format_t *)(pkt->data.aem.command.payload);
  unsigned short stream_index = ntoh_16(cmd->descriptor_id);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);
  enum avb_stream_format_t format;
  int rate, channels;

  if (desc_type == AEM_STREAM_INPUT_TYPE && stream_index < AVB_NUM_SINKS)
  {
    avb.get_sink_format(stream_index, format, rate);
    avb.get_sink_channels(stream_index, channels);
  }
  else if (desc_type == AEM_STREAM_OUTPUT_TYPE && stream_index < AVB_NUM_SOURCES)
  {
    avb.get_source_format(stream_index, format, rate);
    avb.get_source_channels(stream_index, channels);
  }
  else
  {
    status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return;
  }

  if (command_type == AECP_AEM_CMD_GET_STREAM_FORMAT)
  {
    stream_format_bytes(cmd->stream_format, format, rate, channels);
    return;
  }

  if (cmd->stream_format[0] == 0x04)
  {
    int requested_rate = 48000;
    unsigned char expected[8];
    stream_format_bytes(expected, AVB_SOURCE_FORMAT_CRF, requested_rate, 0);
    int valid = (format == AVB_SOURCE_FORMAT_CRF && requested_rate == 48000 &&
                 memcmp(expected, cmd->stream_format, 8) == 0);
    if (valid && desc_type == AEM_STREAM_INPUT_TYPE)
      valid = avb.set_sink_format(stream_index, AVB_SOURCE_FORMAT_CRF, requested_rate);
    else if (valid)
      valid = avb.set_source_format(stream_index, AVB_SOURCE_FORMAT_CRF, requested_rate);
    if (!valid) status = AECP_AEM_STATUS_NOT_SUPPORTED;
    return;
  }

  unsigned packed = ntoh_32(&cmd->stream_format[4]);
  int requested_channels = (packed >> 22) & 0x3ff;
  int requested_samples = (packed >> 12) & 0x3ff;
  int requested_rate = 48000;
  int valid = cmd->stream_format[0] == 0x02 &&
              cmd->stream_format[2] == 0x02 &&
              cmd->stream_format[3] == 32 &&
              cmd->stream_format[1] == 0x05 &&
              requested_channels == channels &&
              requested_samples == 6;

  if (!valid)
  {
    status = AECP_AEM_STATUS_NOT_SUPPORTED;
    return;
  }

  if (desc_type == AEM_STREAM_INPUT_TYPE)
    valid = avb.set_sink_format(stream_index, AVB_SOURCE_FORMAT_MBLA_24BIT, requested_rate);
  else
    valid = avb.set_source_format(stream_index, AVB_SOURCE_FORMAT_MBLA_24BIT, requested_rate);

  if (!valid)
    status = AECP_AEM_STATUS_STREAM_IS_RUNNING;
}

unsafe void process_aem_cmd_getset_stream_info(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          REFERENCE_PARAM(unsigned char, status),
                                          unsigned short command_type,
                                          CLIENT_INTERFACE(avb_interface, i_avb))
{
  avb_1722_1_aem_getset_stream_info_t *cmd = (avb_1722_1_aem_getset_stream_info_t *)(pkt->data.aem.command.payload);
  unsigned short stream_index = ntoh_16(cmd->descriptor_id);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);

  avb_srp_info_t *unsafe reservation;
  avb_stream_info_t *unsafe stream;
  avb_sink_info_t sink;
  avb_source_info_t source;

  if ((desc_type == AEM_STREAM_INPUT_TYPE) && (stream_index < AVB_NUM_SINKS))
  {
    sink = i_avb._get_sink_info(stream_index);
    reservation = &sink.reservation;
    stream = &sink.stream;
  }
  else if ((desc_type == AEM_STREAM_OUTPUT_TYPE) && (stream_index < AVB_NUM_SOURCES))
  {
    source = i_avb._get_source_info(stream_index);
    reservation = &source.reservation;
    stream = &source.stream;
  }
  else
  {
    status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return;
  }

  if (command_type == AECP_AEM_CMD_GET_STREAM_INFO)
  {
    unsigned int stream_id_hi = reservation->stream_id[0];
    unsigned int stream_id_lo = reservation->stream_id[1];
    unsigned char stream_dest_mac[6];
    unsigned short stream_vlan_id = reservation->vlan_id;
    unsigned short connected_acmp_flags = 0;
    int connected = 0;

    memcpy(stream_dest_mac, reservation->dest_mac_addr, 6);

    /* HYB4.104: the AVB manager's sink reservation is the authoritative live
     * state written by the ACMP application hook.  ACMP and AECP execute in
     * separate XMOS tasks, so file-static cache variables are not a reliable
     * cross-task transport.  Treat a non-disabled listener with a complete
     * reservation as connected.  Disconnect always commits DISABLED first,
     * preventing stale reservation data from being advertised as connected. */
    if ((desc_type == AEM_STREAM_INPUT_TYPE) &&
        (stream->state != AVB_SINK_STATE_DISABLED) &&
        ((stream_id_hi != 0) || (stream_id_lo != 0)))
    {
      connected = 1;
    }

    /* HYB4.35: Hive's Milan routing dots appear to depend on GET_STREAM_INFO
     * returning the live connected stream_id and destination MAC for listener
     * endpoints. The AVB sink reservation cache can remain zero even while
     * ACMP is connected and audio/CRF frames are flowing. For listener inputs,
     * prefer the ACMP listener state, which is populated from CONNECT_RX.
     */
    if ((desc_type == AEM_STREAM_INPUT_TYPE) &&
        (stream_index < AVB_1722_1_MAX_LISTENERS) &&
        acmp_listener_streams[stream_index].connected &&
        acmp_listener_streams[stream_index].stream_id.l)
    {
      stream_id_hi = (unsigned int)(acmp_listener_streams[stream_index].stream_id.l >> 32);
      stream_id_lo = (unsigned int)(acmp_listener_streams[stream_index].stream_id.l);
      memcpy(stream_dest_mac, acmp_listener_streams[stream_index].destination_mac, 6);
      if (stream_vlan_id == 0)
        stream_vlan_id = AVB_DEFAULT_VLAN;
      connected = 1;
    }

    /* CONNECT_RX is authoritative. Prefer its runtime snapshot when the sink
     * reservation/ACMP view has not propagated into this AECP request. */
    if ((desc_type == AEM_STREAM_INPUT_TYPE) &&
        (stream_index < AVB_1722_1_MAX_LISTENERS) &&
        listener_stream_info_cache[stream_index].valid)
    {
      stream_id_hi = listener_stream_info_cache[stream_index].stream_id[0];
      stream_id_lo = listener_stream_info_cache[stream_index].stream_id[1];
      memcpy(stream_dest_mac,
             listener_stream_info_cache[stream_index].dest_mac, 6);
      stream_vlan_id = listener_stream_info_cache[stream_index].vlan_id;
      connected_acmp_flags = listener_stream_info_cache[stream_index].acmp_flags;
      connected = 1;
    }
    stream_format_bytes(cmd->stream_format, stream->format,
                        stream->rate, stream->num_channels);

    hton_32(&cmd->stream_id[0], stream_id_hi);
    hton_32(&cmd->stream_id[4], stream_id_lo);
    hton_32(cmd->msrp_accumulated_latency, reservation->accumulated_latency);
    memcpy(&cmd->msrp_failure_bridge_id, &reservation->failure_bridge_id, 8);
    cmd->msrp_failure_code = reservation->failure_code;

    memcpy(cmd->stream_dest_mac, stream_dest_mac, 6);
    hton_16(cmd->stream_vlan_id, stream_vlan_id);

    int mac_valid = 0;
    for (int i = 0; i < 6; i++)
      if (stream_dest_mac[i] != 0) mac_valid = 1;

    int flags = AECP_STREAM_INFO_FLAGS_STREAM_FORMAT_VALID;
    if ((stream_id_hi != 0) || (stream_id_lo != 0))
      flags |= AECP_STREAM_INFO_FLAGS_STREAM_ID_VALID;
    if (mac_valid)
      flags |= AECP_STREAM_INFO_FLAGS_STREAM_DESC_MAC_VALID;
    if (stream_vlan_id != 0)
      flags |= AECP_STREAM_INFO_FLAGS_STREAM_VLAN_ID_VALID;
    /* Milan 1.3 section 5.4.2.10 defines validity from registration of a
     * matching Talker Advertise/Talker Failed attribute, not from the numeric
     * latency being non-zero.  A valid Talker Advertise may carry zero
     * accumulated latency.  The TSpec is populated only from a real matching
     * MSRP attribute by the AVB manager. */
    int srp_registration_valid =
        (desc_type == AEM_STREAM_INPUT_TYPE) &&
        (reservation->tspec_max_frame_size != 0);
    if (srp_registration_valid)
      flags |= AECP_STREAM_INFO_FLAGS_MSRP_ACC_LAT_VALID;
    else if ((desc_type == AEM_STREAM_INPUT_TYPE) && connected)
      flags |= AECP_STREAM_INFO_FLAGS_NOT_REGISTERING_SRP;
    /* A non-zero MSRP failure code is the authoritative indication that the
     * matching live registration is a Talker Failed declaration.  Bridge-ID
     * bytes may survive a transient domain-boundary transition in older
     * state, so they must never assert MSRP_FAILURE_VALID by themselves. */
    if (reservation->failure_code != 0)
      flags |= AECP_STREAM_INFO_FLAGS_MSRP_FAILURE_VALID;
    if (connected)
      flags |= AECP_STREAM_INFO_FLAGS_CONNECTED;
    if (connected_acmp_flags & AVB_1722_1_ACMP_FLAGS_FAST_CONNECT)
      flags |= AECP_STREAM_INFO_FLAGS_FAST_CONNECT;
    if (connected_acmp_flags & AVB_1722_1_ACMP_FLAGS_SAVED_STATE)
      flags |= AECP_STREAM_INFO_FLAGS_SAVED_STATE;
    hton_32(cmd->flags, flags);

  }
  else
  {
    if (stream->state != AVB_SOURCE_STATE_DISABLED)
    {
      status = AECP_AEM_STATUS_STREAM_IS_RUNNING;
      return;
    }

    int flags = ntoh_32(cmd->flags);

    if (flags & AECP_STREAM_INFO_FLAGS_STREAM_VLAN_ID_VALID)
    {
      reservation->vlan_id = ntoh_16(cmd->stream_vlan_id);
    }

    if (desc_type == AEM_STREAM_INPUT_TYPE)
    {
      i_avb._set_sink_info(stream_index, sink);
    }
    else
    {
      i_avb._set_source_info(stream_index, source);
    }

  }
}

unsafe void process_aem_cmd_getset_sampling_rate(avb_1722_1_aecp_packet_t *unsafe pkt,
                                          unsigned char &status,
                                          unsigned short command_type,
                                          client interface avb_interface avb)
{
  avb_1722_1_aem_getset_sampling_rate_t *cmd = (avb_1722_1_aem_getset_sampling_rate_t *)(pkt->data.aem.command.payload);
  unsigned short media_clock_id = ntoh_16(cmd->descriptor_id);
  int rate;

  if (command_type == AECP_AEM_CMD_GET_SAMPLING_RATE)
  {
    if (avb.get_device_media_clock_rate(media_clock_id, rate))
    {
      hton_32(cmd->sampling_rate, rate);
      return;
    }
  }
  else // AECP_AEM_CMD_SET_SAMPLING_RATE
  {
    rate = ntoh_32(cmd->sampling_rate);

    if (avb.set_device_media_clock_rate(media_clock_id, rate))
    {
      debug_printf("SET SAMPLING RATE TO %d\n", rate);
      // Success
      return;
    }
  }

  status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
}

unsafe void process_aem_cmd_getset_clock_source(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         unsigned char &status,
                                         unsigned short command_type,
                                         client interface avb_interface avb)
{
  avb_1722_1_aem_getset_clock_source_t *cmd = (avb_1722_1_aem_getset_clock_source_t *)(pkt->data.aem.command.payload);
  unsigned short media_clock_id = ntoh_16(cmd->descriptor_id);
  /* The XMOS runtime enum is INPUT_STREAM=0, LOCAL=1.  The AEM graph uses
   * descriptor 0 for CRF input and descriptor 1 for the external I2S clock.
   * Keep the runtime untouched and translate only at the AEM boundary. */
  enum device_media_clock_type_t runtime_source;
  unsigned short descriptor_source;

  if (command_type == AECP_AEM_CMD_GET_CLOCK_SOURCE)
  {
    if (avb.get_device_media_clock_type(media_clock_id, runtime_source))
    {
      if (runtime_source == DEVICE_MEDIA_CLOCK_INPUT_STREAM_DERIVED)
        descriptor_source = 0;
      else if (runtime_source == DEVICE_MEDIA_CLOCK_LOCAL_CLOCK)
        descriptor_source = 1;
      else {
        status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
        return;
      }
      hton_16(cmd->clock_source_index, descriptor_source);
      return;
    }
  }
  else // AECP_AEM_CMD_SET_CLOCK_SOURCE
  {
    descriptor_source = ntoh_16(cmd->clock_source_index);

    if (descriptor_source == 0)
      runtime_source = DEVICE_MEDIA_CLOCK_INPUT_STREAM_DERIVED;
    else if (descriptor_source == 1)
      runtime_source = DEVICE_MEDIA_CLOCK_LOCAL_CLOCK;
    else {
      status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
      return;
    }

    if (avb.set_device_media_clock_type(media_clock_id, runtime_source))
    {
      // Success
      return;
    }
  }

  status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
}

unsafe void process_aem_cmd_startstop_streaming(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         unsigned char &status,
                                         unsigned short command_type,
                                         client interface avb_interface avb)
{
  avb_1722_1_aem_startstop_streaming_t *cmd = (avb_1722_1_aem_startstop_streaming_t *)(pkt->data.aem.command.payload);
  unsigned short stream_index = ntoh_16(cmd->descriptor_id);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);

  if (desc_type == AEM_STREAM_INPUT_TYPE)
  {
    enum avb_sink_state_t state;
    if (avb.get_sink_state(stream_index, state))
    {
      if (command_type == AECP_AEM_CMD_START_STREAMING)
      {
        avb.set_sink_state(stream_index, AVB_SINK_STATE_ENABLED);
      }
      else
      {
        if (state == AVB_SINK_STATE_ENABLED)
        {
          avb.set_sink_state(stream_index, AVB_SINK_STATE_POTENTIAL);
        }
      }
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;

  }
  else if ((desc_type == AEM_STREAM_OUTPUT_TYPE))
  {
    enum avb_source_state_t state;
    if (avb.get_source_state(stream_index, state))
    {
      if (command_type == AECP_AEM_CMD_START_STREAMING)
      {
        int source_started = 1;

        /* A source must never jump directly from DISABLED to ENABLED.
         * DISABLED -> POTENTIAL configures the packetizer, media FIFOs,
         * VLAN/MSRP state and media clock.  Only the subsequent
         * POTENTIAL -> ENABLED transition sends AVB1722_TALKER_GO and
         * increments the real STREAM_START counter. */
        if (state == AVB_SOURCE_STATE_DISABLED)
        {
          source_started = avb.set_source_state(stream_index,
                                                AVB_SOURCE_STATE_POTENTIAL);
          if (source_started)
            source_started = avb.get_source_state(stream_index, state) &&
                             (state == AVB_SOURCE_STATE_POTENTIAL);
        }

        if (source_started && state == AVB_SOURCE_STATE_POTENTIAL)
        {
          source_started = avb.set_source_state(stream_index,
                                                AVB_SOURCE_STATE_ENABLED);
          if (source_started)
            source_started = avb.get_source_state(stream_index, state) &&
                             (state == AVB_SOURCE_STATE_ENABLED);
        }

        if (!source_started || state != AVB_SOURCE_STATE_ENABLED)
          status = AECP_AEM_STATUS_ENTITY_MISBEHAVING;
      }
      else
      {
        if (state == AVB_SOURCE_STATE_ENABLED)
        {
          avb.set_source_state(stream_index, AVB_SOURCE_STATE_POTENTIAL);
        }
      }
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
}

unsafe void process_aem_cmd_get_counters(avb_1722_1_aecp_packet_t *unsafe pkt,
                                         unsigned char &status,
                                         client interface avb_interface avb)
{
  avb_1722_1_aem_get_counters_t *cmd = (avb_1722_1_aem_get_counters_t *)(pkt->data.aem.command.payload);
  unsigned short clock_domain_id = ntoh_16(cmd->descriptor_id);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);

  if (desc_type == AEM_CLOCK_DOMAIN_TYPE)
  {
    if (clock_domain_id < AVB_NUM_MEDIA_CLOCKS) {
      media_clock_info_t info = avb._get_media_clock_info(clock_domain_id);
      const int counters_valid = AECP_GET_COUNTERS_CLOCK_DOMAIN_LOCKED_VALID |
                                 AECP_GET_COUNTERS_CLOCK_DOMAIN_UNLOCKED_VALID;
      hton_32(cmd->counters_valid, counters_valid);
      memset(&cmd->counters_block, 0, sizeof(cmd->counters_block));
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_CLOCK_DOMAIN_LOCKED_OFFSET],
              info.lock_counter);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_CLOCK_DOMAIN_UNLOCKED_OFFSET],
              info.unlock_counter);
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
  else if (desc_type == AEM_STREAM_INPUT_TYPE)
  {
    if (clock_domain_id < AVB_NUM_SINKS) {
      avb_1722_listener_counters_t counters = avb._get_sink_counters(clock_domain_id);
      if (clock_domain_id == 0) {
        /* CRF Input 0 is governed by the isolated CRF estimator.  Report its
         * real transition counters without adding work to the FIFO timing
         * loop. */
        media_clock_info_t info = avb._get_media_clock_info(0);
        counters.media_locked = info.lock_counter;
        counters.media_unlocked = info.unlock_counter;
        counters.media_reset = 0;
      }

      /* Milan 1.2 section 7.3.8.10 requires this complete counter set to be
       * declared for every STREAM_INPUT descriptor.  The traffic and event
       * counters below remain sourced from the listener/CRF state; the
       * early/late timestamp detectors are not implemented and therefore
       * correctly remain zero in the cleared response block. */
      const int counters_valid =
          AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_LOCKED_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_UNLOCKED_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_STREAM_INTERRUPTED_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_SEQ_NUM_MISMATCH_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_RESET_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_UNCERTAIN_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_UNSUPPORTED_FORMAT_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_LATE_TIMESTAMP_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_EARLY_TIMESTAMP_VALID |
          AECP_GET_COUNTERS_STREAM_INPUT_FRAMES_RX_VALID;
      hton_32(cmd->counters_valid, counters_valid);
      memset(&cmd->counters_block, 0, sizeof(cmd->counters_block));
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_LOCKED_OFFSET],
              counters.media_locked);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_UNLOCKED_OFFSET],
              counters.media_unlocked);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_STREAM_INTERRUPTED_OFFSET],
              counters.stream_interrupted);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_SEQ_NUM_MISMATCH_OFFSET],
              counters.seq_num_mismatch);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_RESET_OFFSET],
              counters.media_reset);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_UNCERTAIN_OFFSET],
              counters.timestamp_uncertain);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_UNSUPPORTED_FORMAT_OFFSET],
              counters.unsupported_format);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_INPUT_FRAMES_RX_OFFSET], counters.frames_rx);
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
  else if (desc_type == AEM_STREAM_OUTPUT_TYPE)
  {
    if (clock_domain_id < AVB_NUM_SOURCES) {
      avb_1722_talker_counters_t counters = avb._get_source_counters(clock_domain_id);
      const int counters_valid = AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_START_VALID |
                                 AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_STOP_VALID |
                                 AECP_GET_COUNTERS_STREAM_OUTPUT_MEDIA_RESET_VALID |
                                 AECP_GET_COUNTERS_STREAM_OUTPUT_TIMESTAMP_UNCERTAIN_VALID |
                                 AECP_GET_COUNTERS_STREAM_OUTPUT_FRAMES_TX_VALID;
      hton_32(cmd->counters_valid, counters_valid);
      memset(&cmd->counters_block, 0, sizeof(cmd->counters_block));
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_START_OFFSET],
              counters.stream_start);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_STOP_OFFSET],
              counters.stream_stop);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_OUTPUT_MEDIA_RESET_OFFSET],
              counters.media_reset);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_OUTPUT_TIMESTAMP_UNCERTAIN_OFFSET],
              counters.timestamp_uncertain);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_STREAM_OUTPUT_FRAMES_TX_OFFSET],
              counters.frames_tx);
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
  else if (desc_type == AEM_AVB_INTERFACE_TYPE)
  {
    if (clock_domain_id == 0) {
      /* Milan requires these three AVB_INTERFACE event counters.  LinkUp is
       * true when this response is being served; the legacy MAC API has no
       * historical link/GM transition feed, so the two since-boot event
       * counts remain zero rather than inventing packet statistics. */
      const int counters_valid = AECP_GET_COUNTERS_AVB_INTERFACE_LINK_UP_VALID |
                                 AECP_GET_COUNTERS_AVB_INTERFACE_LINK_DOWN_VALID |
                                 AECP_GET_COUNTERS_AVB_INTERFACE_GPTP_GM_CHANGED_VALID;
      hton_32(cmd->counters_valid, counters_valid);
      memset(&cmd->counters_block, 0, sizeof(cmd->counters_block));
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_AVB_INTERFACE_LINK_UP_OFFSET], 1);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_AVB_INTERFACE_LINK_DOWN_OFFSET], 0);
      hton_32(&cmd->counters_block[AECP_GET_COUNTERS_AVB_INTERFACE_GPTP_GM_CHANGED_OFFSET], 0);
    }
    else status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
  else status = AECP_AEM_STATUS_NOT_SUPPORTED;
}


