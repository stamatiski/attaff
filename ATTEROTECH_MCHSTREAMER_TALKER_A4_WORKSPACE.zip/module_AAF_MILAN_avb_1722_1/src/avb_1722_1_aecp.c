#include "avb.h"
#include "avb_1722_1_common.h"
#include "avb_1722_1_aecp.h"
#include "misc_timer.h"
#include "avb_srp_pdu.h"
#include <string.h>
#include <print.h>
#include "debug_print.h"
#include "xccompat.h"
#include "avb_1722_1.h"
#include "avb_1722_1_aecp_controls.h"
#include "avb_1722_1_adp.h"
#include "reboot.h"
#include <xs1.h>
#include <platform.h>
#include "avb_util.h"

#if AVB_1722_1_USE_AVC
#include "avc_commands.h"
#endif
#if AVB_1722_1_AEM_ENABLED
#include "aem_descriptor_types.h"
#include "aem_descriptors.h"
#include "aem_descriptor_structs.h"
#endif

extern unsigned int avb_1722_1_buf[AVB_1722_1_PACKET_SIZE_WORDS];
extern guid_t my_guid;
extern unsigned char my_mac_addr[6];

static avb_timer aecp_aem_lock_timer;

static enum {
  AEM_ENTITY_NOT_ACQUIRED,
  AEM_ENTITY_ACQUIRED,
  AEM_ENTITY_ACQUIRED_AND_PERSISTENT,
  AEM_ENTITY_ACQUIRED_BUT_PENDING = 0x80000001
} entity_acquired_status = AEM_ENTITY_NOT_ACQUIRED;

static enum {
  AECP_AEM_CONTROLLER_AVAILABLE_IN_A=0,
  AECP_AEM_CONTROLLER_AVAILABLE_IN_B,
  AECP_AEM_CONTROLLER_AVAILABLE_IN_C,
  AECP_AEM_CONTROLLER_AVAILABLE_IN_D,
  AECP_AEM_CONTROLLER_AVAILABLE_IN_E,
  AECP_AEM_CONTROLLER_AVAILABLE_IN_F,
  AECP_AEM_CONTROLLER_AVAILABLE_IDLE
} aecp_aem_controller_available_state = AECP_AEM_CONTROLLER_AVAILABLE_IDLE;

static avb_timer aecp_aem_controller_available_timer;
static avb_timer aecp_aem_stream_info_timer;
static avb_timer aecp_aem_counters_timer;
static guid_t pending_controller_guid;
static guid_t acquired_controller_guid;
static unsigned char acquired_controller_mac[6];
static unsigned char pending_controller_mac[6];
static unsigned short pending_controller_sequence;
static unsigned char pending_persistent;
static unsigned short aecp_controller_available_sequence = -1;

/* Milan 1.3 5.4.2.21 and 5.4.5 require the endpoint to remember every
 * controller which successfully registered for unsolicited AEM messages.
 * This product has one AVB interface, so the ingress MAC address is also the
 * correct egress destination/port for every registered controller. */
#define AECP_MAX_UNSOLICITED_CONTROLLERS 10
#define AECP_UNSOLICITED_IDLE_PROBE_SECONDS 600
#define AECP_UNSOLICITED_PROBE_MAX_ATTEMPTS 3
typedef struct aecp_unsolicited_controller_t {
  unsigned valid;
  unsigned char mac[6];
  unsigned char guid[8];
  unsigned short next_sequence_id;
  unsigned short idle_seconds;
} aecp_unsolicited_controller_t;

static aecp_unsolicited_controller_t
    aecp_unsolicited_controllers[AECP_MAX_UNSOLICITED_CONTROLLERS];
static avb_timer aecp_unsolicited_maintenance_timer;
static int aecp_unsolicited_probe_index = -1;
static unsigned short aecp_unsolicited_probe_sequence;
static unsigned char aecp_unsolicited_probe_attempts;
static unsigned char aecp_unsolicited_force_probe_remaining;
static unsigned char aecp_unsolicited_force_probe_cursor;
static unsigned char aecp_unsolicited_probe_forced;

/* The serialized payload is the comparison key.  This deliberately compares
 * exactly what a controller will receive rather than maintaining a second,
 * potentially divergent model of the listener state. */
static unsigned char aecp_stream_info_snapshot[AVB_NUM_SINKS][68];
static unsigned char aecp_stream_info_snapshot_valid[AVB_NUM_SINKS];
static unsigned char
    aecp_stream_counter_snapshot[AVB_NUM_SINKS][sizeof(avb_1722_1_aem_get_counters_t)];
static unsigned char aecp_stream_counter_snapshot_valid[AVB_NUM_SINKS];
static avb_1722_1_aecp_packet_t aecp_unsolicited_packet;

/* IEEE 1722.1 GET_NAME/SET_NAME addresses the same 64-byte object names that
 * READ_DESCRIPTOR exposes.  Some descriptors are synthesized by this legacy
 * XMOS stack, so retain their mutable names separately and use this single
 * backing store for READ_DESCRIPTOR, GET_NAME and SET_NAME. */
#if AEM_GENERATE_DESCRIPTORS_ON_FLY
#if (AVB_NUM_SINKS > 0)
static unsigned char aecp_stream_input_names[AVB_NUM_SINKS][64];
#endif
#if (AVB_NUM_SOURCES > 0)
static unsigned char aecp_stream_output_names[AVB_NUM_SOURCES][64];
#endif
#if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
static unsigned char
    aecp_audio_cluster_names[AVB_NUM_MEDIA_OUTPUTS + AVB_NUM_MEDIA_INPUTS][64];
#endif
#endif


static enum {
    AECP_AEM_IDLE,
    AECP_AEM_WAITING,
    AECP_AEM_CONTROLLER_AVAILABLE_TIMEOUT,
    AECP_AEM_LOCK_TIMEOUT
} aecp_aem_state = AECP_AEM_IDLE;

// Called on startup to initialise certain static descriptor fields
void avb_1722_1_aem_descriptors_init(unsigned int serial_num)
{
  static const char hex_digits[] = "0123456789ABCDEF";

  // entity_guid in Entity Descriptor
  for (int i=0; i < 8; i++)
  {
    desc_entity[4+i] = my_guid.c[7-i];
  }

  avb_itoa((int)serial_num,(char *)&desc_entity[244], 10, 0);

  /* HYB4.113: give every physical unit a stable, unique AEM entity name.
   *
   * Nebra keys its module/network record by group_name + entity_name.  Two
   * SABRE boards previously advertised the identical key
   * "MILAN.SABRE 9018 2 Channel", so their otherwise-distinct entity IDs
   * alternated under one record and both were periodically reported offline.
   * Keep the requested product name and append a short suffix derived from
   * the unit's immutable MAC address (for example " [36:E1]").
   *
   * Model name, group, entity ID, stream formats and every media-path setting
   * remain unchanged.
   */
  {
    int name_len = 0;
    while ((name_len < 64) && (desc_entity[48 + name_len] != 0)) {
      name_len++;
    }

    if (name_len <= 55) {
      desc_entity[48 + name_len++] = ' ';
      desc_entity[48 + name_len++] = '[';
      desc_entity[48 + name_len++] = hex_digits[(my_mac_addr[4] >> 4) & 0x0f];
      desc_entity[48 + name_len++] = hex_digits[my_mac_addr[4] & 0x0f];
      desc_entity[48 + name_len++] = ':';
      desc_entity[48 + name_len++] = hex_digits[(my_mac_addr[5] >> 4) & 0x0f];
      desc_entity[48 + name_len++] = hex_digits[my_mac_addr[5] & 0x0f];
      desc_entity[48 + name_len++] = ']';
      desc_entity[48 + name_len] = 0;
    }
  }

  /* HYB4.114: initialize the names of descriptors generated on demand.
   * Keeping them in writable storage makes SET_NAME observable through both
   * subsequent GET_NAME and READ_DESCRIPTOR responses. */
#if AEM_GENERATE_DESCRIPTORS_ON_FLY
#if (AVB_NUM_SINKS > 0)
  for (int i = 0; i < AVB_NUM_SINKS; i++) {
    memset(aecp_stream_input_names[i], 0, 64);
    if (i == 0)
      strcpy((char *)aecp_stream_input_names[i], "Input Stream CRF");
    else
      strcpy((char *)aecp_stream_input_names[i], "Input Stream AAF");
  }
#endif
#if (AVB_NUM_SOURCES > 0)
  for (int i = 0; i < AVB_NUM_SOURCES; i++) {
    memset(aecp_stream_output_names[i], 0, 64);
    strcpy((char *)aecp_stream_output_names[i], "Output Stream AAF");
  }
#endif
#if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
  for (int i = 0; i < (AVB_NUM_MEDIA_OUTPUTS + AVB_NUM_MEDIA_INPUTS); i++) {
    memset(aecp_audio_cluster_names[i], 0, 64);
    strcpy((char *)aecp_audio_cluster_names[i], "Channel 1");
    aecp_audio_cluster_names[i][8] = '1' + i;
  }
#endif
#endif

  for (int i=0; i < 6; i++)
  {
    // mac_address in AVB Interface Descriptor
    desc_avb_interface_0[70+i] = my_mac_addr[i];
    // HYB4.33: stream-input clock source identifier intentionally remains zero (Joyned-like).
  }

  // TODO: Should be stored centrally, possibly query PTP for ID per interface
  desc_avb_interface_0[78+0] = my_mac_addr[0];
  desc_avb_interface_0[78+1] = my_mac_addr[1];
  desc_avb_interface_0[78+2] = my_mac_addr[2];
  desc_avb_interface_0[78+3] = 0xff;
  desc_avb_interface_0[78+4] = 0xfe;
  desc_avb_interface_0[78+5] = my_mac_addr[3];
  desc_avb_interface_0[78+6] = my_mac_addr[4];
  desc_avb_interface_0[78+7] = my_mac_addr[5];
  desc_avb_interface_0[78+8] = 0;
  desc_avb_interface_0[78+9] = 1;
}

void avb_1722_1_aecp_aem_init(unsigned int serial_num)
{
  avb_1722_1_aem_descriptors_init(serial_num);
  init_avb_timer(&aecp_aem_lock_timer, 100);
  init_avb_timer(&aecp_aem_controller_available_timer, 5);
  init_avb_timer(&aecp_aem_stream_info_timer, 1);
  init_avb_timer(&aecp_aem_counters_timer, 1);
  init_avb_timer(&aecp_unsolicited_maintenance_timer, 1);
  start_avb_timer(&aecp_aem_stream_info_timer, 10); /* 100 ms */
  start_avb_timer(&aecp_aem_counters_timer, 100);   /* 1 s */
  start_avb_timer(&aecp_unsolicited_maintenance_timer, 100); /* 1 s */

  memset(aecp_unsolicited_controllers, 0,
         sizeof(aecp_unsolicited_controllers));
  memset(aecp_stream_info_snapshot_valid, 0,
         sizeof(aecp_stream_info_snapshot_valid));
  memset(aecp_stream_counter_snapshot_valid, 0,
         sizeof(aecp_stream_counter_snapshot_valid));
  aecp_unsolicited_probe_index = -1;
  aecp_unsolicited_probe_sequence = 0;
  aecp_unsolicited_probe_attempts = 0;
  aecp_unsolicited_force_probe_remaining = 0;
  aecp_unsolicited_force_probe_cursor = 0;
  aecp_unsolicited_probe_forced = 0;

  aecp_aem_state = AECP_AEM_WAITING;
}

static unsigned char *avb_1722_1_create_aecp_response_header(unsigned char dest_addr[6], char status, int message_type, unsigned int data_len, avb_1722_1_aecp_packet_t* cmd_pkt)
{
  struct ethernet_hdr_t *hdr = (ethernet_hdr_t*) &avb_1722_1_buf[0];
  avb_1722_1_aecp_packet_t *pkt = (avb_1722_1_aecp_packet_t*) (hdr + AVB_1722_1_PACKET_BODY_POINTER_OFFSET);

  avb_1722_1_create_1722_1_header(dest_addr, DEFAULT_1722_1_AECP_SUBTYPE, message_type+1, status, data_len, hdr);

  // Copy the target guid, controller guid and sequence ID into the response header
  memcpy(pkt->target_guid, cmd_pkt->target_guid, (pkt->data.payload - pkt->target_guid));

  return pkt->data.payload;
}

/* data_len: number of bytes of command_specific_data (9.2.1.2 Figure 9.2)
*/
static void avb_1722_1_create_aecp_aem_response(unsigned char src_addr[6], unsigned char status, unsigned int command_data_len, avb_1722_1_aecp_packet_t* cmd_pkt)
{
  /* 9.2.1.1.7: "control_data_length field for AECP is the number of octets following the target_guid,
  but is limited to a maximum of 524"

  control_data_length = payload_specific_data + sequence_id + controller_guid
  payload_specific_data (for AEM) = command_specific_data + command_type + u

  = command_specific_data + 2 + 2 + 8
  */
  avb_1722_1_aecp_aem_msg_t *aem = (avb_1722_1_aecp_aem_msg_t*)avb_1722_1_create_aecp_response_header(src_addr, status, AECP_CMD_AEM_COMMAND, command_data_len+12, cmd_pkt);

  /* Copy payload_specific_data into the response */
  memcpy(aem, cmd_pkt->data.payload, command_data_len + 2);
}

static int aecp_find_unsolicited_controller(const unsigned char controller_guid[8])
{
  for (int i = 0; i < AECP_MAX_UNSOLICITED_CONTROLLERS; i++) {
    if (aecp_unsolicited_controllers[i].valid &&
        memcmp(aecp_unsolicited_controllers[i].guid, controller_guid, 8) == 0)
      return i;
  }
  return -1;
}

static void aecp_finish_unsolicited_probe(void)
{
  if (aecp_unsolicited_probe_forced &&
      aecp_unsolicited_force_probe_remaining > 0)
    aecp_unsolicited_force_probe_remaining--;
  aecp_unsolicited_probe_index = -1;
  aecp_unsolicited_probe_attempts = 0;
  aecp_unsolicited_probe_forced = 0;
}

static void aecp_touch_unsolicited_controller(const unsigned char controller_guid[8],
                                               const unsigned char src_addr[6])
{
  int index = aecp_find_unsolicited_controller(controller_guid);
  if (index < 0)
    return;

  memcpy(aecp_unsolicited_controllers[index].mac, src_addr, 6);
  aecp_unsolicited_controllers[index].idle_seconds = 0;
  if (index == aecp_unsolicited_probe_index) {
    aecp_finish_unsolicited_probe();
  }
}

static int aecp_register_unsolicited_controller(const unsigned char controller_guid[8],
                                                 const unsigned char src_addr[6])
{
  int index = aecp_find_unsolicited_controller(controller_guid);
  if (index < 0) {
    for (int i = 0; i < AECP_MAX_UNSOLICITED_CONTROLLERS; i++) {
      if (!aecp_unsolicited_controllers[i].valid) {
        index = i;
        memset(&aecp_unsolicited_controllers[i], 0,
               sizeof(aecp_unsolicited_controller_t));
        aecp_unsolicited_controllers[i].valid = 1;
        memcpy(aecp_unsolicited_controllers[i].guid, controller_guid, 8);
        /* Milan 1.3 5.4.2.21: a new registration starts at sequence zero. */
        aecp_unsolicited_controllers[i].next_sequence_id = 0;
        aecp_unsolicited_controllers[i].idle_seconds = 0;
        break;
      }
    }
  }

  if (index >= 0) {
    memcpy(aecp_unsolicited_controllers[index].mac, src_addr, 6);
    aecp_unsolicited_controllers[index].idle_seconds = 0;
  }
  else {
    /* Do not evict an unverified controller. Ask every occupied slot to prove
     * liveness, then let the registering controller retry normally. */
    aecp_unsolicited_force_probe_remaining =
        AECP_MAX_UNSOLICITED_CONTROLLERS;
    aecp_unsolicited_force_probe_cursor = 0;
  }
  return index;
}

static void aecp_deregister_unsolicited_controller(const unsigned char controller_guid[8])
{
  int index = aecp_find_unsolicited_controller(controller_guid);
  if (index >= 0) {
    if (index == aecp_unsolicited_probe_index)
      aecp_finish_unsolicited_probe();
    memset(&aecp_unsolicited_controllers[index], 0,
           sizeof(aecp_unsolicited_controller_t));
  }
}

void avb_1722_1_aecp_forget_unsolicited_controller(unsigned char controller_guid[8])
{
  aecp_deregister_unsolicited_controller(controller_guid);
}

static void aecp_send_unsolicited_controller_probe(int index, chanend c_tx)
{
  struct ethernet_hdr_t *hdr = (ethernet_hdr_t *)&avb_1722_1_buf[0];
  avb_1722_1_aecp_packet_t *pkt =
      (avb_1722_1_aecp_packet_t *)(hdr + AVB_1722_1_PACKET_BODY_POINTER_OFFSET);
  avb_1722_1_aecp_aem_msg_t *aem_msg = &pkt->data.aem;
  aecp_unsolicited_controller_t *controller =
      &aecp_unsolicited_controllers[index];

  avb_1722_1_create_1722_1_header(controller->mac,
      DEFAULT_1722_1_AECP_SUBTYPE, AECP_CMD_AEM_COMMAND,
      AECP_AEM_STATUS_SUCCESS, AVB_1722_1_AECP_COMMAND_DATA_OFFSET, hdr);
  memcpy(pkt->target_guid, controller->guid, 8);
  set_64(pkt->controller_guid, my_guid.c);
  hton_16(pkt->sequence_id, aecp_unsolicited_probe_sequence);
  AEM_MSG_SET_COMMAND_TYPE(aem_msg, AECP_AEM_CMD_CONTROLLER_AVAILABLE);
  AEM_MSG_SET_U_FLAG(aem_msg, 0);

  int num_tx_bytes = AVB_1722_1_AECP_PAYLOAD_OFFSET +
                     sizeof(ethernet_hdr_t);
  if (num_tx_bytes < 64) num_tx_bytes = 64;
  mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);
  aecp_unsolicited_probe_attempts++;
}

static int aecp_select_unsolicited_probe_candidate(void)
{
  if (aecp_unsolicited_force_probe_remaining > 0) {
    for (int n = 0; n < AECP_MAX_UNSOLICITED_CONTROLLERS; n++) {
      int index = (aecp_unsolicited_force_probe_cursor + n) %
                  AECP_MAX_UNSOLICITED_CONTROLLERS;
      if (aecp_unsolicited_controllers[index].valid) {
        aecp_unsolicited_force_probe_cursor =
            (index + 1) % AECP_MAX_UNSOLICITED_CONTROLLERS;
        return index;
      }
    }
    aecp_unsolicited_force_probe_remaining = 0;
    return -1;
  }

  int candidate = -1;
  unsigned oldest = AECP_UNSOLICITED_IDLE_PROBE_SECONDS - 1;
  for (int i = 0; i < AECP_MAX_UNSOLICITED_CONTROLLERS; i++) {
    if (aecp_unsolicited_controllers[i].valid &&
        aecp_unsolicited_controllers[i].idle_seconds > oldest) {
      candidate = i;
      oldest = aecp_unsolicited_controllers[i].idle_seconds;
    }
  }
  return candidate;
}

static void aecp_unsolicited_controller_maintenance(chanend c_tx)
{
  if (!avb_timer_expired(&aecp_unsolicited_maintenance_timer))
    return;

  for (int i = 0; i < AECP_MAX_UNSOLICITED_CONTROLLERS; i++) {
    if (aecp_unsolicited_controllers[i].valid &&
        aecp_unsolicited_controllers[i].idle_seconds < 0xffff)
      aecp_unsolicited_controllers[i].idle_seconds++;
  }

  if (aecp_unsolicited_probe_index >= 0) {
    int index = aecp_unsolicited_probe_index;
    if (!aecp_unsolicited_controllers[index].valid) {
      aecp_finish_unsolicited_probe();
    }
    else if (aecp_unsolicited_probe_attempts <
             AECP_UNSOLICITED_PROBE_MAX_ATTEMPTS) {
      aecp_send_unsolicited_controller_probe(index, c_tx);
    }
    else {
      memset(&aecp_unsolicited_controllers[index], 0,
             sizeof(aecp_unsolicited_controller_t));
      aecp_finish_unsolicited_probe();
    }
  }
  else {
    int index = aecp_select_unsolicited_probe_candidate();
    if (index >= 0) {
      aecp_unsolicited_probe_index = index;
      aecp_unsolicited_probe_sequence++;
      aecp_unsolicited_probe_attempts = 0;
      aecp_unsolicited_probe_forced =
          (aecp_unsolicited_force_probe_remaining > 0);
      aecp_send_unsolicited_controller_probe(index, c_tx);
    }
  }

  start_avb_timer(&aecp_unsolicited_maintenance_timer, 100);
}

static void aecp_send_empty_aem_response(unsigned char dest_addr[6],
                                         unsigned char status,
                                         avb_1722_1_aecp_packet_t *cmd_pkt,
                                         chanend c_tx)
{
  avb_1722_1_create_aecp_aem_response(dest_addr, status, 0, cmd_pkt);
  int num_tx_bytes = 2 + AVB_1722_1_AECP_PAYLOAD_OFFSET +
                     sizeof(ethernet_hdr_t);
  if (num_tx_bytes < 64) num_tx_bytes = 64;
  mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);
}

static void aecp_complete_milan_stream_info_extension(avb_1722_1_aecp_packet_t *pkt)
{
  avb_1722_1_aem_getset_stream_info_t *cmd =
      (avb_1722_1_aem_getset_stream_info_t *)pkt->data.aem.command.payload;
  unsigned char *stream_info_ext =
      ((unsigned char *)pkt->data.aem.command.payload) +
      sizeof(avb_1722_1_aem_getset_stream_info_t);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);
  unsigned int flags = ntoh_32(cmd->flags);

  memset(stream_info_ext, 0,
         68 - sizeof(avb_1722_1_aem_getset_stream_info_t));

  if ((desc_type == AEM_STREAM_INPUT_TYPE) &&
      (flags & AECP_STREAM_INFO_FLAGS_CONNECTED)) {
    /* flags_ex REGISTERING is valid only with a live matching SRP
     * registration.  pbsta=3/acmpsta=SUCCESS reflects the settled listener
     * state already represented by the base GET_STREAM_INFO payload. */
    if ((flags & AECP_STREAM_INFO_FLAGS_MSRP_ACC_LAT_VALID) &&
        !(flags & AECP_STREAM_INFO_FLAGS_NOT_REGISTERING_SRP))
      hton_32(stream_info_ext, 0x00000001);
    stream_info_ext[4] = 0x60;
    stream_info_ext[5] = 0;
  }
}

static void aecp_prepare_unsolicited_header(avb_1722_1_aecp_packet_t *pkt,
                                            unsigned short command_type,
                                            unsigned short descriptor_type,
                                            unsigned short descriptor_index)
{
  memset(pkt, 0, sizeof(avb_1722_1_aecp_packet_t));
  AEM_MSG_SET_U_FLAG(&pkt->data.aem, 1);
  AEM_MSG_SET_COMMAND_TYPE(&pkt->data.aem, command_type);
  hton_16(&pkt->data.aem.command.payload[0], descriptor_type);
  hton_16(&pkt->data.aem.command.payload[2], descriptor_index);
}

static void aecp_send_unsolicited_payload(avb_1722_1_aecp_packet_t *pkt,
                                          unsigned int command_data_len,
                                          chanend c_tx)
{
  for (int i = 0; i < AECP_MAX_UNSOLICITED_CONTROLLERS; i++) {
    aecp_unsolicited_controller_t *controller =
        &aecp_unsolicited_controllers[i];
    if (!controller->valid)
      continue;

    for (int j = 0; j < 8; j++)
      pkt->target_guid[j] = my_guid.c[7-j];
    memcpy(pkt->controller_guid, controller->guid, 8);
    hton_16(pkt->sequence_id, controller->next_sequence_id);
    controller->next_sequence_id++;

    avb_1722_1_create_aecp_aem_response(controller->mac,
                                        AECP_AEM_STATUS_SUCCESS,
                                        command_data_len, pkt);
    int num_tx_bytes = command_data_len + 2 +
                       AVB_1722_1_AECP_PAYLOAD_OFFSET +
                       sizeof(ethernet_hdr_t);
    if (num_tx_bytes < 64) num_tx_bytes = 64;
    mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);
  }
}

static void configure_audio_or_crf_stream_descriptor(unsigned char *descriptor,
                                                       int crf)
{
  const unsigned char crf48[8] = {0x04,0x10,0x60,0x01,0x00,0x00,0xbb,0x80};
  /* Milan Base AAF at 48 kHz: INT_32 samples, 32 valid bits,
   * eight channels and six samples per packet.  Keep this runtime
   * descriptor overlay identical to the generated STREAM_OUTPUT
   * descriptor and GET_STREAM_FORMAT response. */
  const unsigned char aaf48_8ch_32bit[8] =
    {0x02,0x05,0x02,0x20,0x02,0x00,0x60,0x00};

  memcpy(&descriptor[74], crf ? crf48 : aaf48_8ch_32bit, 8);
  /* HYB4.45 la_avdecc/Milan profile alignment: only CRF is a dedicated
   * clock-sync source. AAF remains a class-A audio sink stream.
   */
  descriptor[72] = 0x00;
  descriptor[73] = 0x03;
  descriptor[84] = 0;
  descriptor[85] = 1;
  memset(&descriptor[132], 0, 80);
  if (crf) {
    memcpy(&descriptor[132], crf48, 8);
  }
  else {
    memcpy(&descriptor[132], aaf48_8ch_32bit, 8);
  }
}

static int create_aem_read_descriptor_response(unsigned int read_type, unsigned int read_id, unsigned char src_addr[6], avb_1722_1_aecp_packet_t *pkt)
{
  int desc_size_bytes = 0, i = 0;
  unsigned char *descriptor = NULL;
  int found_descriptor = 0;
#if (AVB_NUM_SINKS > 0)
  unsigned char stream_input_descriptor[sizeof(desc_stream_input_0)];
#endif

#if AEM_GENERATE_DESCRIPTORS_ON_FLY
  switch (read_type) {
  #if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
    case AEM_AUDIO_CLUSTER_TYPE:
      if (read_id < (AVB_NUM_MEDIA_OUTPUTS+AVB_NUM_MEDIA_INPUTS)) {
        descriptor = &desc_audio_cluster_template[0];
        desc_size_bytes = sizeof(aem_desc_audio_cluster_t);
      }
      break;
  #endif
#if (AVB_NUM_SINKS > 0)
    case AEM_STREAM_INPUT_TYPE:
      if (read_id < AVB_NUM_SINKS) {
        memcpy(stream_input_descriptor, &desc_stream_input_0[0], sizeof(stream_input_descriptor));
        descriptor = &stream_input_descriptor[0];
        /* HYB4.31: descriptor order is Input 0 = CRF, Input 1 = AAF.
         * Keep the static format list aligned with the visible stream name.
         */
        configure_audio_or_crf_stream_descriptor(descriptor, read_id == 0);
        desc_size_bytes = sizeof(desc_stream_input_0);
      }
      break;
  #if (AVB_NUM_MEDIA_OUTPUTS > 0) && (AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF)
    case AEM_STREAM_PORT_INPUT_TYPE:
      if (read_id == 0) {
        descriptor = &desc_stream_port_input_0[0];
        desc_size_bytes = sizeof(aem_desc_stream_port_input_output_t);
      }
      break;
  #endif
#endif
#if (AVB_NUM_SOURCES > 0)
    case AEM_STREAM_OUTPUT_TYPE:
      if (read_id < AVB_NUM_SOURCES) {
        descriptor = &desc_stream_output_0[0];
        configure_audio_or_crf_stream_descriptor(descriptor, read_id == 1);
        desc_size_bytes = sizeof(desc_stream_output_0);
      }
      break;
    case AEM_STREAM_PORT_OUTPUT_TYPE:
      if (read_id < AVB_NUM_SOURCES) {
        descriptor = &desc_stream_port_output_0[0];
        desc_size_bytes = sizeof(desc_stream_port_output_0);
      }
      break;
#endif
  }

  if (descriptor != NULL)
  {
    aem_desc_audio_cluster_t *cluster = (aem_desc_audio_cluster_t *)descriptor;
    // The descriptor id is also the channel number
    cluster->descriptor_index[1] = (uint8_t)read_id;

    if (read_type == AEM_AUDIO_CLUSTER_TYPE)
    {
      memcpy(cluster->object_name, aecp_audio_cluster_names[read_id], 64);
    }
#if (AVB_NUM_SOURCES > 0)
    else if (read_type == AEM_STREAM_OUTPUT_TYPE)
    {
      memcpy(cluster->object_name, aecp_stream_output_names[read_id], 64);
    }
#endif
#if (AVB_NUM_SINKS > 0)
    else if (read_type == AEM_STREAM_INPUT_TYPE)
    {
      memcpy(cluster->object_name, aecp_stream_input_names[read_id], 64);
    }
#endif

#if (AVB_NUM_SOURCES > 0)
    if (read_type == AEM_STREAM_PORT_OUTPUT_TYPE) {
      aem_desc_stream_port_input_output_t *stream_port = (aem_desc_stream_port_input_output_t *)descriptor;
      hton_16(stream_port->base_cluster, AVB_NUM_MEDIA_OUTPUTS + (read_id * AVB_NUM_MEDIA_INPUTS/AVB_NUM_SOURCES));
      hton_16(stream_port->base_map, read_id);
    }
#endif
#if (AVB_NUM_MEDIA_OUTPUTS > 0)
    if (read_type == AEM_STREAM_PORT_INPUT_TYPE) {
      aem_desc_stream_port_input_output_t *stream_port = (aem_desc_stream_port_input_output_t *)descriptor;
      hton_16(stream_port->base_cluster, read_id * AVB_NUM_MEDIA_OUTPUTS/AVB_NUM_SINKS);
      hton_16(stream_port->base_map, read_id);
    }
#endif
    found_descriptor = 1;
  }
#if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
  else if (read_type == AEM_AUDIO_MAP_TYPE)
  {
    /* Only AAF Input 0 owns an audio map.  CRF Input 1 carries timestamps
     * and must not divide or consume the eight audio channel mappings. */
    if (read_id == 0)
    {
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
      const int num_mappings = AVB_NUM_MEDIA_INPUTS;
#else
      const int num_mappings = AVB_NUM_MEDIA_OUTPUTS;
#endif

      /* Since the map descriptors aren't constant size, unlike the clusters, and
       * dependent on the number of channels, we don't use a template */

      struct ethernet_hdr_t *hdr = (ethernet_hdr_t*) &avb_1722_1_buf[0];
      avb_1722_1_aecp_packet_t *pkt = (avb_1722_1_aecp_packet_t*) (hdr + AVB_1722_1_PACKET_BODY_POINTER_OFFSET);
      avb_1722_1_aecp_aem_msg_t *aem = (avb_1722_1_aecp_aem_msg_t*)(pkt->data.payload);
      unsigned char *pktptr = (unsigned char *)&(aem->command.read_descriptor_resp.descriptor);
      aem_desc_audio_map_t *audio_map = (aem_desc_audio_map_t *)pktptr;

      desc_size_bytes = 8+(num_mappings*8);

      memset(audio_map, 0, desc_size_bytes);
      hton_16(audio_map->descriptor_type, AEM_AUDIO_MAP_TYPE);
      hton_16(audio_map->descriptor_index, read_id);
      hton_16(audio_map->mappings_offset, 8);
      hton_16(audio_map->number_of_mappings, num_mappings);

      for (int i=0; i < num_mappings; i++)
      {
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
        hton_16(audio_map->mappings[i].mapping_stream_index, 0);
#else
        hton_16(audio_map->mappings[i].mapping_stream_index, 1);
#endif
        hton_16(audio_map->mappings[i].mapping_stream_channel, i);
        hton_16(audio_map->mappings[i].mapping_cluster_offset, i);
        hton_16(audio_map->mappings[i].mapping_cluster_channel, 0); // Single channel audio clusters
      }

      found_descriptor = 2; // 2 signifies do not copy descriptor below
    }
  }
#endif
  else
#endif
  {
    /* Search for the descriptor */
    while (aem_descriptor_list[i] <= read_type)
    {
      int num_descriptors = aem_descriptor_list[i+1];

      if (aem_descriptor_list[i] == read_type)
      {
        for (int j=0, k=2; j < num_descriptors; j++, k += 2)
        {
          desc_size_bytes = aem_descriptor_list[i+k];
          descriptor = (unsigned char *)aem_descriptor_list[i+k+1];

          if (( ((unsigned)descriptor[2] << 8) | ((unsigned)descriptor[3]) ) == read_id)
          {
            found_descriptor = 1;
            break;
          }
        }

      }

      i += ((num_descriptors*2)+2);
      if (i >= (sizeof(aem_descriptor_list)>>2)) break;
    }
  }


  if (found_descriptor)
  {
    int packet_size = sizeof(ethernet_hdr_t)+sizeof(avb_1722_1_packet_header_t)+24+desc_size_bytes;

    avb_1722_1_aecp_aem_msg_t *aem = (avb_1722_1_aecp_aem_msg_t*)avb_1722_1_create_aecp_response_header(src_addr, AECP_AEM_STATUS_SUCCESS, AECP_CMD_AEM_COMMAND, desc_size_bytes+16, pkt);

    memcpy(aem, pkt->data.payload, 6);
    if (found_descriptor < 2) memcpy(&(aem->command.read_descriptor_resp.descriptor), descriptor, desc_size_bytes);

    return packet_size;
  }
  else // Descriptor not found, send NO_SUCH_DESCRIPTOR reply
  {
    int packet_size = sizeof(ethernet_hdr_t)+sizeof(avb_1722_1_packet_header_t)+20+sizeof(avb_1722_1_aem_read_descriptor_command_t);

    avb_1722_1_aecp_aem_msg_t *aem = (avb_1722_1_aecp_aem_msg_t*)avb_1722_1_create_aecp_response_header(src_addr, AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR, AECP_CMD_AEM_COMMAND, 40, pkt);

    memcpy(aem, pkt->data.payload, 20+sizeof(avb_1722_1_aem_read_descriptor_command_t));

    return packet_size;
  }
}

#define AECP_AEM_NAME_SIZE 64
#define AECP_AEM_NAME_RESPONSE_SIZE 72

/* Return the static descriptor backing store. Descriptors generated on demand
 * are handled separately by process_aem_cmd_getset_name(). */
static unsigned char *aecp_find_static_descriptor(unsigned short descriptor_type,
                                                   unsigned short descriptor_index)
{
  unsigned int i = 0;
  const unsigned int list_words = sizeof(aem_descriptor_list) >> 2;

  while ((i + 1) < list_words && aem_descriptor_list[i] <= descriptor_type) {
    unsigned int count = aem_descriptor_list[i + 1];

    if (aem_descriptor_list[i] == descriptor_type) {
      for (unsigned int descriptor = 0, k = 2;
           descriptor < count && (i + k + 1) < list_words;
           descriptor++, k += 2) {
        unsigned char *candidate =
            (unsigned char *)aem_descriptor_list[i + k + 1];
        unsigned int candidate_index =
            ((unsigned int)candidate[2] << 8) | candidate[3];
        if (candidate_index == descriptor_index)
          return candidate;
      }
    }

    i += 2 + (count * 2);
  }

  return 0;
}

static int aecp_descriptor_has_object_name(unsigned short descriptor_type)
{
  switch (descriptor_type) {
    case AEM_CONFIGURATION_TYPE:
    case AEM_AUDIO_UNIT_TYPE:
    case AEM_STREAM_INPUT_TYPE:
    case AEM_STREAM_OUTPUT_TYPE:
    case AEM_JACK_INPUT_TYPE:
    case AEM_JACK_OUTPUT_TYPE:
    case AEM_AVB_INTERFACE_TYPE:
    case AEM_CLOCK_SOURCE_TYPE:
    case AEM_MEMORY_OBJECT_TYPE:
    case AEM_AUDIO_CLUSTER_TYPE:
    case AEM_CONTROL_TYPE:
    case AEM_CLOCK_DOMAIN_TYPE:
      return 1;
    default:
      return 0;
  }
}

/* Resolve a name to the authoritative writable backing store. Entity names
 * use their two special indices; all ordinary object names use name_index 0.
 * The endpoint has one configuration, so configuration_index must be zero. */
static unsigned char *aecp_resolve_name(unsigned short descriptor_type,
                                        unsigned short descriptor_index,
                                        unsigned short name_index,
                                        unsigned short configuration_index,
                                        unsigned char *status)
{
  unsigned char *descriptor;

  if (configuration_index != 0) {
    *status = AECP_AEM_STATUS_BAD_ARGUMENTS;
    return 0;
  }

  if (descriptor_type == AEM_ENTITY_TYPE) {
    if (descriptor_index != 0) {
      *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
      return 0;
    }
    if (name_index == 0)
      return &desc_entity[48];
    if (name_index == 1)
      return &desc_entity[180];
    *status = AECP_AEM_STATUS_BAD_ARGUMENTS;
    return 0;
  }

  if (name_index != 0) {
    *status = AECP_AEM_STATUS_BAD_ARGUMENTS;
    return 0;
  }

#if AEM_GENERATE_DESCRIPTORS_ON_FLY
#if (AVB_NUM_SINKS > 0)
  if (descriptor_type == AEM_STREAM_INPUT_TYPE) {
    if (descriptor_index < AVB_NUM_SINKS)
      return aecp_stream_input_names[descriptor_index];
    *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return 0;
  }
#endif
#if (AVB_NUM_SOURCES > 0)
  if (descriptor_type == AEM_STREAM_OUTPUT_TYPE) {
    if (descriptor_index < AVB_NUM_SOURCES)
      return aecp_stream_output_names[descriptor_index];
    *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return 0;
  }
#endif
#if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
  if (descriptor_type == AEM_AUDIO_CLUSTER_TYPE) {
    if (descriptor_index < (AVB_NUM_MEDIA_OUTPUTS + AVB_NUM_MEDIA_INPUTS))
      return aecp_audio_cluster_names[descriptor_index];
    *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return 0;
  }
#endif
#endif

  if (!aecp_descriptor_has_object_name(descriptor_type)) {
    *status = AECP_AEM_STATUS_NOT_SUPPORTED;
    return 0;
  }

  descriptor = aecp_find_static_descriptor(descriptor_type, descriptor_index);
  if (descriptor == 0) {
    *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
    return 0;
  }

  return &descriptor[4];
}

static int process_aem_cmd_getset_name(avb_1722_1_aecp_packet_t *pkt,
                                       unsigned char *status,
                                       unsigned short command_type)
{
  unsigned char *payload = pkt->data.aem.command.payload;
  unsigned short descriptor_type = ntoh_16(&payload[0]);
  unsigned short descriptor_index = ntoh_16(&payload[2]);
  unsigned short name_index = ntoh_16(&payload[4]);
  unsigned short configuration_index = ntoh_16(&payload[6]);
  unsigned char *name = aecp_resolve_name(descriptor_type, descriptor_index,
                                          name_index, configuration_index,
                                          status);

  if (name == 0) {
    /* la_avdecc validates every implemented GET_NAME response, including
     * non-success responses, against the complete 72-byte response shape. */
    if (command_type == AECP_AEM_CMD_GET_NAME)
      memset(&payload[8], 0, AECP_AEM_NAME_SIZE);
    return AECP_AEM_NAME_RESPONSE_SIZE;
  }

  if (command_type == AECP_AEM_CMD_GET_NAME) {
    memcpy(&payload[8], name, AECP_AEM_NAME_SIZE);
  }
  else {
    if (entity_acquired_status != AEM_ENTITY_NOT_ACQUIRED &&
        !compare_guid(pkt->controller_guid, &acquired_controller_guid)) {
      *status = AECP_AEM_STATUS_ENTITY_ACQUIRED;
      return AECP_AEM_NAME_RESPONSE_SIZE;
    }
    memcpy(name, &payload[8], AECP_AEM_NAME_SIZE);
  }

  *status = AECP_AEM_STATUS_SUCCESS;
  return AECP_AEM_NAME_RESPONSE_SIZE;
}

static unsigned short avb_1722_1_create_controller_available_packet(void)
{
  struct ethernet_hdr_t *hdr = (ethernet_hdr_t*) &avb_1722_1_buf[0];
  avb_1722_1_aecp_packet_t *pkt = (avb_1722_1_aecp_packet_t*) (hdr + AVB_1722_1_PACKET_BODY_POINTER_OFFSET);
  avb_1722_1_aecp_aem_msg_t *aem_msg = &(pkt->data.aem);

  avb_1722_1_create_1722_1_header(acquired_controller_mac, DEFAULT_1722_1_AECP_SUBTYPE, AECP_CMD_AEM_COMMAND, AECP_AEM_STATUS_SUCCESS, AVB_1722_1_AECP_COMMAND_DATA_OFFSET, hdr);

  set_64(pkt->target_guid, acquired_controller_guid.c);
  set_64(pkt->controller_guid, my_guid.c);
  hton_16(pkt->sequence_id, aecp_controller_available_sequence);

  AEM_MSG_SET_COMMAND_TYPE(aem_msg, AECP_AEM_CMD_CONTROLLER_AVAILABLE);
  AEM_MSG_SET_U_FLAG(aem_msg, 0);

  return AVB_1722_1_AECP_PAYLOAD_OFFSET;
}

static unsigned short avb_1722_1_create_acquire_response_packet(unsigned char status)
{
  struct ethernet_hdr_t *hdr = (ethernet_hdr_t*) &avb_1722_1_buf[0];
  avb_1722_1_aecp_packet_t *pkt = (avb_1722_1_aecp_packet_t*) (hdr + AVB_1722_1_PACKET_BODY_POINTER_OFFSET);
  avb_1722_1_aecp_aem_msg_t *aem_msg = &(pkt->data.aem);

  aem_msg->command.acquire_entity_cmd.flags[0] = pending_persistent;
  set_64(aem_msg->command.acquire_entity_cmd.owner_guid, acquired_controller_guid.c);
  hton_16(aem_msg->command.acquire_entity_cmd.descriptor_type, 0);
  hton_16(aem_msg->command.acquire_entity_cmd.descriptor_id, 0);

  avb_1722_1_create_1722_1_header(pending_controller_mac, DEFAULT_1722_1_AECP_SUBTYPE, AECP_CMD_AEM_RESPONSE, status, AVB_1722_1_AECP_COMMAND_DATA_OFFSET + sizeof(avb_1722_1_aem_acquire_entity_command_t), hdr);

  set_64(pkt->target_guid, my_guid.c);
  set_64(pkt->controller_guid, pending_controller_guid.c);
  hton_16(pkt->sequence_id, pending_controller_sequence);

  AEM_MSG_SET_COMMAND_TYPE(aem_msg, AECP_AEM_CMD_ACQUIRE_ENTITY);
  AEM_MSG_SET_U_FLAG(aem_msg, 0);

  return sizeof(avb_1722_1_aem_acquire_entity_command_t) + AVB_1722_1_AECP_PAYLOAD_OFFSET;
}

static unsigned short process_aem_cmd_acquire(avb_1722_1_aecp_packet_t *pkt, unsigned char *status, unsigned char src_addr[6], chanend c_tx)
{
  unsigned short descriptor_index = ntoh_16(pkt->data.aem.command.acquire_entity_cmd.descriptor_id);
  unsigned short descriptor_type = ntoh_16(pkt->data.aem.command.acquire_entity_cmd.descriptor_type);

  if (AEM_ENTITY_TYPE == descriptor_type && 0 == descriptor_index)
  {
    if (AEM_ACQUIRE_ENTITY_RELEASE_FLAG(&(pkt->data.aem.command.acquire_entity_cmd)))
    {
      //Release
      if (entity_acquired_status == AEM_ENTITY_NOT_ACQUIRED)
      {
        *status = AECP_AEM_STATUS_BAD_ARGUMENTS;
      }
      else if (compare_guid(pkt->controller_guid, &acquired_controller_guid))
      {
        *status = AECP_AEM_STATUS_SUCCESS;
        entity_acquired_status = AEM_ENTITY_NOT_ACQUIRED;
        debug_printf("1722.1 Controller %x%x released entity\n", acquired_controller_guid.l<<32, acquired_controller_guid.l);
        for(int i=0; i < 8; i++)
        {
          acquired_controller_guid.c[7-i] = 0;
        }
        memset(&acquired_controller_mac, 0, 6);
      }
      else
      {
        *status = AECP_AEM_STATUS_ENTITY_ACQUIRED;

        for(int i=0; i < 8; i++)
        {
          pkt->data.aem.command.acquire_entity_cmd.owner_guid[i] = acquired_controller_guid.c[7-i];
        }
      }
    }
    else
    {
      //Acquire

      switch (entity_acquired_status)
      {
        case AEM_ENTITY_NOT_ACQUIRED:
          *status = AECP_AEM_STATUS_SUCCESS;
          if (AEM_ACQUIRE_ENTITY_PERSISTENT_FLAG(&(pkt->data.aem.command.acquire_entity_cmd)))
          {
            entity_acquired_status = AEM_ENTITY_ACQUIRED_AND_PERSISTENT;
          }
          else
          {
            entity_acquired_status = AEM_ENTITY_ACQUIRED;
          }
          for(int i=0; i < 8; i++)
          {
            acquired_controller_guid.c[7-i] = pkt->controller_guid[i];
            pkt->data.aem.command.acquire_entity_cmd.owner_guid[i] = acquired_controller_guid.c[7-i];
          }
          debug_printf("1722.1 Controller %x%x acquired entity\n", acquired_controller_guid.l<<32, acquired_controller_guid.l);
          memcpy(&acquired_controller_mac, &src_addr, 6);
          break;

        case AEM_ENTITY_ACQUIRED_BUT_PENDING:

          break;

        case AEM_ENTITY_ACQUIRED:
          if (compare_guid(pkt->controller_guid, &acquired_controller_guid))
          {
            *status = AECP_AEM_STATUS_SUCCESS;
          }
          else
          {
            *status = AECP_AEM_STATUS_IN_PROGRESS;
            for(int i=0; i < 8; i++)
            {
              pending_controller_guid.c[7-i] = pkt->controller_guid[i];
            }
            memcpy(&pending_controller_mac, &src_addr, 6);
            pending_controller_sequence = ntoh_16(pkt->sequence_id);
            pending_persistent = AEM_ACQUIRE_ENTITY_PERSISTENT_FLAG(&(pkt->data.aem.command.acquire_entity_cmd));

            aecp_controller_available_sequence++;

            avb_1722_1_create_controller_available_packet();
            mac_tx(c_tx, avb_1722_1_buf, 64, -1);

            start_avb_timer(&aecp_aem_controller_available_timer, 12);
            aecp_aem_controller_available_state = AECP_AEM_CONTROLLER_AVAILABLE_IN_A;
            entity_acquired_status = AEM_ENTITY_ACQUIRED_BUT_PENDING;
          }

          for(int i=0; i < 8; i++)
          {
            pkt->data.aem.command.acquire_entity_cmd.owner_guid[i] = acquired_controller_guid.c[7-i];
          }
          break;
        case AEM_ENTITY_ACQUIRED_AND_PERSISTENT:
          if (compare_guid(pkt->controller_guid, &acquired_controller_guid))
          {
            *status = AECP_AEM_STATUS_SUCCESS;
          }
          else
          {
            *status = AECP_AEM_STATUS_ENTITY_ACQUIRED;
          }

          for(int i=0; i < 8; i++)
          {
            pkt->data.aem.command.acquire_entity_cmd.owner_guid[i] = acquired_controller_guid.c[7-i];
          }
          break;
      }
    }
  }
  else
  {
    *status = AECP_AEM_STATUS_NOT_SUPPORTED;
  }


  return GET_1722_1_DATALENGTH(&pkt->header);
}

#if AVB_1722_1_FIRMWARE_UPGRADE_ENABLED
static int process_aem_cmd_start_abort_operation(avb_1722_1_aecp_packet_t *pkt,
                                                unsigned char src_addr[6],
                                                unsigned char *status,
                                                unsigned short command_type,
                                                CLIENT_INTERFACE(spi_interface, i_spi),
                                                chanend c_tx)
{
  avb_1722_1_aem_start_operation_t *cmd = (avb_1722_1_aem_start_operation_t *)(pkt->data.aem.command.payload);
  unsigned short desc_type = ntoh_16(cmd->descriptor_type);
  unsigned short desc_id = ntoh_16(cmd->descriptor_id);
  unsigned short operation_type = ntoh_16(cmd->operation_type);

  if (command_type == AECP_AEM_CMD_START_OPERATION &&
      desc_type == AEM_MEMORY_OBJECT_TYPE &&
      desc_id == 0) // descriptor ID of the AEM_MEMORY_OBJECT_TYPE descriptor
  {
    switch (operation_type)
    {
      case AEM_MEMORY_OBJECT_OPERATION_ERASE:
      {
        const int erase_operation_id = 1234;
        hton_16(cmd->operation_id, erase_operation_id);
        // Form response and send immediately
        avb_1722_1_create_aecp_aem_response(src_addr, AECP_AEM_STATUS_SUCCESS, GET_1722_1_DATALENGTH(&pkt->header), pkt);
        int num_tx_bytes = sizeof(avb_1722_1_aem_start_operation_t) + AVB_1722_1_AECP_PAYLOAD_OFFSET;
        if (num_tx_bytes < 64) num_tx_bytes = 64;
        mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);

        avb_1722_1_aecp_aem_msg_t *aem_msg = &(pkt->data.aem);
        AEM_MSG_SET_U_FLAG(aem_msg, 1);
        AEM_MSG_SET_COMMAND_TYPE(aem_msg, AECP_AEM_CMD_OPERATION_STATUS);
        avb_1722_1_aem_operation_status_t *resp = (avb_1722_1_aem_operation_status_t *)(pkt->data.aem.command.payload);

        hton_16(resp->operation_id, erase_operation_id);

        if (!avb_erase_upgrade_image(i_spi))
        {
          hton_16(resp->percent_complete, 1000);
        }
        else
        {
          // Failed
          hton_16(resp->percent_complete, 0);
          *status = AECP_AEM_STATUS_ENTITY_MISBEHAVING;
        }
        avb_1722_1_create_aecp_aem_response(src_addr, *status, GET_1722_1_DATALENGTH(&pkt->header), pkt);
        mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);

        return 0;
        break;
      }
      default:
      {
        *status = AECP_AEM_STATUS_BAD_ARGUMENTS; // Other operation types not supported
        break;
      }
    }
  }
  else if (command_type == AECP_AEM_CMD_ABORT_OPERATION)
  {
    *status = AECP_AEM_STATUS_NOT_IMPLEMENTED;
  }
  else
  {
    *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  }
  return GET_1722_1_DATALENGTH(&pkt->header);
}
#endif

static int process_aem_cmd_get_audio_map(avb_1722_1_aecp_packet_t *pkt,
                                         unsigned char *status)
{
  unsigned char *payload = pkt->data.aem.command.payload;
  const unsigned short desc_type = ntoh_16(&payload[0]);
  const unsigned short desc_id = ntoh_16(&payload[2]);
  const unsigned short map_index = ntoh_16(&payload[4]);
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
  const int num_mappings = AVB_NUM_MEDIA_INPUTS;
#else
  const int num_mappings = AVB_NUM_MEDIA_OUTPUTS;
#endif

  /* HYB4.60 experiment: keep the 4.55-safe STREAM_PORT_INPUT descriptor
   * (number_of_maps remains 0), but answer GET_AUDIO_MAP with the descriptor-
   * shaped header order that Wireshark/la_avdecc name explicitly:
   *   descriptor_type, descriptor_index, map_index,
   *   mappings_offset, number_of_mappings, number_of_maps, mappings[]
   *
   * This is control-plane only; media, CRF, FIFO, gPTP, and DAC clocking are
   * intentionally untouched from HYB4.55.
   */
  memset(payload, 0, 12 + (num_mappings * 8));

  hton_16(&payload[0], desc_type);
  hton_16(&payload[2], desc_id);
  hton_16(&payload[4], map_index);

  if (
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
      desc_type == AEM_STREAM_PORT_OUTPUT_TYPE &&
#else
      desc_type == AEM_STREAM_PORT_INPUT_TYPE &&
#endif
      desc_id == 0 && map_index == 0)
  {
    hton_16(&payload[6], 12);           /* mappings_offset */
    hton_16(&payload[8], num_mappings); /* number_of_mappings */
    hton_16(&payload[10], 1);           /* number_of_maps */

    for (int i = 0; i < num_mappings; i++)
    {
      const int off = 12 + (i * 8);
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
      hton_16(&payload[off + 0], 0); /* mapping_stream_index: AAF output */
#else
      hton_16(&payload[off + 0], 1); /* mapping_stream_index: AAF input */
#endif
      hton_16(&payload[off + 2], i); /* mapping_stream_channel */
      hton_16(&payload[off + 4], i); /* mapping_cluster_offset */
      hton_16(&payload[off + 6], 0); /* mapping_cluster_channel */
    }

    *status = AECP_AEM_STATUS_SUCCESS;
    return 12 + (num_mappings * 8);
  }

  if (
#if (AVB_NUM_SOURCES > 0) && (AVB_NUM_MEDIA_OUTPUTS == 0)
      desc_type == AEM_STREAM_PORT_OUTPUT_TYPE &&
#else
      desc_type == AEM_STREAM_PORT_INPUT_TYPE &&
#endif
      desc_id == 0)
  {
    /* Some controllers probe beyond the advertised map subset while building
     * Milan dynamic state. Return a well-formed empty map instead of a
     * non-success response, otherwise la_avdecc treats GET_AUDIO_MAP as
     * unsupported for Milan mandatory dynamic info.
     */
    hton_16(&payload[6], 12); /* mappings_offset */
    hton_16(&payload[8], 0);  /* number_of_mappings */
    hton_16(&payload[10], 1); /* number_of_maps */
    *status = AECP_AEM_STATUS_SUCCESS;
    return 12;
  }

  *status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
  return 8;
}static void process_avb_1722_1_aecp_aem_msg(avb_1722_1_aecp_packet_t *pkt,
                                            unsigned char src_addr[6],
                                            int message_type,
                                            int num_pkt_bytes,
                                            chanend c_tx,
                                            CLIENT_INTERFACE(avb_interface, i_avb_api),
                                            CLIENT_INTERFACE(avb_1722_1_control_callbacks, i_1722_1_entity),
                                            CLIENT_INTERFACE(spi_interface, i_spi))
{
  avb_1722_1_aecp_aem_msg_t *aem_msg = &(pkt->data.aem);
  unsigned short command_type = AEM_MSG_GET_COMMAND_TYPE(aem_msg);
  unsigned char status = AECP_AEM_STATUS_SUCCESS;
  int cd_len = 0;

  if (message_type == AECP_CMD_AEM_COMMAND)
  {
    if (compare_guid(pkt->target_guid, &my_guid)==0) return;

    /* Any valid AEM command proves that a registered controller is alive.
     * Refresh its return MAC as controllers may restart on a new interface. */
    aecp_touch_unsolicited_controller(pkt->controller_guid, src_addr);

    switch (command_type)
    {
      case AECP_AEM_CMD_ACQUIRE_ENTITY: // Long term exclusive control of the entity
      {
        cd_len = process_aem_cmd_acquire(pkt, &status, src_addr, c_tx);
        break;
      }
      case AECP_AEM_CMD_LOCK_ENTITY: // Atomic operation on the entity
      {
        /* HYB4.23 Milan compatibility: report LOCK_ENTITY as implemented
         * and return the standard 16-byte command_specific_data shape
         * (flags, locked_guid, descriptor_type, descriptor_index). HYB4.21
         * showed that NOT_SUPPORTED makes Milan Manager reject the device;
         * HYB4.22 showed the zero-byte SUCCESS form preserves visibility but
         * has the wrong payload size.  This remains control-plane only.
         */
        unsigned char *payload = pkt->data.aem.command.payload;
        memset(payload, 0, 16);
        status = AECP_AEM_STATUS_SUCCESS;
        avb_1722_1_create_aecp_aem_response(src_addr, status, 16, pkt);
        cd_len = 16;
        break;
      }
      case AECP_AEM_CMD_ENTITY_AVAILABLE:
      {
        cd_len = AVB_1722_1_AECP_PAYLOAD_OFFSET;
        break;
      }
      case AECP_AEM_CMD_REBOOT:
      {
        // Reply before reboot, do the reboot after sending the packet
        cd_len = AVB_1722_1_AECP_PAYLOAD_OFFSET;
        break;
      }
      case AECP_AEM_CMD_READ_DESCRIPTOR:
      {
        unsigned int desc_read_type, desc_read_id;
        int num_tx_bytes;

        desc_read_type = ntoh_16(aem_msg->command.read_descriptor_cmd.descriptor_type);
        desc_read_id = ntoh_16(aem_msg->command.read_descriptor_cmd.descriptor_id);

        num_tx_bytes = create_aem_read_descriptor_response(desc_read_type, desc_read_id, src_addr, pkt);

        if (num_tx_bytes < 64) num_tx_bytes = 64;

        mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);

        break;
      }
      case AECP_AEM_CMD_GET_AVB_INFO:
      {
        // Command and response share descriptor_type and descriptor_index
        avb_1722_1_aem_get_avb_info_response_t *cmd = (avb_1722_1_aem_get_avb_info_response_t *)(pkt->data.aem.command.payload);
        unsigned short desc_type = ntoh_16(cmd->descriptor_type);
        unsigned short desc_id = ntoh_16(cmd->descriptor_id);

        if (desc_type == AEM_AVB_INTERFACE_TYPE && desc_id == 0)
        {
          unsigned int pdelay;
          avb_1722_1_adp_get_ptp_grandmaster(&cmd->as_grandmaster_id[0]);
          pdelay = avb_1722_1_adp_get_ptp_propagation_delay();
          hton_32(cmd->propagation_delay, pdelay);
          /* AVB_INTERFACE_INFO flags: AS_CAPABLE, GPTP_ENABLED, SRP_ENABLED. */
          hton_16(cmd->reserved, 0x0007);
          hton_16(cmd->msrp_mappings_count, 1);
          cmd->msrp_mappings[0] = AVB_SRP_SRCLASS_DEFAULT;
          cmd->msrp_mappings[1] = AVB_SRP_TSPEC_PRIORITY_DEFAULT;
          cmd->msrp_mappings[2] = (AVB_DEFAULT_VLAN>>8)&0xff;
          cmd->msrp_mappings[3] = (AVB_DEFAULT_VLAN&0xff);

          cd_len = sizeof(avb_1722_1_aem_get_avb_info_response_t);
        }
        else {
          status = AECP_AEM_STATUS_NO_SUCH_DESCRIPTOR;
          cd_len = sizeof(avb_1722_1_aem_get_avb_info_response_t);
        }
        break;
      }
      case AECP_AEM_CMD_GET_AS_PATH:
      {
        /* Report the current live gPTP path: elected grandmaster followed by
         * the local entity/port clock identity. No network identity is
         * substituted while gPTP is acquiring. */
        unsigned char *payload = pkt->data.aem.command.payload;
        memset(payload, 0, 20);
        payload[3] = 0x02;
        avb_1722_1_adp_get_ptp_grandmaster(&payload[4]);
        for (int i = 0; i < 8; i++) {
          payload[12+i] = my_guid.c[7-i];
        }
        cd_len = 20;
        break;
      }
      case AECP_AEM_CMD_GET_NAME:
      case AECP_AEM_CMD_SET_NAME:
      {
        /* Milan 1.3 5.4.2.11/12 and IEEE 1722.1 7.4.17/18. GET_NAME carries
         * an 8-byte selector and returns that selector plus a 64-byte fixed
         * string; SET_NAME carries and echoes the complete 72-byte payload. */
        cd_len = process_aem_cmd_getset_name(pkt, &status, command_type);
        break;
      }
      case AECP_AEM_CMD_REGISTER_UNSOLICITED_NOTIFICATION:
      {
        /* HYB4.112: retain the controller and its ingress MAC so asynchronous
         * AEM state changes can be delivered on this AVB interface.  Respond
         * with the standard zero-byte command-specific payload. */
        if (aecp_register_unsolicited_controller(pkt->controller_guid,
                                                  src_addr) < 0)
          status = AECP_AEM_STATUS_NO_RESOURCES;
        aecp_send_empty_aem_response(src_addr, status, pkt, c_tx);
        return;
      }
      case AECP_AEM_CMD_DEREGISTER_UNSOLICITED_NOTIFICATION:
      {
        aecp_deregister_unsolicited_controller(pkt->controller_guid);
        aecp_send_empty_aem_response(src_addr, AECP_AEM_STATUS_SUCCESS,
                                     pkt, c_tx);
        return;
      }
      case AECP_AEM_CMD_GET_STREAM_INFO:
      {
        /* HYB4.14 Milan compatibility: Milan controllers expect the
         * IEEE 1722.1-2021 / Milan extended GET_STREAM_INFO response size.
         * JOYNED devices on this network answer control_data_length 68,
         * while the legacy XMOS stack answered 60 and Hive reported
         * "Milan mandatory extended GET_STREAM_INFO not found".
         *
         * HYB4.69: do not leave the Milan extension bytes entirely empty for
         * connected listener streams. Joyned listener streams report the Milan
         * extension as flags_ex REGISTERING plus a non-zero probing status, and
         * Milan Manager otherwise keeps showing our active listener connection
         * as TALKER_OFFLINE even while audio/CRF are actually flowing.
         */
        process_aem_cmd_getset_stream_info(pkt, &status, command_type, i_avb_api);
        cd_len = 68;
        aecp_complete_milan_stream_info_extension(pkt);
        break;
      }
      case AECP_AEM_CMD_SET_STREAM_INFO:
      {
        process_aem_cmd_getset_stream_info(pkt, &status, command_type, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_getset_stream_info_t);
        break;
      }
      case AECP_AEM_CMD_GET_STREAM_FORMAT:
      case AECP_AEM_CMD_SET_STREAM_FORMAT:
      {
        process_aem_cmd_getset_stream_format(pkt, &status, command_type, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_getset_stream_format_t);
        break;
      }
      case AECP_AEM_CMD_GET_SAMPLING_RATE:
      case AECP_AEM_CMD_SET_SAMPLING_RATE:
      {
        process_aem_cmd_getset_sampling_rate(pkt, &status, command_type, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_getset_sampling_rate_t);
        break;
      }
      case AECP_AEM_CMD_GET_CLOCK_SOURCE:
      case AECP_AEM_CMD_SET_CLOCK_SOURCE:
      {
        process_aem_cmd_getset_clock_source(pkt, &status, command_type, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_getset_clock_source_t);
        break;
      }
      case AECP_AEM_CMD_START_STREAMING:
      case AECP_AEM_CMD_STOP_STREAMING:
      {
        process_aem_cmd_startstop_streaming(pkt, &status, command_type, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_startstop_streaming_t);
        break;
      }
      case AECP_AEM_CMD_GET_CONTROL:
      case AECP_AEM_CMD_SET_CONTROL:
      {
        cd_len = process_aem_cmd_getset_control(pkt, &status, command_type, i_1722_1_entity) + sizeof(avb_1722_1_aem_getset_control_t) + AVB_1722_1_AECP_COMMAND_DATA_OFFSET;
        break;
      }
      case AECP_AEM_CMD_GET_COUNTERS:
      {
        process_aem_cmd_get_counters(pkt, &status, i_avb_api);
        cd_len = sizeof(avb_1722_1_aem_get_counters_t);
        break;
      }
      case AECP_AEM_CMD_GET_AUDIO_MAP:
      {
        cd_len = process_aem_cmd_get_audio_map(pkt, &status);
        break;
      }
#if AVB_1722_1_FIRMWARE_UPGRADE_ENABLED
      case AECP_AEM_CMD_START_OPERATION:
      case AECP_AEM_CMD_ABORT_OPERATION:
      {
        cd_len = process_aem_cmd_start_abort_operation(pkt, src_addr, &status, command_type, i_spi, c_tx);
        break;
      }
#endif
      default:
      {
        // AECP_AEM_STATUS_NOT_IMPLEMENTED
        return;
      }
    }

    // Send a response if required
    if (cd_len > 0)
    {
      avb_1722_1_create_aecp_aem_response(src_addr, status, cd_len, pkt);
    }
  }
  else // AECP_CMD_AEM_RESPONSE
  {
    switch (command_type)
    {
      case AECP_AEM_CMD_CONTROLLER_AVAILABLE:
        if (aecp_unsolicited_probe_index >= 0 &&
            compare_guid(pkt->controller_guid, &my_guid) &&
            memcmp(pkt->target_guid,
                   aecp_unsolicited_controllers[aecp_unsolicited_probe_index].guid,
                   8) == 0 &&
            ntoh_16(pkt->sequence_id) == aecp_unsolicited_probe_sequence)
        {
          aecp_unsolicited_controllers[aecp_unsolicited_probe_index].idle_seconds = 0;
          aecp_finish_unsolicited_probe();
        }
        if (AEM_ENTITY_ACQUIRED_BUT_PENDING == entity_acquired_status && compare_guid(pkt->controller_guid, &my_guid))
        {
          if (compare_guid(pkt->target_guid, &pending_controller_guid))
          {
            entity_acquired_status = AEM_ENTITY_ACQUIRED;
            aecp_aem_controller_available_state = AECP_AEM_CONTROLLER_AVAILABLE_IDLE;

            cd_len = avb_1722_1_create_acquire_response_packet(AECP_AEM_STATUS_SUCCESS);
          }
          else if (compare_guid(pkt->target_guid, &acquired_controller_guid))
          {
            if (AEM_ACQUIRE_ENTITY_PERSISTENT_FLAG(&(pkt->data.aem.command.acquire_entity_cmd)))
            {
              entity_acquired_status = AEM_ENTITY_ACQUIRED_AND_PERSISTENT;
            }
            else
            {
              entity_acquired_status = AEM_ENTITY_ACQUIRED;
            }

            cd_len = avb_1722_1_create_acquire_response_packet(AECP_AEM_STATUS_ENTITY_ACQUIRED);
            stop_avb_timer(&aecp_aem_controller_available_timer);
          }
        }
        break;
      default:
        break;
    }
  }

  if (cd_len > 0)
  {
    int num_tx_bytes = cd_len +
                            2 + // U Flag + command type
                            AVB_1722_1_AECP_PAYLOAD_OFFSET +
                            sizeof(ethernet_hdr_t);

    if (num_tx_bytes < 64) num_tx_bytes = 64;

    mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);

    if (command_type == AECP_AEM_CMD_REBOOT) {
      waitfor(10000); // Wait for the response packet to egress
      device_reboot();
    }
  }
}

#if AVB_1722_1_FIRMWARE_UPGRADE_ENABLED
static void process_avb_1722_1_aecp_address_access_cmd(avb_1722_1_aecp_packet_t *pkt,
                                            unsigned char src_addr[6],
                                            int message_type,
                                            int num_pkt_bytes,
                                            CLIENT_INTERFACE(spi_interface, i_spi),
                                            chanend c_tx)
{
  avb_1722_1_aecp_address_access_t *aa_cmd = &(pkt->data.address);
  int tlv_count = ntoh_16(aa_cmd->tlv_count);
  unsigned short status = AECP_AA_STATUS_SUCCESS;
  int mode = ADDRESS_MSG_GET_MODE(aa_cmd);
  int length = ADDRESS_MSG_GET_LENGTH(aa_cmd);
  int cd_len = 0;

  if (compare_guid(pkt->target_guid, &my_guid)==0) return;

  if (tlv_count != 1 || mode != AECP_AA_MODE_WRITE || length != 256) {
    status = AECP_AA_STATUS_UNSUPPORTED;
  }
  else {
    long long address = ntoh_32(&aa_cmd->address[4]);
    if (avb_write_upgrade_image_page(i_spi, address, aa_cmd->data) != 0) {
      status = AECP_AA_STATUS_ADDRESS_INVALID;
    }
    cd_len = num_pkt_bytes;
  }

  // Send a response if required
  if (cd_len > 0)
  {
    avb_1722_1_aecp_address_access_t *aa_pkt = (avb_1722_1_aecp_address_access_t*)avb_1722_1_create_aecp_response_header(src_addr, status, AECP_CMD_ADDRESS_ACCESS_COMMAND, 278, pkt);

    /* Copy payload_specific_data into the response */
    memcpy(aa_pkt, pkt->data.payload, sizeof(avb_1722_1_aecp_address_access_t));
  }

  if (cd_len > 0)
  {
    int num_tx_bytes = cd_len;

    if (num_tx_bytes < 64) num_tx_bytes = 64;

    mac_tx(c_tx, avb_1722_1_buf, 304, -1);
  }
}

#endif

/* HYB4.11 Milan MVU 4-byte command-aware advertisement helper.
 *
 * Milan-aware controllers may probe AECP Vendor Unique after seeing the
 * VENDOR_UNIQUE_SUPPORTED ADP bit.  HYB4.6 had a shifted MilanInfo layout,
 * which proved too weak for Hive's Milan compatibility probe.
 *
 * This handler deliberately stays bounded and non-blocking.  It echoes the
 * request protocol id/command selector and supplies a Milan-info-style payload
 * with the same public version values Hive reports for the JOYNED Milan
 * devices in this system:
 *   protocol_version       1
 *   specification_version  1.2.0.0
 *   certification_version  1.1.0.0
 *   flags                  0
 *
 * Audio, CRF, SRP, AEM descriptors, stream routing, and the clock loop are not
 * modified by this compatibility responder.
 */
static void process_avb_1722_1_aecp_vendor_unique_cmd(avb_1722_1_aecp_packet_t *pkt,
                                            unsigned char src_addr[6],
                                            int num_pkt_bytes,
                                            chanend c_tx)
{
  unsigned int request_control_data_len = GET_1722_1_DATALENGTH(&pkt->header);
  unsigned int request_vendor_payload_len = 0;
  unsigned int response_vendor_payload_len = 48;
  unsigned int mvu_cmd = 0xffffffff;

  if (request_control_data_len >= 10) {
    request_vendor_payload_len = request_control_data_len - 10;
  }
  if (request_vendor_payload_len > 514) {
    request_vendor_payload_len = 514;
  }

  if (request_vendor_payload_len >= 4) {
    unsigned int cmd_be = ((unsigned int)pkt->data.vendor.payload_data[0] << 24) |
                          ((unsigned int)pkt->data.vendor.payload_data[1] << 16) |
                          ((unsigned int)pkt->data.vendor.payload_data[2] << 8)  |
                          ((unsigned int)pkt->data.vendor.payload_data[3]);
    unsigned int cmd_alt = ((unsigned int)pkt->data.vendor.payload_data[0] << 8) |
                           ((unsigned int)pkt->data.vendor.payload_data[1]);

    /* HYB4.40: accept both simple MVU selectors (00000004) and the
     * controller-observed padded selectors (00000400), so MCR info does not
     * fall through to the generic/default payload size.
     */
    if (cmd_be == 0x00000000 || cmd_be == 0x00000002 || cmd_be == 0x00000004 ||
        cmd_be == 0x00000200 || cmd_be == 0x00000400) {
      mvu_cmd = cmd_be;
    }
    else if (cmd_alt == 0x0000 || cmd_alt == 0x0002 || cmd_alt == 0x0004) {
      mvu_cmd = cmd_alt;
    }
    else {
      mvu_cmd = cmd_be;
    }
  }

  /* GET_MILAN_INFO: use the accepted MT32 wire shape observed on this network.
   * AECP control_data_length is 0x24 = 10 common bytes + 26 vendor bytes.
   */
  if (mvu_cmd == 0x00000000) {
    response_vendor_payload_len = 26;
  }
  else if (mvu_cmd == 0x00000002 || mvu_cmd == 0x00000200) {
    /* Milan GET_SYSTEM_UNIQUE_ID: command echo + stable 64-bit system id. */
    response_vendor_payload_len = 18;
  }
  else if (mvu_cmd == 0x00000004 || mvu_cmd == 0x00000400) {
    /* Milan 1.2 GET_MEDIA_CLOCK_REFERENCE_INFO response:
     * 6-byte protocol id + 2-byte MVU command + 74-byte response payload.
     * Hive 1.3.2's la_avdecc checks for the complete 74-byte command payload. */
    response_vendor_payload_len = 82;
  }

  unsigned int control_data_len = 10 + response_vendor_payload_len;
  unsigned char *vendor_payload = avb_1722_1_create_aecp_response_header(src_addr,
                                                                        AECP_STATUS_SUCCESS,
                                                                        AECP_CMD_VENDOR_UNIQUE_COMMAND,
                                                                        control_data_len,
                                                                        pkt);

  memset(vendor_payload, 0, response_vendor_payload_len);

  if (request_vendor_payload_len >= 6) {
    memcpy(vendor_payload, pkt->data.vendor.protocol_id, 6);
  }

  if (request_vendor_payload_len >= 4 && response_vendor_payload_len >= 10) {
    vendor_payload[6] = pkt->data.vendor.payload_data[0];
    vendor_payload[7] = pkt->data.vendor.payload_data[1];
    vendor_payload[8] = pkt->data.vendor.payload_data[2];
    vendor_payload[9] = pkt->data.vendor.payload_data[3];
  } else if (request_vendor_payload_len >= 2 && response_vendor_payload_len >= 8) {
    vendor_payload[6] = pkt->data.vendor.payload_data[0];
    vendor_payload[7] = pkt->data.vendor.payload_data[1];
  }

  if (mvu_cmd == 0x00000000) {
    /* MT32 GET_MILAN_INFO payload after the 6-byte protocol id:
     * selector 00000000, protocol 00000001, flags 00000000,
     * certification 01010000, specification 01020000, reserved 0000.
     */
    vendor_payload[10] = 0x00;
    vendor_payload[11] = 0x00;
    vendor_payload[12] = 0x00;
    vendor_payload[13] = 0x01;
    vendor_payload[14] = 0x00;
    vendor_payload[15] = 0x00;
    vendor_payload[16] = 0x00;
    vendor_payload[17] = 0x00;
    vendor_payload[18] = 0x01;
    vendor_payload[19] = 0x01;
    vendor_payload[20] = 0x00;
    vendor_payload[21] = 0x00;
    vendor_payload[22] = 0x01;
    vendor_payload[23] = 0x02;
    vendor_payload[24] = 0x00;
    vendor_payload[25] = 0x00;
  }
  else if (mvu_cmd == 0x00000002 || mvu_cmd == 0x00000200) {
    /* Use our stable entity EUI-64 as the Milan system unique id rather than
     * reporting all-ones/unknown.  set_64() convention stores my_guid little
     * endian, so write it in network byte order here.
     */
    vendor_payload[10] = my_guid.c[7];
    vendor_payload[11] = my_guid.c[6];
    vendor_payload[12] = my_guid.c[5];
    vendor_payload[13] = my_guid.c[4];
    vendor_payload[14] = my_guid.c[3];
    vendor_payload[15] = my_guid.c[2];
    vendor_payload[16] = my_guid.c[1];
    vendor_payload[17] = my_guid.c[0];
  }
  else if (mvu_cmd == 0x00000004 || mvu_cmd == 0x00000400) {
    /* Exact Milan 1.2 / la_avdecc wire shape.  After the 6-byte protocol id
     * and 2-byte command header, serialize:
     * clock_domain_index(2), flags(1), reserved(1), default_priority(1),
     * user_priority(1), reserved(4), domain_name(64) = 74 bytes. */
    vendor_payload[6] = 0x00;
    vendor_payload[7] = 0x04;
    /* clock_domain_index = 0 */
    vendor_payload[8] = 0x00;
    vendor_payload[9] = 0x00;
    /* flags = 0: user priority and domain name are not independently valid. */
    vendor_payload[10] = 0x00;
    /* reserved8 */
    vendor_payload[11] = 0x00;
    /* Default and mirrored user MCR priority for a normal endpoint. */
    vendor_payload[12] = 0x80;
    vendor_payload[13] = 0x80;
    /* vendor_payload[14..17] reserved32 and [18..81] domain name were zeroed
     * by memset above. */
  }
  else {
    /* Keep the HYB4.11 safe command echo for other non-Milan-info MVU probes.
     * Do not pretend to know their payload until Wireshark gives us enough.
     */
  }

  int num_tx_bytes = response_vendor_payload_len +
                     AVB_1722_1_AECP_PAYLOAD_OFFSET +
                     sizeof(ethernet_hdr_t);

  if (num_tx_bytes < 64) num_tx_bytes = 64;
  mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);
}
void process_avb_1722_1_aecp_packet(unsigned char src_addr[6],
                                    avb_1722_1_aecp_packet_t *pkt,
                                    int num_pkt_bytes,
                                    chanend c_tx,
                                    CLIENT_INTERFACE(avb_interface, i_avb),
                                    CLIENT_INTERFACE(avb_1722_1_control_callbacks, i_1722_1_entity),
                                    CLIENT_INTERFACE(spi_interface, i_spi))
{
  int message_type = GET_1722_1_MSG_TYPE(((avb_1722_1_packet_header_t*)pkt));

  switch (message_type)
  {
    case AECP_CMD_AEM_COMMAND:
    case AECP_CMD_AEM_RESPONSE:
    {
#if AVB_1722_1_AEM_ENABLED
      process_avb_1722_1_aecp_aem_msg(pkt, src_addr, message_type, num_pkt_bytes, c_tx, i_avb, i_1722_1_entity, i_spi);
#endif
      break;
    }
#if AVB_1722_1_FIRMWARE_UPGRADE_ENABLED
    case AECP_CMD_ADDRESS_ACCESS_COMMAND:
    {
      process_avb_1722_1_aecp_address_access_cmd(pkt, src_addr, message_type, num_pkt_bytes, i_spi, c_tx);
      break;
    }
#endif
    case AECP_CMD_AVC_COMMAND:
    {
      break;
    }
    case AECP_CMD_VENDOR_UNIQUE_COMMAND:
    {
      process_avb_1722_1_aecp_vendor_unique_cmd(pkt, src_addr, num_pkt_bytes, c_tx);
      break;
    }
    case AECP_CMD_EXTENDED_COMMAND:
    {
      break;
    }
    default:
      // This node is not expecting a response
      break;
  }
}

void avb_1722_1_aecp_aem_periodic(chanend c_tx,
                                  CLIENT_INTERFACE(avb_interface, i_avb))
{
  char available_timeouts[5] = {12, 1, 11, 12, 2};

  /* HYB4.117 control-plane maintenance. This sends at most one small AECP
   * packet per second and never executes in audio, CRF, gPTP or DAC tasks. */
  aecp_unsolicited_controller_maintenance(c_tx);

  /* Milan 1.3 Table 5.20: GET_STREAM_INFO is sent asynchronously whenever
   * the connected/stream/SRP state changes.  Polling here is bounded to the
   * AVDECC task and never runs in the audio, listener, CRF or media-clock
   * timing loops. */
  if (avb_timer_expired(&aecp_aem_stream_info_timer))
  {
    for (unsigned stream_index = 0; stream_index < AVB_NUM_SINKS;
         stream_index++)
    {
      unsigned char status = AECP_AEM_STATUS_SUCCESS;
      aecp_prepare_unsolicited_header(&aecp_unsolicited_packet,
                                      AECP_AEM_CMD_GET_STREAM_INFO,
                                      AEM_STREAM_INPUT_TYPE,
                                      stream_index);
      process_aem_cmd_getset_stream_info(&aecp_unsolicited_packet, &status,
                                         AECP_AEM_CMD_GET_STREAM_INFO,
                                         i_avb);
      aecp_complete_milan_stream_info_extension(&aecp_unsolicited_packet);

      unsigned char *payload =
          aecp_unsolicited_packet.data.aem.command.payload;
      if (status == AECP_AEM_STATUS_SUCCESS)
      {
        if (!aecp_stream_info_snapshot_valid[stream_index])
        {
          memcpy(aecp_stream_info_snapshot[stream_index], payload, 68);
          aecp_stream_info_snapshot_valid[stream_index] = 1;
        }
        else if (memcmp(aecp_stream_info_snapshot[stream_index], payload,
                        68) != 0)
        {
          memcpy(aecp_stream_info_snapshot[stream_index], payload, 68);
          aecp_send_unsolicited_payload(&aecp_unsolicited_packet, 68, c_tx);
        }
      }
    }
    start_avb_timer(&aecp_aem_stream_info_timer, 10);
  }

  /* FRAMES_RX changes continuously while a listener is healthy.  Milan
   * requires GET_COUNTERS notifications for updated counters and limits them
   * to one per descriptor per second; this one-second scheduler implements
   * both requirements and gives controllers a positive packet-continuity
   * signal instead of the enumeration-time zero snapshot. */
  if (avb_timer_expired(&aecp_aem_counters_timer))
  {
    for (unsigned stream_index = 0; stream_index < AVB_NUM_SINKS;
         stream_index++)
    {
      unsigned char status = AECP_AEM_STATUS_SUCCESS;
      aecp_prepare_unsolicited_header(&aecp_unsolicited_packet,
                                      AECP_AEM_CMD_GET_COUNTERS,
                                      AEM_STREAM_INPUT_TYPE,
                                      stream_index);
      process_aem_cmd_get_counters(&aecp_unsolicited_packet, &status, i_avb);

      unsigned char *payload =
          aecp_unsolicited_packet.data.aem.command.payload;
      const unsigned payload_len = sizeof(avb_1722_1_aem_get_counters_t);
      if (status == AECP_AEM_STATUS_SUCCESS)
      {
        if (!aecp_stream_counter_snapshot_valid[stream_index])
        {
          memcpy(aecp_stream_counter_snapshot[stream_index], payload,
                 payload_len);
          aecp_stream_counter_snapshot_valid[stream_index] = 1;
        }
        else if (memcmp(aecp_stream_counter_snapshot[stream_index], payload,
                        payload_len) != 0)
        {
          memcpy(aecp_stream_counter_snapshot[stream_index], payload,
                 payload_len);
          aecp_send_unsolicited_payload(&aecp_unsolicited_packet,
                                        payload_len, c_tx);
        }
      }
    }
    start_avb_timer(&aecp_aem_counters_timer, 100);
  }

  if (avb_timer_expired(&aecp_aem_controller_available_timer))
  {
    int cd_len = 0;

    //Timeline

    //TX Controller Available
    //  IN_A state for 120ms
    //TX IN_PROGRESS response
    //  IN_B state for 120ms
    //TX IN_PROGRESS
    //  IN_C state for 10ms
    //TX Controller Available
    //  IN_D state for 110ms
    //TX IN_PROGRESS response
    //  IN_E state for 120ms
    //TX IN_PROGRESS response
    //  IN_F state for 20ms
    //Timed out so it's an acquire

    switch (aecp_aem_controller_available_state)
    {
      case AECP_AEM_CONTROLLER_AVAILABLE_IDLE:
        //Nothing to do
        break;
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_A:
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_B:
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_C:
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_D:
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_E:
        cd_len = avb_1722_1_create_acquire_response_packet(AECP_AEM_STATUS_IN_PROGRESS);
        start_avb_timer(&aecp_aem_controller_available_timer, available_timeouts[aecp_aem_controller_available_state]);
        aecp_aem_controller_available_state++;
        break;
      case AECP_AEM_CONTROLLER_AVAILABLE_IN_F:
        if (pending_persistent)
        {
          entity_acquired_status = AEM_ENTITY_ACQUIRED_AND_PERSISTENT;
        }
        else
        {
          entity_acquired_status = AEM_ENTITY_ACQUIRED;
        }
        for(int i=0; i < 8; i++)
        {
          acquired_controller_guid.c[7-i] = pending_controller_guid.c[7-i];
          //pkt->data.aem.command.acquire_entity_cmd.owner_guid[i] = acquired_controller_guid.c[7-i] = pending_controller_guid[7-i];
        }
        debug_printf("1722.1 Controller %x%x acquired entity after timeout\n", acquired_controller_guid.l<<32, acquired_controller_guid.l);

        memcpy(&acquired_controller_mac, &pending_controller_mac, 6);

        //TODO: Construct and send response to pending controller
        cd_len = avb_1722_1_create_acquire_response_packet(AECP_AEM_STATUS_SUCCESS);

        aecp_aem_controller_available_state = AECP_AEM_CONTROLLER_AVAILABLE_IDLE;
        break;
    }

    if (cd_len)
    {
      int num_tx_bytes = cd_len;

      if(num_tx_bytes < 64)
      {
        num_tx_bytes = 64;
      }

      mac_tx(c_tx, avb_1722_1_buf, num_tx_bytes, -1);
    }
  }

}






