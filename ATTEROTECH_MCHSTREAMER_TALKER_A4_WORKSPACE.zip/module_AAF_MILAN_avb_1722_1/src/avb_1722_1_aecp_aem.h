#ifndef AVB_1722_1_AECP_AEM_H_
#define AVB_1722_1_AECP_AEM_H_

#include "avb_1722_1_protocol.h"
#include "avb_1722_1_default_conf.h"

/* 7.4.2.1. READ_DESCRIPTOR Command Format */

typedef struct {
    unsigned char configuration[2];
    unsigned char reserved[2];
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
} avb_1722_1_aem_read_descriptor_command_t;

/* 7.4.2.2. READ_DESCRIPTOR Response Format */
typedef struct {
    unsigned char configuration[2];
    unsigned char reserved[2];
    unsigned char descriptor[512];
} avb_1722_1_aem_read_descriptor_response_t;

/* 7.4.1. ACQUIRE_ENTITY Command */
typedef struct {
    unsigned char flags[4];
    unsigned char owner_guid[8];
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
} avb_1722_1_aem_acquire_entity_command_t;

#define AEM_ACQUIRE_ENTITY_PERSISTENT_FLAG(cmd)     ((cmd)->flags[3] & 1)
#define AEM_ACQUIRE_ENTITY_RELEASE_FLAG(cmd)     ((cmd)->flags[0] & 0x80)

/* 7.4.2. LOCK_ENTITY Command */
typedef struct {
    unsigned char flags[4];
    unsigned char locked_guid[8];
} avb_1722_1_aem_lock_entity_command_t;

/* 7.4.40.1 GET_AVB_INFO Command */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
} avb_1722_1_aem_get_avb_info_command_t;

/* 7.4.40.2 GET_AVB_INFO Response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char as_grandmaster_id[8];
    unsigned char propagation_delay[4];
    unsigned char reserved[2];
    unsigned char msrp_mappings_count[2];
    unsigned char msrp_mappings[4];
} avb_1722_1_aem_get_avb_info_response_t;

/* 7.4.9.1 SET_STREAM_FORMAT Command/response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char stream_format[8];
} avb_1722_1_aem_getset_stream_format_t;

/* 7.4.22. SET_SAMPLING_RATE Command/Response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char sampling_rate[4];
} avb_1722_1_aem_getset_sampling_rate_t;

/* 7.4.23. SET_CLOCK_SOURCE Command/Response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char clock_source_index[2];
    unsigned char reserved[2];
} avb_1722_1_aem_getset_clock_source_t;

#define AECP_STREAM_INFO_FLAGS_FAST_CONNECT             (0x00000002)
#define AECP_STREAM_INFO_FLAGS_SAVED_STATE              (0x00000004)
#define AECP_STREAM_INFO_FLAGS_NOT_REGISTERING_SRP       (0x01000000)
#define AECP_STREAM_INFO_FLAGS_STREAM_VLAN_ID_VALID     (0x02000000)
#define AECP_STREAM_INFO_FLAGS_CONNECTED                (0x04000000)
#define AECP_STREAM_INFO_FLAGS_MSRP_FAILURE_VALID       (0x08000000)
#define AECP_STREAM_INFO_FLAGS_STREAM_DESC_MAC_VALID    (0x10000000)
#define AECP_STREAM_INFO_FLAGS_MSRP_ACC_LAT_VALID       (0x20000000)
#define AECP_STREAM_INFO_FLAGS_STREAM_ID_VALID          (0x40000000)
#define AECP_STREAM_INFO_FLAGS_STREAM_FORMAT_VALID      (0x80000000)

/* 7.4.15.1. SET_STREAM_INFO Command/Response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char flags[4];
    unsigned char stream_format[8];
    unsigned char stream_id[8];
    unsigned char msrp_accumulated_latency[4];
    unsigned char stream_dest_mac[6];
    unsigned char msrp_failure_code;
    unsigned char reserved1;
    unsigned char msrp_failure_bridge_id[8];
    unsigned char stream_vlan_id[2];
    unsigned char reserved2[2];
} avb_1722_1_aem_getset_stream_info_t;

#define AEM_MAX_CONTROL_VALUES_LENGTH_BYTES 508

/* 7.4.25.1 SET_CONTROL */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
} avb_1722_1_aem_getset_control_t;

/* 7.4.42 GET_COUNTERS */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char counters_valid[4];
    unsigned char counters_block[128];
} avb_1722_1_aem_get_counters_t;

#define AECP_GET_COUNTERS_CLOCK_DOMAIN_LOCKED_VALID     (0x00000001)
#define AECP_GET_COUNTERS_CLOCK_DOMAIN_UNLOCKED_VALID   (0x00000002)

#define AECP_GET_COUNTERS_CLOCK_DOMAIN_LOCKED_OFFSET    (0)
#define AECP_GET_COUNTERS_CLOCK_DOMAIN_UNLOCKED_OFFSET  (4)

#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_LOCKED_VALID        (0x00000001)
#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_UNLOCKED_VALID      (0x00000002)
#define AECP_GET_COUNTERS_STREAM_INPUT_STREAM_INTERRUPTED_VALID  (0x00000004)
#define AECP_GET_COUNTERS_STREAM_INPUT_SEQ_NUM_MISMATCH_VALID    (0x00000008)
#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_RESET_VALID         (0x00000010)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_UNCERTAIN_VALID (0x00000020)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_VALID_VALID     (0x00000040)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_NOT_VALID_VALID (0x00000080)
#define AECP_GET_COUNTERS_STREAM_INPUT_UNSUPPORTED_FORMAT_VALID  (0x00000100)
#define AECP_GET_COUNTERS_STREAM_INPUT_LATE_TIMESTAMP_VALID      (0x00000200)
#define AECP_GET_COUNTERS_STREAM_INPUT_EARLY_TIMESTAMP_VALID     (0x00000400)
#define AECP_GET_COUNTERS_STREAM_INPUT_FRAMES_RX_VALID           (0x00000800)

#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_LOCKED_OFFSET        (0)
#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_UNLOCKED_OFFSET      (4)
#define AECP_GET_COUNTERS_STREAM_INPUT_STREAM_INTERRUPTED_OFFSET  (8)
#define AECP_GET_COUNTERS_STREAM_INPUT_SEQ_NUM_MISMATCH_OFFSET    (12)
#define AECP_GET_COUNTERS_STREAM_INPUT_MEDIA_RESET_OFFSET         (16)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_UNCERTAIN_OFFSET (20)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_VALID_OFFSET     (24)
#define AECP_GET_COUNTERS_STREAM_INPUT_TIMESTAMP_NOT_VALID_OFFSET (28)
#define AECP_GET_COUNTERS_STREAM_INPUT_UNSUPPORTED_FORMAT_OFFSET  (32)
#define AECP_GET_COUNTERS_STREAM_INPUT_LATE_TIMESTAMP_OFFSET      (36)
#define AECP_GET_COUNTERS_STREAM_INPUT_EARLY_TIMESTAMP_OFFSET     (40)
#define AECP_GET_COUNTERS_STREAM_INPUT_FRAMES_RX_OFFSET           (44)

/* STREAM_OUTPUT counters use the Milan 1.2 layout (Milan 1.2, 5.3.7.7). */
#define AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_START_VALID         (0x00000001)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_STOP_VALID          (0x00000002)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_MEDIA_RESET_VALID          (0x00000004)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_TIMESTAMP_UNCERTAIN_VALID  (0x00000008)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_FRAMES_TX_VALID            (0x00000010)

#define AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_START_OFFSET        (0)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_STREAM_STOP_OFFSET         (4)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_MEDIA_RESET_OFFSET         (8)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_TIMESTAMP_UNCERTAIN_OFFSET (12)
#define AECP_GET_COUNTERS_STREAM_OUTPUT_FRAMES_TX_OFFSET           (16)

/* 7.4.35.1 START_STREAMING */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
} avb_1722_1_aem_startstop_streaming_t;

/* 7.4.39.1 IDENTIFY_NOTIFICATION */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_index[2];
} avb_1722_1_aem_identify_notification_t;

/* 7.4.53 START_OPERATION Command */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char operation_id[2];
    unsigned char operation_type[2];
} avb_1722_1_aem_start_operation_t;

/* 7.4.55 OPERATION_STATUS Unsolicited Response */
typedef struct {
    unsigned char descriptor_type[2];
    unsigned char descriptor_id[2];
    unsigned char operation_id[2];
    unsigned char percent_complete[2];
} avb_1722_1_aem_operation_status_t;


#endif /* AVB_1722_1_AECP_AEM_H_ */


#define AECP_GET_COUNTERS_AVB_INTERFACE_LINK_UP_VALID       (0x00000001)
#define AECP_GET_COUNTERS_AVB_INTERFACE_LINK_DOWN_VALID     (0x00000002)
#define AECP_GET_COUNTERS_AVB_INTERFACE_PACKETS_TX_VALID    (0x00000004)
#define AECP_GET_COUNTERS_AVB_INTERFACE_PACKETS_RX_VALID    (0x00000008)
#define AECP_GET_COUNTERS_AVB_INTERFACE_RX_CRC_ERROR_VALID  (0x00000010)
#define AECP_GET_COUNTERS_AVB_INTERFACE_GPTP_GM_CHANGED_VALID (0x00000020)

#define AECP_GET_COUNTERS_AVB_INTERFACE_LINK_UP_OFFSET       (0)
#define AECP_GET_COUNTERS_AVB_INTERFACE_LINK_DOWN_OFFSET     (4)
#define AECP_GET_COUNTERS_AVB_INTERFACE_PACKETS_TX_OFFSET    (8)
#define AECP_GET_COUNTERS_AVB_INTERFACE_PACKETS_RX_OFFSET    (12)
#define AECP_GET_COUNTERS_AVB_INTERFACE_RX_CRC_ERROR_OFFSET  (16)
#define AECP_GET_COUNTERS_AVB_INTERFACE_GPTP_GM_CHANGED_OFFSET (20)
