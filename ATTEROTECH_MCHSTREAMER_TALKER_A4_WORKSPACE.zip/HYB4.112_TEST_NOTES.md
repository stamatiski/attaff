# SABRE 9018 2 Channel — HYB4.112 UNSOLICITED LIVE STATE

Date: 2026-07-19

## Purpose

HYB4.112 is based directly on the audio-safe HYB4.111 build. It targets the
remaining controller-state symptom only: audio starts in 3–4 seconds and
reconnects immediately, but Hive does not show its Milan routing dots until a
manual refresh, Milan Manager changes the active connection to red, and Nebra
reports the listener network status as Not available.

## Changes from HYB4.111

- Implements real registration and deregistration for AEM unsolicited
  notifications, retaining the controller GUID and ingress MAC address.
- Sends an unsolicited `GET_STREAM_INFO` response when the serialized live
  listener state changes (Stream ID, destination MAC, VLAN, format, connected
  state, latency or SRP-related fields).
- Sends an unsolicited `GET_COUNTERS` response when live listener counters
  change, limited to no more than one notification per descriptor per second.
- Uses the existing live `GET_STREAM_INFO` and `GET_COUNTERS` generators, so
  notification contents are the same values returned by an explicit controller
  query rather than a second synthetic state model.
- Keeps per-controller unsolicited sequence numbers and delivers updates to
  every registered controller.

## Deliberately unchanged

- AAF receive and sample-copy path
- CRF parser, CRF acquisition and CRF-to-DAC clock path
- listener FIFO sizes, thresholds and recovery behavior
- I2S/DAC output and channel mapping
- gPTP/BMCA and Grandmaster selection
- ACMP connection handling, stream formats and audio gain

There are no switch-specific, talker-specific, Stream-ID-specific or
Grandmaster-ID-specific constants in this revision.

## Build verification

- XMOS xTIMEcomposer 14.4.1 clean build: PASS
- Tile 0: 7 cores, 8 timers, 23 chanends, 43,644 / 65,536 bytes
- Tile 1: 6 cores, 7 timers, 22 chanends, 63,212 / 65,536 bytes
- Constraint checks: PASS

## Test sequence

1. Flash HYB4.112 and power-cycle the SABRE device.
2. Start Hive, Milan Manager and Nebra before making stream connections.
3. Connect the MT32 CRF stream to `Input Stream CRF`.
4. Connect the ADAT AAF stream to `Input Stream AAF`.
5. Do **not** refresh Hive for at least 15 seconds.
6. Confirm whether:
   - first audio remains approximately 3–4 seconds;
   - disconnect/reconnect remains immediate;
   - Hive Milan dots appear without refreshing;
   - Milan Manager stays blue for more than 5 seconds;
   - Nebra changes from `Not available` to `Online`;
   - the Milan 1.2 logo, correct GM ID, CRF lock and dynamic mapping lines remain.
7. Save one FullDump at approximately 15 seconds and a second after two
   minutes. `FRAMES_RX` should now be visible to registered controllers and
   increase between observations while the stream is active.

## Rollback

If audio, CRF, discovery, Milan logo, mappings, or device stability regress,
return to `SABRE_9018_2_Channel_HYB4.111_LIVE_REPORTING_20260719.xe`.

This is a focused interoperability test revision, not an Avnu certification
claim.
