# SABRE 9018 2 Channel — HYB4.110 SRP Settlement

Firmware identity: `6.1.1-HYB4.110-SRPSET`

## Purpose

HYB4.110 is a controlled revision of HYB4.109. It retains the complete
HYB4.109 audio, 48 kHz FIFO-acquisition, CRF, channel mapping, AEM and Milan
compatibility paths. It changes only the listener's first MSRP/SRP settlement
and the corresponding `GET_STREAM_INFO` dynamic report.

The important observation behind this revision is that HYB4.109 reconnects
immediately after it has acquired the stream once, while its first connection
can take roughly 15 seconds to produce audio and about one minute to become
fully stable. This points to first SRP/PAAD settlement rather than a persistent
DAC or FIFO fault.

## Changes from HYB4.109

- The listener obtains the matching live MSRP Talker Advertise/Talker Failed
  information from the SRP participant when the sink is activated.
- The ACMP-selected Stream ID, destination MAC and VLAN remain authoritative;
  the revision copies only genuine SRP TSpec, accumulated-latency and failure
  information.
- `MSRP_ACC_LAT_VALID` now means that a matching MSRP attribute is present. It
  no longer depends on the numeric accumulated latency being non-zero.
- A connected listener without a matching MSRP attribute explicitly reports
  `NOT_REGISTERING_SRP`.
- Milan `flags_ex REGISTERING` is emitted only when the listener is genuinely
  registering the matching MSRP attribute. Probing status remains `completed`
  for a settled ACMP connection.
- No Grandmaster ID, device MAC, Stream ID, multicast destination or switch
  identity is hardcoded.

## Build verification

- Built with XMOS xTIMEcomposer Community 14.4.1.
- Both tile constraint checks passed.
- Firmware version string verified in the generated `.xe`.
- Source audit found no device-specific or Grandmaster-specific IDs.

## Test sequence

Use the same JOYNED AS1-EVK network and the same AAF/CRF talkers used for the
HYB4.109 reference.

1. Flash HYB4.110 and power-cycle the SABRE device once.
2. Start Hive, Milan Manager and Nebra before making either connection.
3. Connect CRF, then connect AAF. Record the time at:
   - 15 seconds,
   - first audible output,
   - stable two-channel output,
   - 2 minutes.
4. Take a FullDump at 15 seconds and another at 2 minutes.
5. At the same two points take screenshots of:
   - Hive matrix, Milan 1.2 logo/dots, GM ID and MCR lock,
   - Milan Manager connection colour and event log,
   - Nebra Network Status and Audio Status.
6. Disconnect only the AAF stream and reconnect it. Time this separately. The
   HYB4.109 reference is immediate reconnection, so HYB4.110 must not regress.
7. Confirm audio level and channel balance against HYB4.109; this revision has
   no gain or sample-processing change.

## Acceptance criteria

- Audio and CRF remain normal and bit-transparent as in HYB4.109.
- First audio and stable stereo occur materially sooner than the HYB4.109
  reference.
- AAF reconnect remains immediate.
- Hive keeps the Milan 1.2 logo/dots and correct live GM ID.
- Milan Manager does not change a valid connection from blue to red after its
  approximately five-second grace interval.
- Nebra no longer changes Network Status to `Not available` while continuing
  to report Audio Status `Ready`.
- No new unlock, reset, sequence-mismatch, interrupted, unsupported-format,
  early-timestamp or late-timestamp counters appear.

## Rollback

If audio, CRF, Milan discovery, mappings or immediate reconnection regress,
return to `SABRE_9018_2_Channel_HYB4.109_FIFO48_ACQUISITION_20260719.xe`.
