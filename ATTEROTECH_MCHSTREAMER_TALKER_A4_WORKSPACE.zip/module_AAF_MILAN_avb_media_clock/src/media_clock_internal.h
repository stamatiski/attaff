#ifndef __media_clock_internal_h__
#define __media_clock_internal_h__
#include <xccompat.h>
#include "media_clock_server.h"

/** A description of a media clock */
typedef struct media_clock_t {
  media_clock_info_t info;
  unsigned int wordLength;
  unsigned int baseLengthRemainder;
  unsigned int wordTime;
  unsigned int baseLength;
  unsigned int lowBits;
  int count;
  unsigned int next_event;
  unsigned int bit;
} media_clock_t;


#define WC_FRACTIONAL_BITS 16

// The number of ticks to wait before trying to get initial lock
#define INITIAL_CLOCK_RECOVERY_DELAY (1<<26)

// The number of ticks between period clock recovery checks
#define CLOCK_RECOVERY_SLOW_PERIOD  300000000
#define CLOCK_RECOVERY_PERIOD  (1<<21)

// The number of samples the buffer can deviate from the fill point
// over the recovery period to allow a lock
#define ACCEPTABLE_LOCKED_FILL_DEVIATION 20

void init_media_clock_recovery(NULLABLE_RESOURCE(chanend,ptp_svr),
                                       int clock_info,
                                       unsigned int clk_time,
                                       unsigned int rate);

unsigned int update_media_clock(NULLABLE_RESOURCE(chanend,ptp_svr),
                                int clock_index,
                                REFERENCE_PARAM(const media_clock_t, mclock),
                                unsigned int t2,
                                int period);


void update_media_clock_stream_info(int clock_index,
                                    unsigned int local_ts,
                                    unsigned int outgoing_ptp_ts,
                                    unsigned int presentation_ts,
                                    int locked,
                                    int fill);

void inform_media_clock_of_lock(int clock_index);
int update_media_clock_crf_info(int clock_index, unsigned timestamp_hi,
                                 unsigned timestamp_lo,
                                 unsigned timestamp_interval, unsigned rate,
                                 int inv_ptp_adjust);
int invalidate_media_clock_crf(int clock_index);
void media_clock_get_crf_timestamp(int clock_index, unsigned now_hi,
                                   unsigned now_lo, unsigned rate,
                                   REFERENCE_PARAM(unsigned, timestamp_hi),
                                   REFERENCE_PARAM(unsigned, timestamp_lo),
                                   REFERENCE_PARAM(unsigned, timestamp_interval));
#ifdef __XC__
void clock_recovery_maintain_buffer(chanend buf_info,
		chanend ptp_server,
			         int &locked,
			         int &balance,
			         int &fill_level,
			        unsigned int &t);
#else
void clock_recovery_maintain_buffer(chanend buf_info,
		chanend ptp_server,
			         int *locked,
			         int *balance,
			         int *fill_level,
			         unsigned int *t);
#endif

void ptp_get_local_time_info_mod64(REFERENCE_PARAM(ptp_time_info_mod64,info));


#endif
