/**
 * \file media_clock_support.c
 * \brief C functions for the media clock
 *
 * The copyrights, all other intellectual and industrial
 * property rights are retained by XMOS and/or its licensors.
 * Terms and conditions covering the use of this code can
 * be found in the Xmos End User License Agreement.
 *
 * Copyright XMOS Ltd 2010
 *
 * In the case where this code is a modification of existing code
 * under a separate license, the separate license terms are shown
 * below. The modifications to the code are still covered by the
 * copyright notice above.
 *
 **/
#include <xccompat.h>
#include <xscope.h>
#include "gptp.h"
#include "avb_1722_def.h"
#include "print.h"
#include "media_clock_internal.h"
#include "media_clock_client.h"
#include "misc_timer.h"

#define NANO_SECOND 1000000000

// The clock recovery internal representation of the worldlen.  More precision and range than the external
// worldlen representation.  The max percision is 26 bits before the PTP clock recovery multiplcation overflows
#define WORDLEN_FRACTIONAL_BITS 24
#define CRF_AGGREGATE_INTERVAL 48000
#define CRF_ESTIMATOR_EVENTS 4
#define CRF_TARGET_FILTER_SHIFT 3
#define CRF_TARGET_LIMIT_PPM 1000
#define CRF_AAF_GUARD_PPM 25
#define CRF_SERVO_MAX_STEP 2048ULL

/**
 *  \brief Records the state of the media stream
 *
 *  It is used by the stream based clock recovery to store stream state, and
 *  therefore work out deltas between the last clock recovery state and the
 *  current one
 */
typedef struct stream_info_t {
	int valid;
	unsigned int local_ts;
	unsigned int outgoing_ptp_ts;
	unsigned int presentation_ts;
	int locked;
	int fill;
} stream_info_t;

/**
 * \brief Records the state of the clock recovery for one media clock
 */
typedef struct clock_info_t {
	unsigned long long wordlen;
	long long ierror;
	unsigned int rate;
	int first;
	stream_info_t stream_info1;
	stream_info_t stream_info2;
	int crf_valid;
	unsigned int crf_timestamp_hi;
	unsigned int crf_timestamp_lo;
	unsigned int crf_interval;
	unsigned int crf_rate;
	unsigned int crf_good_count;
	int crf_seeded;
	unsigned long long crf_window_timestamp;
	unsigned int crf_window_intervals;
	unsigned int crf_window_count;
	unsigned long long crf_target_wordlen;
	int crf_target_ready;
} clock_info_t;

/// The array of media clock state structures
static clock_info_t clock_states[AVB_NUM_MEDIA_CLOCKS];

/**
 * \brief Converts the internal 64 bit wordlen into an external 32 bit wordlen
 */
static unsigned int local_wordlen_to_external_wordlen(unsigned long long w) {
	return (w >> (WORDLEN_FRACTIONAL_BITS - WC_FRACTIONAL_BITS));
}

void init_media_clock_recovery(chanend ptp_svr,
							   int clock_num,
							   unsigned int clk_time,
							   unsigned int rate) {
	clock_info_t *clock_info = &clock_states[clock_num];

	clock_info->first = 1;
	clock_info->rate = rate;
	clock_info->ierror = 0;
	if (rate != 0) {
		clock_info->wordlen = ((100000000LL << WORDLEN_FRACTIONAL_BITS) / clock_info->rate);
	} else {
		clock_info->wordlen = 0;
	}

	clock_info->stream_info1.valid = 0;
	clock_info->stream_info2.valid = 0;
	clock_info->crf_valid = 0;
	clock_info->crf_good_count = 0;
	clock_info->crf_seeded = 0;
	clock_info->crf_window_intervals = 0;
	clock_info->crf_window_count = 0;
	clock_info->crf_target_wordlen = clock_info->wordlen;
	clock_info->crf_target_ready = 0;
}

int update_media_clock_crf_info(int clock_index, unsigned timestamp_hi,
                                 unsigned timestamp_lo,
                                 unsigned timestamp_interval, unsigned rate,
                                 int inv_ptp_adjust)
{
	clock_info_t *clock_info = &clock_states[clock_index];
	/* HYB3 derives a slow, filtered DAC-clock target from CRF.  It deliberately
	 * avoids packet-by-packet steering; the AAF loop later supplies only a small,
	 * bounded phase correction around this long-term target. */
	unsigned long long timestamp = ((unsigned long long)timestamp_hi << 32) |
	                              timestamp_lo;
	int was_valid = clock_info->crf_valid;
	int format_valid = (rate == 48000 && timestamp_interval == CRF_AGGREGATE_INTERVAL);
	int timing_valid = 0;

	if (!format_valid) {
		clock_info->crf_valid = 0;
		clock_info->crf_seeded = 0;
		clock_info->crf_good_count = 0;
		clock_info->crf_window_intervals = 0;
		clock_info->crf_window_count = 0;
		clock_info->crf_target_ready = 0;
		return was_valid ? -1 : 0;
	}

	if (clock_info->crf_seeded && rate == clock_info->crf_rate) {
		unsigned long long previous =
			((unsigned long long)clock_info->crf_timestamp_hi << 32) |
			clock_info->crf_timestamp_lo;
		unsigned long long delta_ns = timestamp - previous;
		unsigned long long expected_ns =
			((unsigned long long)timestamp_interval * 1000000000ULL) / rate;
		if (delta_ns > expected_ns - expected_ns / 10 &&
		    delta_ns < expected_ns + expected_ns / 10) {
			timing_valid = 1;
		}
	}
	if (timing_valid) {
		if (clock_info->crf_good_count < 8) clock_info->crf_good_count++;
		clock_info->crf_window_intervals += timestamp_interval;
		clock_info->crf_window_count++;
		/* A one-second window suppresses packet scheduling noise before CRF is
		 * allowed to influence the DAC clock. */
		if (clock_info->crf_window_count >= CRF_ESTIMATOR_EVENTS) {
			unsigned long long window_ns = timestamp - clock_info->crf_window_timestamp;
			long long correction = ((long long)window_ns * inv_ptp_adjust) >> 30;
			long long adjusted_ns_signed = (long long)window_ns + correction;
			unsigned long long adjusted_ns = (unsigned long long)adjusted_ns_signed;
			unsigned long long recovered =
				((adjusted_ns << WORDLEN_FRACTIONAL_BITS) / 10ULL) /
				clock_info->crf_window_intervals;
			unsigned long long nominal =
				(100000000ULL << WORDLEN_FRACTIONAL_BITS) / rate;
			unsigned long long limit = nominal / (1000000 / CRF_TARGET_LIMIT_PPM);
			if (recovered > nominal - limit && recovered < nominal + limit) {
				if (!clock_info->crf_target_ready)
					/* Start at the stable AAF rate for a bumpless handover. */
					clock_info->crf_target_wordlen = clock_info->wordlen;
				else
					clock_info->crf_target_wordlen =
						(clock_info->crf_target_wordlen * ((1 << CRF_TARGET_FILTER_SHIFT) - 1)
						 + recovered) >> CRF_TARGET_FILTER_SHIFT;
				clock_info->crf_target_ready = 1;
			}
			clock_info->crf_window_timestamp = timestamp;
			clock_info->crf_window_intervals = 0;
			clock_info->crf_window_count = 0;
		}
	} else {
		/* A single delayed or missing packet only restarts the long-window
		 * estimate.  If already locked, keep the DAC clock undisturbed; true
		 * CRF loss is handled by the receive timeout in the clock server. */
		if (!was_valid) {
			clock_info->crf_good_count = 0;
			clock_info->crf_valid = 0;
		}
		clock_info->crf_window_timestamp = timestamp;
		clock_info->crf_window_intervals = 0;
		clock_info->crf_window_count = 0;
	}
	clock_info->crf_timestamp_hi = timestamp_hi;
	clock_info->crf_timestamp_lo = timestamp_lo;
	clock_info->crf_interval = timestamp_interval;
	clock_info->crf_rate = rate;
	clock_info->crf_seeded = 1;
	if (!was_valid && !timing_valid)
		clock_info->crf_window_timestamp = timestamp;
	if (clock_info->crf_good_count >= 8 && clock_info->crf_target_ready)
		clock_info->crf_valid = 1;
	if (!was_valid && clock_info->crf_valid) return 1;
	if (was_valid && !clock_info->crf_valid) return -1;
	return 0;
}

int invalidate_media_clock_crf(int clock_index)
{
	clock_info_t *clock_info = &clock_states[clock_index];
	int was_valid = clock_info->crf_valid;
	clock_info->crf_valid = 0;
	clock_info->crf_seeded = 0;
	clock_info->crf_good_count = 0;
	clock_info->crf_window_intervals = 0;
	clock_info->crf_window_count = 0;
	clock_info->crf_target_ready = 0;
	return was_valid;
}

void media_clock_get_crf_timestamp(int clock_index, unsigned now_hi,
                                   unsigned now_lo, unsigned rate,
                                   unsigned *timestamp_hi,
                                   unsigned *timestamp_lo,
                                   unsigned *timestamp_interval)
{
	clock_info_t *clock_info = &clock_states[clock_index];
	unsigned interval = 96;
	unsigned long long now = ((unsigned long long)now_hi << 32) | now_lo;
	unsigned long long period_ns = 2000000ULL;
	unsigned long long timestamp;
	if (clock_info->crf_valid && clock_info->crf_rate == rate) {
		timestamp = ((unsigned long long)clock_info->crf_timestamp_hi << 32) |
		            clock_info->crf_timestamp_lo;
		while (timestamp <= now + period_ns) timestamp += period_ns;
	} else {
		timestamp = ((now + (2 * period_ns) - 1) / period_ns) * period_ns;
	}
	*timestamp_hi = (unsigned)(timestamp >> 32);
	*timestamp_lo = (unsigned)timestamp;
	*timestamp_interval = interval;
}

void update_media_clock_stream_info(int clock_index,
                                    unsigned int local_ts,
                                    unsigned int outgoing_ptp_ts,
                                    unsigned int presentation_ts,
                                    int locked,
                                    int fill) {
	clock_info_t *clock_info = &clock_states[clock_index];

	clock_info->stream_info2.local_ts = local_ts;
	clock_info->stream_info2.outgoing_ptp_ts = outgoing_ptp_ts;
	clock_info->stream_info2.presentation_ts = presentation_ts;
	clock_info->stream_info2.valid = 1;
	clock_info->stream_info2.locked = locked;
	clock_info->stream_info2.fill = fill;
}

void inform_media_clock_of_lock(int clock_index) {
	clock_info_t *clock_info = &clock_states[clock_index];
	clock_info->stream_info2.valid = 0;
}

#define MAX_ERROR_TOLERANCE 100

unsigned int update_media_clock(chanend ptp_svr,
								int clock_index,
								const media_clock_t *mclock,
								unsigned int t2,
								int period0) {
	clock_info_t *clock_info = &clock_states[clock_index];
	long long diff_local;
	int clock_type = mclock->info.clock_type;

	switch (clock_type) {
	case LOCAL_CLOCK:
		return local_wordlen_to_external_wordlen(clock_info->wordlen);
		break;

#ifndef MEDIA_CLOCK_EXCLUDE_STREAM_DERIVED
	case INPUT_STREAM_DERIVED: {
		long long ierror, perror, proposed;
		unsigned long long guard, lower, upper;

		// If the stream info isn't valid at all, then return the default clock rate
		if (!clock_info->stream_info2.valid)
			return local_wordlen_to_external_wordlen(clock_info->wordlen);

		// If there are not two stream infos to compare, then return default clock rate
		if (!clock_info->stream_info1.valid) {
			clock_info->stream_info1 = clock_info->stream_info2;
			clock_info->stream_info2.valid = 0;
			return local_wordlen_to_external_wordlen(clock_info->wordlen);
		}

		// If the stream is unlocked, return the default clock rate
		if (!clock_info->stream_info2.locked) {
			if (clock_info->crf_valid) {
				proposed = (long long)clock_info->crf_target_wordlen;
				if ((unsigned long long)proposed > clock_info->wordlen + CRF_SERVO_MAX_STEP)
					clock_info->wordlen += CRF_SERVO_MAX_STEP;
				else if ((unsigned long long)proposed + CRF_SERVO_MAX_STEP < clock_info->wordlen)
					clock_info->wordlen -= CRF_SERVO_MAX_STEP;
				else
					clock_info->wordlen = (unsigned long long)proposed;
			} else {
				clock_info->wordlen = ((100000000LL << WORDLEN_FRACTIONAL_BITS)
						/ clock_info->rate);
			}
			clock_info->stream_info1 = clock_info->stream_info2;
			clock_info->stream_info2.valid = 0;
			clock_info->first = 1;
			clock_info->ierror = 0;

		// We have all the info we need to perform clock recovery
		} else {
			diff_local = clock_info->stream_info2.local_ts
					- clock_info->stream_info1.local_ts;

			ierror = (signed) clock_info->stream_info2.outgoing_ptp_ts -
					 (signed) clock_info->stream_info2.presentation_ts;

			ierror = ierror << WORDLEN_FRACTIONAL_BITS;

			if (clock_info->first) {
				perror = 0;
				clock_info->first = 0;
			} else
				perror = ierror - clock_info->ierror;

			clock_info->ierror = ierror;

#if PLL_TYPE_CS2300
			proposed = (long long)clock_info->wordlen
				- ((perror / diff_local) * 32) - ((ierror / diff_local) / 4);
#else
			proposed = (long long)clock_info->wordlen
				- ((perror / diff_local) * 80)/11 - ((ierror / diff_local) * 1) / 5;
#endif
			if (clock_info->crf_valid) {
				/* CRF defines the long-term center.  AAF may correct phase only
				 * inside a narrow guard band, and the PLL command is always slewed. */
				guard = clock_info->crf_target_wordlen / (1000000 / CRF_AAF_GUARD_PPM);
				lower = clock_info->crf_target_wordlen - guard;
				upper = clock_info->crf_target_wordlen + guard;
				if (proposed < (long long)lower) proposed = (long long)lower;
				if (proposed > (long long)upper) proposed = (long long)upper;
				if ((unsigned long long)proposed > clock_info->wordlen + CRF_SERVO_MAX_STEP)
					clock_info->wordlen += CRF_SERVO_MAX_STEP;
				else if ((unsigned long long)proposed + CRF_SERVO_MAX_STEP < clock_info->wordlen)
					clock_info->wordlen -= CRF_SERVO_MAX_STEP;
				else
					clock_info->wordlen = (unsigned long long)proposed;
			} else {
				clock_info->wordlen = (unsigned long long)proposed;
			}
			xscope_longlong(MEDIA_CLOCK_WORDLEN, clock_info->wordlen);
			xscope_longlong(MEDIA_CLOCK_IERROR, clock_info->ierror);
			xscope_longlong(MEDIA_CLOCK_PERROR, perror);

			clock_info->stream_info1 = clock_info->stream_info2;
			clock_info->stream_info2.valid = 0;
		}
		break;
	}
#endif

		break;
	}

	return local_wordlen_to_external_wordlen(clock_info->wordlen);
}
