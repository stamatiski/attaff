#ifndef __avb_conf_h__
#define __avb_conf_h__

#include "app_config.h"
#include "avb_1722_def.h"
/* Some of the configuration depends on the app_config.h file included above */

/******** ETHERNET MAC CONFIGURATION PARAMETERS *************************************************/
#define ETHERNET_DEFAULT_IMPLEMENTATION full

#define MAX_ETHERNET_PACKET_SIZE (1518)
#define NUM_MII_RX_BUF 6
#define NUM_MII_TX_BUF 3
#define ETHERNET_RX_HP_QUEUE 1
#define ETHERNET_TX_HP_QUEUE 1
#define MAX_ETHERNET_CLIENTS   4

#define ETHERNET_MAX_TX_HP_PACKET_SIZE (AVB_ETHERNET_HDR_SIZE + AVB_TP_HDR_SIZE + AVB_CIP_HDR_SIZE + 192*4 + 4)
#define ETHERNET_MAX_TX_LP_PACKET_SIZE (600)

#define MII_RX_BUFSIZE_HIGH_PRIORITY (1100 + (3*(ETHERNET_MAX_TX_HP_PACKET_SIZE)))
#define MII_RX_BUFSIZE_LOW_PRIORITY (2000)

#define MII_TX_BUFSIZE_HIGH_PRIORITY (1100 + (3*(ETHERNET_MAX_TX_HP_PACKET_SIZE)))
#define MII_TX_BUFSIZE_LOW_PRIORITY (2000)

#define NUM_ETHERNET_PORTS 1
#define NUM_ETHERNET_MASTER_PORTS 1

#define ETHERNET_RX_ENABLE_TIMER_OFFSET_REQ 1

/******** ENDPOINT AUDIO AND CLOCKING PARAMETERS ************************************************/

/* Talker configuration */
#if AVB_DEMO_ENABLE_TALKER

/** The total number of AVB sources (streams that are to be transmitted). */
#define AVB_NUM_SOURCES 1
/** The total number or Talker components (typically the number of
  * tasks running the  :c:func:`avb_1722_talker` function). */
#define AVB_NUM_TALKER_UNITS 1
/** The total number of media inputs (typically number of I2S input channels). */
#define AVB_NUM_MEDIA_INPUTS 1
/** Enable the 1722.1 Talker functionality */
#define AVB_1722_1_TALKER_ENABLED 1

#else

#define AVB_NUM_SOURCES 0
#define AVB_NUM_TALKER_UNITS 0
#define AVB_NUM_MEDIA_INPUTS 0
#define AVB_1722_1_TALKER_ENABLED 0

#endif

/* Listener configuration */
#if AVB_DEMO_ENABLE_LISTENER

/** The total number of AVB sinks (incoming streams that can be listened to) */
#define AVB_NUM_SINKS 1
/** The total number or listener components
  * (typically the number of tasks running the  :c:func:`avb_1722_listener` function) */
#define AVB_NUM_LISTENER_UNITS 1
/** The total number of media outputs (typically the number of I2S output channels). */
#define AVB_NUM_MEDIA_OUTPUTS 1
/** Enable the 1722.1 Listener functionality */
#define AVB_1722_1_LISTENER_ENABLED 1

#else

#define AVB_NUM_SINKS 0
#define AVB_NUM_LISTENER_UNITS 0
#define AVB_NUM_MEDIA_OUTPUTS 0
#define AVB_1722_1_LISTENER_ENABLED 0

#endif

/** The maximum number of channels permitted per 1722 Talker stream */
#define AVB_MAX_CHANNELS_PER_TALKER_STREAM 1
/** The maximum number of channels permitted per 1722 Listener stream */
#define AVB_MAX_CHANNELS_PER_LISTENER_STREAM 1

/** Enable combination of the media clock server and PTP server in a single core */
#define COMBINE_MEDIA_CLOCK_AND_PTP 1

/** Use 61883-4 MPEG-TS format for 1722 streams */
#define AVB_1722_FORMAT_61883_4 1

/** The number of components in the endpoint that will register and initialize media FIFOs
    (typically an audio interface component such as I2S). */
#define AVB_NUM_MEDIA_UNITS 1

/** The number of media clocks in the endpoint. Typically the number of clock domains, each with a
  * separate PLL and master clock. */
#define AVB_NUM_MEDIA_CLOCKS 0


/******** 1722.1 PARAMETERS *****************************************************************/

/** Enable 1722.1 AVDECC on the entity */
#define AVB_ENABLE_1722_1 1

#define AVB_1722_1_ADP_ENTITY_CAPABILITIES (AVB_1722_1_ADP_ENTITY_CAPABILITIES_AEM_SUPPORTED| \
                                            AVB_1722_1_ADP_ENTITY_CAPABILITIES_CLASS_A_SUPPORTED| \
                                            AVB_1722_1_ADP_ENTITY_CAPABILITIES_GPTP_SUPPORTED| \
                                            AVB_1722_1_ADP_ENTITY_CAPABILITIES_AEM_IDENTIFY_CONTROL_INDEX_VALID)

#if AVB_1722_1_TALKER_ENABLED
#define AVB_1722_1_ADP_TALKER_CAPABILITIES (AVB_1722_1_ADP_TALKER_CAPABILITIES_IMPLEMENTED|AVB_1722_1_ADP_TALKER_CAPABILITIES_VIDEO_SOURCE)
#else
#define AVB_1722_1_ADP_TALKER_CAPABILITIES 0
#endif

#if AVB_1722_1_LISTENER_ENABLED
#define AVB_1722_1_ADP_LISTENER_CAPABILITIES (AVB_1722_1_ADP_LISTENER_CAPABILITIES_IMPLEMENTED|AVB_1722_1_ADP_LISTENER_CAPABILITIES_VIDEO_SINK)
#else
#define AVB_1722_1_ADP_LISTENER_CAPABILITIES 0
#endif

#define AVB_1722_1_ADP_MODEL_ID 0x1234

enum aem_control_indices {
    DESCRIPTOR_INDEX_CONTROL_IDENTIFY = 0,
};

/** Enable 1722.1 Controller functionality on the entity. */
#define AVB_1722_1_CONTROLLER_ENABLED 1


/** Enable SRP auto-start and auto-stop a stream when Listeners come and go */
#define SRP_AUTO_TALKER_STREAM_CONTROL 1

#endif
