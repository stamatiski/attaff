# SABRE 9018 2 Channel — HYB4.114 AEM Name Response

Date: 2026-07-19

Firmware identity: `6.1.1-HYB4.114-AEM-NAME`

## Purpose

HYB4.113 proved that AAF audio, CRF-to-DAC clocking, gPTP, Milan discovery,
dynamic mappings, per-unit identity and reconnection were healthy. Nebra still
reported both units as `Network Status: Not available` because it repeatedly
sent AEM `GET_NAME` and received no AECP response.

HYB4.114 corrects that control-plane omission without changing the media path.

## Changes from HYB4.113

- Dispatches IEEE 1722.1 AEM `GET_NAME` and `SET_NAME` commands.
- Parses `descriptor_type`, `descriptor_index`, `name_index` and
  `configuration_index` in network byte order.
- Returns the required 72-byte implemented-command response shape: the 8-byte
  selector plus a 64-byte fixed string.
- Supports entity name index 0, entity group name index 1, and object name
  index 0 for named descriptors.
- Uses one authoritative writable name store for synthesized CRF/AAF stream
  names and the eight audio-cluster/channel names, so `SET_NAME`, `GET_NAME`
  and `READ_DESCRIPTOR` remain mutually consistent.
- Returns explicit `BAD_ARGUMENTS`, `NO_SUCH_DESCRIPTOR`, `NOT_SUPPORTED` or
  `ENTITY_ACQUIRED` status for invalid/unauthorized targets instead of timing
  out.
- Retains HYB4.113 per-unit entity-name suffixes such as `[36:E1]` and
  `[F2:20]` after boot.

## Deliberately unchanged

- Listener-only operation, 48 kHz, eight-channel AAF.
- CRF input and CRF-to-DAC media-clock path.
- Bit-exact unity/bypass audio path and DSP configuration.
- gPTP/BMCA behavior and live Grandmaster reporting.
- MSRP/ACMP, Milan advertisement, dynamic mappings and unsolicited reporting.
- Stream formats, stream indices, channel routing, device model and MAC/entity
  identity construction.

The source comparison against HYB4.113 contains only two functional source
differences: the firmware version string and `avb_1722_1_aecp.c`.

## Build verification

- xTIMEcomposer/XTC 14.4.1 build: PASS
- Tile 0: 43,644 / 65,536 bytes
- Tile 1: 64,456 / 65,536 bytes (1,080 bytes free)
- Timing analysis: PASS (the same legacy informational warnings remain)
- Embedded version string found in the final `.xe`: PASS

## First hardware test

Flash one SABRE device first and keep the other on HYB4.113 as the comparison
unit. After power-up:

1. Confirm audio and CRF lock in Hive.
2. Restart Nebra and wait at least 30 seconds.
3. Confirm the HYB4.114 unit remains `Network Status: Online` and
   `Audio Status: Ready`, with no enumeration remove/re-add cycle.
4. Confirm Milan 1.2 logo/dots, correct GM ID, dynamic mappings and mapping
   lines remain present.
5. Disconnect and reconnect AAF once; audio recovery should remain immediate.

If the media path regresses, restore HYB4.113. This revision is compiled and
resource-checked, but the new AECP transaction still requires this hardware
and Nebra validation.
