# HYB4.115 Nebra Clock-Graph Correction

Date: 2026-07-21

Firmware identity: `6.1.1-HYB4.115-NBR-CLK`

## Purpose

HYB4.115 is a deliberately narrow control-plane revision of the proven
HYB4.114 firmware. It corrects the AEM clock-source graph used by controllers
such as Nebra without changing the working audio or timing implementation.

## Changes from HYB4.114

- Corrects Clock Source 1 (`Internal Clock`) so its AEM location is Entity 0.
  HYB4.114 incorrectly located this internal source at Stream Input 0, the same
  input used by the CRF source.
- Keeps Clock Source 0 as the selected input-stream-derived CRF source at
  Stream Input 0.
- Changes the AEM model name shown by Nebra from `SABRE-9018-2CH` to
  `AVB-DG Stamatis`, as requested.
- Updates the firmware label to `6.1.1-HYB4.115-NBR-CLK`.
- Provides separate images with the established entity names
  `SABRE 9018 2 Channel` and `ESS SABRE 8 Channel`.

## Deliberately unchanged

- Listener-only, 48 kHz, eight-channel AAF operation.
- CRF reception, CRF-to-DAC media-clock implementation and isolation.
- gPTP/BMCA election and live Grandmaster reporting.
- Audio sample path, unity gain, channel order, word width and bit-exact
  behavior.
- Stream formats, stream indices, ACMP/MSRP, dynamic mappings, Milan
  advertisement, reconnection and GET/SET_NAME handling.
- No DSP, dither, gain, buffering or packet-processing change.

## Build verification

Built cleanly with xTIMEcomposer/XTC 14.4.1.

- Tile 0: 43,644 / 65,536 bytes.
- Tile 1: 64,456 / 65,536 bytes (1,080 bytes free).
- Core, timer and channel-end constraints: PASS.
- Timing analysis: PASS; only the same legacy informational warnings remain.
- Compiled firmware version, model name and entity-name variants were found
  in the final XE images.

## First hardware validation

Test one device first and retain HYB4.114 as the fallback.

1. Flash the image matching the desired entity name.
2. Restart or refresh Hive, Milan Manager and Nebra so their AEM caches read
   the corrected descriptor.
3. Confirm the Milan 1.2 logo/dots, correct GM ID, green connections, dynamic
   mappings and mapping lines.
4. Connect CRF and AAF and confirm immediate, clean audio.
5. Confirm CRF `FRAMES_RX` advances and MCR remains locked.
6. In Nebra, confirm model `AVB-DG Stamatis`, Network Status Online, Audio
   Status Ready, and inspect the log for disappearance of:
   - `ClockFormat is none`
   - `currentSourceClock is nullptr`
7. Disconnect/reconnect AAF once and verify immediate recovery.

This build is compile- and descriptor-verified, but the Nebra behavior requires
hardware validation. If audio, CRF, Milan discovery or reconnection regresses,
restore HYB4.114 and provide fresh FullDump, Hive, Milan Manager and Nebra logs.

