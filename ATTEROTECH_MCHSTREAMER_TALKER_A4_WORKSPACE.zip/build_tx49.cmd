@echo off
call "C:\Program Files (x86)\XMOS\xTIMEcomposer\Community_14.4.1\SetEnv.bat"
if errorlevel 1 exit /b %errorlevel%
xmake -C ATTEROTECH_MCHSTREAMER_TALKER clean all
exit /b %errorlevel%
