#include <xccompat.h>
#include <print.h>
#include <string.h>
#include "debug_print.h"
#include "avb.h"
#include "avb_conf.h"
#include "avb_1722_common.h"
#include "avb_1722_maap.h"
#include "avb_1722_maap_protocol.h"
#include "avb_1722_1_adp.h"
#include "avb_1722_1_acmp.h"
#include "avb_control_types.h"

static int acmp_talker_initialized = 0;

void avb_talker_on_source_address_reserved_default(client interface avb_interface avb, int source_num, unsigned char mac_addr[6])
{
  // Do some debug print
  debug_printf("MAAP reserved Talker stream #%d address: %x:%x:%x:%x:%x:%x\n", source_num,
                            mac_addr[0],
                            mac_addr[1],
                            mac_addr[2],
                            mac_addr[3],
                            mac_addr[4],
                            mac_addr[5]);

  unsigned char old_mac_addr[6];
  int old_mac_addr_len = 0;
  enum avb_source_state_t previous_state = AVB_SOURCE_STATE_DISABLED;
  int have_previous_state = avb.get_source_state(source_num, previous_state);
  int have_old_mac_addr = avb.get_source_dest(source_num, old_mac_addr, old_mac_addr_len);
  int destination_changed = !have_old_mac_addr ||
                            old_mac_addr_len != 6 ||
                            memcmp(old_mac_addr, mac_addr, 6) != 0;

  /*
   * set_source_dest() is intentionally accepted only while the source is
   * disabled.  A MAAP reallocation can happen after an ACMP connection has
   * already moved the source to POTENTIAL or ENABLED.  Re-arm that source so
   * its SRP reservation and the Ethernet packetizer are rebuilt with exactly
   * the same address that ACMP advertises.
   */
  if (destination_changed &&
      have_previous_state &&
      previous_state != AVB_SOURCE_STATE_DISABLED) {
    avb.set_source_state(source_num, AVB_SOURCE_STATE_DISABLED);
  }

  if (destination_changed && !avb.set_source_dest(source_num, mac_addr, 6)) {
    debug_printf("Unable to apply MAAP address to Talker stream #%d\n", source_num);
    if (have_previous_state && previous_state != AVB_SOURCE_STATE_DISABLED) {
      avb.set_source_state(source_num, AVB_SOURCE_STATE_POTENTIAL);
    }
    return;
  }

  /* NOTE: acmp_talker_init() must be called BEFORE talker_set_mac_address() otherwise it will zero
   * what was just set */
  if (!acmp_talker_initialized) {
    avb_1722_1_acmp_talker_init();
    acmp_talker_initialized = 1;
  }
  avb_1722_1_talker_set_mac_address(source_num, mac_addr);

  /*
   * A newly addressed source must be armed before MSRP can promote it.
   * SRP's Listener Ready handler intentionally enables only POTENTIAL sources;
   * leaving the cold-start source DISABLED therefore creates an AEM/ACMP
   * connection with no TALKER_GO command and no AVTP packets.  POTENTIAL only
   * configures the packetizer and advertises the reservation.  It does not
   * transmit until Listener Ready performs the standards-defined transition
   * to ENABLED.
   *
   * Also re-arm an active source after a genuine MAAP address change.  Do not
   * disturb an already armed/running source when MAAP repeats the same address.
   */
  if (have_previous_state &&
      (destination_changed || previous_state == AVB_SOURCE_STATE_DISABLED)) {
    avb.set_source_state(source_num, AVB_SOURCE_STATE_POTENTIAL);
  }

  avb_1722_1_adp_announce();
}
