# SABRE 9018 2 Channel - HYB4.111 Live Reporting

Firmware identity: `6.1.1-HYB4.111-LIVEREP`

## Purpose

HYB4.111 is a reporting-only revision of HYB4.110. It preserves the working
48 kHz AAF, CRF, FIFO, channel-mapping, I2S/DAC and bit-transparent sample path.
It addresses the remaining contradiction in which audio starts and reconnects
normally, while Milan Manager changes the route from blue to red and the AEM
dump continues to report zero received frames or stale SRP state.

## Changes from HYB4.110

- The listener refreshes the matching live MSRP Talker state every 250 ms.
  This covers the normal case in which Talker Advertise arrives after the ACMP
  connection is accepted.
- SRP TSpec, accumulated-latency and failure fields are cleared at each new
  ACMP connection and then learned from the matching live MSRP attribute.
- ACMP remains authoritative for Stream ID, multicast destination and VLAN.
- AEM `GET_COUNTERS` now uses the standard IEEE 1722.1/Milan STREAM_INPUT bit
  assignments and block positions.
- `FRAMES_RX`, media-lock, interruption, reset, sequence-mismatch,
  timestamp-uncertain and unsupported-format values are genuine listener
  counters. Late/early timestamp counters are advertised in their standard
  positions and remain zero because this listener does not currently detect
  those events.
- No Grandmaster ID, talker identity, Stream ID, multicast address or switch
  identity is hardcoded.

## Unchanged functional path

- Listener-only operation at 48 kHz.
- Input 0: CRF; Input 1: eight-channel AAF.
- CRF-isolated media-clock architecture and DAC/I2S clock path.
- Audio sample words, channel order, gain and DSP behavior.
- Device name: `SABRE 9018 2 Channel`.

## Build verification

- Built with XMOS xTIMEcomposer Community 14.4.1.
- Tile 0: 7/8 cores, 8/10 timers, 23/32 chanends, 43,644/65,536 bytes.
- Tile 1: 6/8 cores, 7/10 timers, 22/32 chanends, 60,992/65,536 bytes.
- Both tile constraint checks passed.
- Firmware identity and device name were verified inside the generated image.
- The live-source audit found no old device-specific Grandmaster or talker IDs.

## Hardware test sequence

1. Flash HYB4.111 and power-cycle the SABRE device once.
2. Start Hive, Milan Manager and Nebra.
3. Connect CRF from the same media-clock domain, then connect the AAF stream.
4. Confirm first audio remains near the HYB4.110 result (about five seconds)
   and that AAF reconnection remains immediate.
5. Leave Milan Manager and Nebra open for at least 30 seconds. Check whether
   the route stays blue and Nebra remains Online rather than changing after its
   five-second grace interval.
6. Take a FullDump at approximately 15 seconds and another at two minutes.
7. In both dumps inspect Input 1 `GET_COUNTERS`: `FRAMES_RX` must increase;
   sequence mismatch, unsupported format and interruption must not grow.
8. Confirm CRF lock, correct GM ID, dynamic mapping lines, Milan 1.2 logo/dots,
   balanced audio and normal output level.

## Acceptance and rollback

HYB4.111 is accepted only after the hardware checks above. The build verifies
the unchanged bit-transparent data path, but a capture or digital loopback is
still required to prove bit-exact operation on the physical system.

If audio, CRF, discovery, mapping or immediate reconnection regresses, return
to the known working HYB4.110 image.
