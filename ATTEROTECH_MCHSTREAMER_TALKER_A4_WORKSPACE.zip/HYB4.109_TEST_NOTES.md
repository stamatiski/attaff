# HYB4.109 48 kHz FIFO Acquisition - SABRE 9018

## Purpose

HYB4.109 is a narrowly scoped correction derived from HYB4.108 and the live
telemetry captured from device `00:50:C2:D4:36:E1`.

The diagnostic dump showed continuous valid AAF and CRF traffic but 171,235
pre-lock FIFO compensation resets before audio became audible. The inherited
acquisition guard reserved space for 12 samples per packet (the removed
96 kHz case). This 48 kHz-only listener receives six samples per AAF packet.
The old guard limited the 106-word FIFO to 94 samples, while the normal Milan
presentation offset requires approximately 96 samples.

## Changes

1. Derive maximum AAF packet samples from the fixed 48 kHz sample rate and
   8 kHz AVTP packet rate: six samples per channel.
2. Preserve one complete six-sample packet of FIFO write headroom while
   allowing the normal approximately 96-sample presentation fill.
3. Retain the original bounded adjustment and full-reset fallback for a
   genuinely unsafe compensation request.
4. Restore AAF public counters to their standards-valid stream semantics.
   Internal per-channel FIFO events are no longer reported as Milan stream
   lock or interruption/reset events.
5. Retain HYB4.108's corrected 82-byte Milan
   `GET_MEDIA_CLOCK_REFERENCE_INFO` vendor payload.

## Intentionally unchanged

- AAF audio samples, channel mapping, gain, scaling, dither and DSP behavior
- CRF estimator and CRF-to-DAC clock path
- gPTP/BMCA, SRP/MSRP, ACMP, VLAN and stream formats
- post-lock loss thresholds and recovery behavior
- entity name: `SABRE 9018 2 Channel`

## Flash image

- File: `SABRE_9018_2_Channel_HYB4.109_FIFO48_ACQUISITION_20260719.xe`
- Embedded firmware version: `6.1.1-HYB4.109-FIFO48`
- SHA-256: `1C4A5B91335058354C7AE366DEC992A6659A770665CF2C30A5C203663A0A708E`
- Clean build: xTIMEcomposer Community 14.4.1, completed without errors

## Controlled test

1. Keep the F2:20 control device on HYB4.107.
2. Flash HYB4.109 only to E1 and power-cycle E1.
3. Refresh Hive once after discovery.
4. Connect CRF and confirm MCR lock.
5. Connect AAF and time the interval until audio becomes audible.
6. Export a FullDump approximately 15 seconds after connection and another
   after 2 minutes.
7. Confirm the Milan 1.2 logo/dots remain after Hive refresh and that no
   invalid MEDIA_LOCKED/MEDIA_UNLOCKED compatibility event appears.
