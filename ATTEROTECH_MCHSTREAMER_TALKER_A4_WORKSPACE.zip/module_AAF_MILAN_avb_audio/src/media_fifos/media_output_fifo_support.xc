/*
 * @ModuleName Audio DAC/ADC FIFO Module.
 * @Description: Implements the Audio DAC controller.
 *
 *
 */

#include <xs1.h>
#include <xclib.h>
#include <print.h>
#include <stdlib.h>
#include <syscall.h>
#include <xscope.h>
#include "media_fifo.h"
#include "app_config.h"

#if AVB_LISTENER_DSP_ENABLE
#define DSP_CHANNELS 8
#define DSP_SIGNAL_FRAC 8
#define DSP_COEFF_FRAC 28
#define DSP_UNITY (1 << DSP_COEFF_FRAC)

typedef struct listener_biquad_t {
  int b0, b1, b2, a1, a2;
  long long z1, z2;
} listener_biquad_t;

static listener_biquad_t dsp_biquad[DSP_CHANNELS][AVB_LISTENER_DSP_BIQUADS];
static int dsp_stage_count[DSP_CHANNELS];
static int dsp_gain[DSP_CHANNELS];
static int dsp_gain_target[DSP_CHANNELS];
static int dsp_delay[DSP_CHANNELS];
static int dsp_delay_pos[DSP_CHANNELS];
static int dsp_delay_line[DSP_CHANNELS][AVB_LISTENER_DSP_MAX_DELAY];
static unsigned dsp_rng[DSP_CHANNELS];
static int dsp_initialized;

static void listener_dsp_init(void)
{
  for (int ch = 0; ch < DSP_CHANNELS; ch++) {
    dsp_stage_count[ch] = 0; /* coefficient slots reserved, initially bypassed */
    dsp_gain[ch] = DSP_UNITY;
    dsp_gain_target[ch] = DSP_UNITY;
    dsp_delay[ch] = 0;
    dsp_delay_pos[ch] = 0;
    dsp_rng[ch] = 0x9e3779b9u ^ (0x1020304u * (ch + 1));
    for (int s = 0; s < AVB_LISTENER_DSP_BIQUADS; s++) {
      dsp_biquad[ch][s].b0 = DSP_UNITY;
      dsp_biquad[ch][s].b1 = 0;
      dsp_biquad[ch][s].b2 = 0;
      dsp_biquad[ch][s].a1 = 0;
      dsp_biquad[ch][s].a2 = 0;
      dsp_biquad[ch][s].z1 = 0;
      dsp_biquad[ch][s].z2 = 0;
    }
  }
  dsp_initialized = 1;
}

#if AVB_LISTENER_DSP_DITHER
static unsigned dsp_random(int ch)
{
  dsp_rng[ch] = dsp_rng[ch] * 1664525u + 1013904223u;
  return dsp_rng[ch];
}
#endif

static unsigned listener_dsp_process(unsigned raw, int ch)
{
  /* FIFO samples are right-aligned 24-bit two's-complement. */
  int x = ((int)(raw << 8)) >> 8;

  if (!dsp_initialized) listener_dsp_init();

  /* Transparent fast path.  With no gain change, filters, or delay, preserve
   * every input bit and avoid dither, rounding, and saturation entirely. */
  if (dsp_gain[ch] == DSP_UNITY &&
      dsp_gain_target[ch] == DSP_UNITY &&
      dsp_stage_count[ch] == 0 &&
      dsp_delay[ch] == 0)
    return raw & 0xffffff;

  long long v = ((long long)x) << DSP_SIGNAL_FRAC;

  /* Click-free gain/mute ramp.  Targets can later be exposed through AEM. */
  dsp_gain[ch] += (dsp_gain_target[ch] - dsp_gain[ch]) >> 10;
  v = (v * dsp_gain[ch]) >> DSP_COEFF_FRAC;

  for (int s = 0; s < dsp_stage_count[ch]; s++) {
    listener_biquad_t *b = &dsp_biquad[ch][s];
    long long acc = ((long long)b->b0 * v) + b->z1;
    long long y = acc >> DSP_COEFF_FRAC;
    b->z1 = ((long long)b->b1 * v) - ((long long)b->a1 * y) + b->z2;
    b->z2 = ((long long)b->b2 * v) - ((long long)b->a2 * y);
    v = y;
  }

  if (dsp_delay[ch]) {
    int pos = dsp_delay_pos[ch];
    int delayed = dsp_delay_line[ch][pos];
    dsp_delay_line[ch][pos] = (int)v;
    pos++;
    if (pos >= dsp_delay[ch]) pos = 0;
    dsp_delay_pos[ch] = pos;
    v = delayed;
  }

  /* Saturate in the guarded domain before reducing to the DAC's 24 bits. */
  if (v > (((long long)0x7fffff) << DSP_SIGNAL_FRAC))
    v = ((long long)0x7fffff) << DSP_SIGNAL_FRAC;
  if (v < -(((long long)0x800000) << DSP_SIGNAL_FRAC))
    v = -((long long)0x800000) << DSP_SIGNAL_FRAC;

#if AVB_LISTENER_DSP_DITHER
  /* TPDF dither: difference of two independent 8-bit uniform variables. */
  unsigned random_a = dsp_random(ch);
  unsigned random_b = dsp_random(ch);
  v += (int)(random_a >> 24) - (int)(random_b >> 24);
#endif
  /* Symmetric round-to-nearest for future fractional DSP.  This avoids the
   * negative half-LSB bias of an arithmetic right-shift quantizer. */
  long long q;
  if (v >= 0)
    q = (v + (1LL << (DSP_SIGNAL_FRAC - 1))) >> DSP_SIGNAL_FRAC;
  else
    q = -(((-v) + (1LL << (DSP_SIGNAL_FRAC - 1))) >> DSP_SIGNAL_FRAC);
  if (q > 0x7fffff) q = 0x7fffff;
  if (q < -0x800000) q = -0x800000;
  return ((unsigned)q) & 0xffffff;
}
#endif

void media_output_fifo_to_xc_channel(streaming chanend samples_out,
                                     media_output_fifo_t output_fifos[],
                                     int num_channels)
{
  while (1) {
    unsigned int size;
    unsigned timestamp;
    samples_out :> timestamp;
    for (int i=0;i<num_channels;i++) {
      unsigned sample;
      sample = media_output_fifo_pull_sample(output_fifos[i],
                                             timestamp);
#if AVB_LISTENER_DSP_ENABLE
      sample = listener_dsp_process(sample, i);
#endif
      samples_out <: sample;

    }
  }
}


int mo_ts;
#pragma unsafe arrays
void
media_output_fifo_to_xc_channel_split_lr(streaming chanend samples_out,
                                         media_output_fifo_t output_fifos[],
                                         int num_channels)
{
  mo_ts = 0xbadf00d;

#ifdef XSCOPE_OUTPUT_FIFO_PULL
  xscope_register(1, XSCOPE_DISCRETE, "Media Output FIFO", XSCOPE_UINT, "Samples");
#endif

  while (1) {
    unsigned timestamp;
    samples_out :> timestamp;
    mo_ts = timestamp;
    for (int i=0;i<num_channels;i+=2) {
      unsigned sample;
      sample = media_output_fifo_pull_sample(output_fifos[i],
                                             timestamp);
#if AVB_LISTENER_DSP_ENABLE
      sample = listener_dsp_process(sample, i);
#endif
      samples_out <: sample;
    }
    for (int i=1;i<num_channels;i+=2) {
      unsigned sample;
      sample = media_output_fifo_pull_sample(output_fifos[i],
                                             timestamp);
#if AVB_LISTENER_DSP_ENABLE
      sample = listener_dsp_process(sample, i);
#endif
      samples_out <: sample;
    }
  }
}
