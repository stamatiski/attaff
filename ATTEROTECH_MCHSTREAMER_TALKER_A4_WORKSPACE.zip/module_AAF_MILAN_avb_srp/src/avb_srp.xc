#include <debug_print.h>
#include "avb.h"
#include "avb_api.h"
#include "avb_mrp.h"
#include "avb_srp.h"
#include "avb_mvrp.h"
#include "ethernet_tx_client.h"
#include "ethernet_rx_client.h"
#include "avb_1722_router.h"
#include "ethernet_server_def.h"
#include "avb_mac_filter.h"
#include "avb_srp_interface.h"

#define PERIODIC_POLL_TIME 5000
#define LISTENER_READY_REPLAY_POLL_DIVIDER 200

[[combinable]]
void avb_srp_task(client interface avb_interface i_avb,
                  server interface srp_interface i_srp,
                  chanend c_mac_rx,
                  chanend c_mac_tx) {
  unsigned periodic_timeout;
  timer tmr;
  unsigned int nbytes;
  unsigned int buf[(MAX_AVB_CONTROL_PACKET_SIZE+1)>>2];
  unsigned int port_num;
  unsigned char mac_addr[6];
  unsigned int pending_talker_stream_id[2] = {0, 0};
  unsigned replay_poll_count = 0;
  int pending_talker_listener_replay = 0;

  srp_store_mac_tx_chanend(c_mac_tx);
  mrp_store_mac_tx_chanend(c_mac_tx);

  mac_get_macaddr(c_mac_tx, mac_addr);
  mrp_init(mac_addr);
  srp_domain_init();
  avb_mvrp_init();

  mac_initialize_routing_table(c_mac_tx);

  mac_set_custom_filter(c_mac_rx, MAC_FILTER_AVB_SRP);
  mac_request_status_packets(c_mac_rx);

  i_avb.initialise();

  tmr :> periodic_timeout;

  while (1) {
    select {
      case avb_get_control_packet(c_mac_rx, buf, nbytes, port_num):
      {
        avb_process_srp_control_packet(i_avb, buf, nbytes, c_mac_tx, port_num);
        break;
      }
      // Periodic processing
      case tmr when timerafter(periodic_timeout) :> unsigned int time_now:
      {
        mrp_periodic(i_avb);

        if (pending_talker_listener_replay &&
            ++replay_poll_count >= LISTENER_READY_REPLAY_POLL_DIVIDER) {
          replay_poll_count = 0;
          if (avb_srp_replay_registered_listener_ready(
                  i_avb, pending_talker_stream_id)) {
            debug_printf("MSRP: Replayed registered Listener Ready for %x:%x\n",
                         pending_talker_stream_id[0],
                         pending_talker_stream_id[1]);
            pending_talker_listener_replay = 0;
          }
        }

        periodic_timeout += PERIODIC_POLL_TIME;
        break;
      }
      case i_srp.register_stream_request(avb_srp_info_t stream_info) -> short vid_joined:
      {
        avb_srp_info_t local_stream_info = stream_info;
        debug_printf("MSRP: Register stream request %x:%x\n", stream_info.stream_id[0], stream_info.stream_id[1]);
        vid_joined = avb_srp_create_and_join_talker_advertise_attrs(&local_stream_info);
        pending_talker_stream_id[0] = stream_info.stream_id[0];
        pending_talker_stream_id[1] = stream_info.stream_id[1];
        replay_poll_count = 0;
        pending_talker_listener_replay = 1;
        break;
      }
      case i_srp.deregister_stream_request(unsigned stream_id[2]):
      {
        unsigned int local_stream_id[2];
        local_stream_id[0] = stream_id[0];
        local_stream_id[1] = stream_id[1];
        debug_printf("MSRP: Deregister stream request %x:%x\n", local_stream_id[0], local_stream_id[1]);
        if (pending_talker_listener_replay &&
            pending_talker_stream_id[0] == local_stream_id[0] &&
            pending_talker_stream_id[1] == local_stream_id[1]) {
          pending_talker_listener_replay = 0;
          replay_poll_count = 0;
        }
        avb_srp_leave_talker_attrs(local_stream_id);
        break;
      }
      case i_srp.register_attach_request(unsigned stream_id[2], short vlan_id) -> short vid_joined:
      {
        unsigned int local_stream_id[2];
        local_stream_id[0] = stream_id[0];
        local_stream_id[1] = stream_id[1];
        debug_printf("MSRP: Register attach request %x:%x\n", local_stream_id[0], local_stream_id[1]);
        vid_joined = avb_srp_join_listener_attrs(local_stream_id, vlan_id);
        break;
      }
      case i_srp.get_attach_info(unsigned stream_id[2]) -> avb_srp_info_t registration:
      {
        unsigned int local_stream_id[2];
        local_stream_id[0] = stream_id[0];
        local_stream_id[1] = stream_id[1];
        registration = avb_srp_get_listener_registration(local_stream_id);
        break;
      }
      case i_srp.deregister_attach_request(unsigned stream_id[2]):
      {
        unsigned int local_stream_id[2];
        local_stream_id[0] = stream_id[0];
        local_stream_id[1] = stream_id[1];
        debug_printf("MSRP: Deregister attach request %x:%x\n", local_stream_id[0], local_stream_id[1]);
        avb_srp_leave_listener_attrs(local_stream_id);
        break;
      }
    }
  }
}
