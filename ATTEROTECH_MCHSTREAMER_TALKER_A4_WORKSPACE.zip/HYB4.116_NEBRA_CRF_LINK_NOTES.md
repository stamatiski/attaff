# HYB4.116 Nebra CRF Clock-Link Correction

HYB4.116 is a narrow control-plane revision of HYB4.115. It preserves the
listener audio, CRF recovery, DAC clocking, gPTP, ACMP/MSRP and Milan behavior.

The AEM clock-source graph now follows the Milan Annex A.7 ordering used by
the reference devices: Clock Source 0 is the internal source at Entity 0 and
Clock Source 1 is the CRF input-stream source at Stream Input 0. The selected
clock source is Source 1. An explicit AECP translation maps those descriptor
indices to the unchanged XMOS runtime clock enumeration.

The Entity Model ID is changed to 0x0022970000009116 so controllers cannot
reuse the static HYB4.115 AEM graph from cache. Firmware identity is
6.1.1-HYB4.116-NBR-CRF.

Hardware validation must confirm that Nebra no longer logs `ClockFormat is
none` or `currentSourceClock ist nullptr` while audio and CRF remain normal.
