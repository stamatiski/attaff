#include "avb.h"
#include <xccompat.h>
#include "avb_srp.h"
#include "avb_mvrp.h"
#include "avb_mrp.h"
#include "avb_stream.h"
#include "gptp_config.h"
#include "avb_control_types.h"
#include <string.h>
#include "debug_print.h"
#include <print.h>
#include "ethernet_tx_client.h"
#include "ethernet_rx_client.h"
#include "ethernet_server_def.h"
#include "mac_filter.h"
#include "avb_1722_maap.h"
#include "nettypes.h"
#include "avb_1722_router.h"
#include "avb_1722_common.h"
#include "avb_api.h"
#include "avb_srp_interface.h"

#if AVB_ENABLE_1722_1
#include "avb_1722_1.h"
#include "avb_1722_1_adp.h"
#endif

//#define AVB_TRANSMIT_BEFORE_RESERVATION 1

#define UNMAPPED (-1)
#define AVB_CHANNEL_UNMAPPED (-1)

typedef struct media_info_t {
  int tile_id;
  unsigned clk_ctl;
  unsigned fifo;
  int local_id;
  int mapped_to;
} media_info_t;

static int max_talker_stream_id = 0;
static int max_listener_stream_id = 0;
static avb_source_info_t sources[AVB_NUM_SOURCES];
static avb_1722_talker_counters_t source_counters[AVB_NUM_SOURCES];
/* Set only after the media map, talker packetizer and SRP/VLAN state have
 * all been configured successfully.  AEM/ACMP state must never advance to
 * ENABLED while this flag is clear. */
static unsigned char source_configured[AVB_NUM_SOURCES];
static avb_sink_info_t sinks[AVB_NUM_SINKS];
static media_info_t inputs[AVB_NUM_MEDIA_INPUTS];
static media_info_t outputs[AVB_NUM_MEDIA_OUTPUTS];

static void register_talkers(chanend (&?c_talker_ctl)[], unsigned char mac_addr[6])
{
  unsafe {
    for (int i=0;i<AVB_NUM_TALKER_UNITS;i++) {
      int tile_id, num_streams;
      c_talker_ctl[i] :> tile_id;
      c_talker_ctl[i] :> num_streams;
      for (int j=0;j<num_streams;j++) {
        avb_source_info_t *unsafe source = &sources[max_talker_stream_id];
        source->stream.state = AVB_SOURCE_STATE_DISABLED;
        chanend *unsafe p_talker_ctl = &c_talker_ctl[i];
        source->talker_ctl = p_talker_ctl;
        source->stream.tile_id = tile_id;
        source->stream.local_id = j;
        source->stream.flags = 0;
        source->reservation.stream_id[0] = (mac_addr[0] << 24) | (mac_addr[1] << 16) | (mac_addr[2] <<  8) | (mac_addr[3] <<  0);
        source->reservation.stream_id[1] = (mac_addr[4] << 24) | (mac_addr[5] << 16) | ((source->stream.local_id & 0xffff)<<0);
        source->presentation = AVB_DEFAULT_PRESENTATION_TIME_DELAY_NS;
        source->reservation.vlan_id = 0;
        source->reservation.tspec = (AVB_SRP_TSPEC_PRIORITY_DEFAULT << 5 |
            AVB_SRP_TSPEC_RANK_DEFAULT << 4 |
            AVB_SRP_TSPEC_RESERVED_VALUE);
        source->reservation.tspec_max_interval = AVB_SRP_MAX_INTERVAL_FRAMES_DEFAULT;
        source->reservation.accumulated_latency = AVB_SRP_ACCUMULATED_LATENCY_DEFAULT;
        source_configured[max_talker_stream_id] = 0;
        max_talker_stream_id++;
      }
    }
  }
}


static int max_link_id = 0;


static void register_listeners(chanend (&?c_listener_ctl)[])
{
  unsafe {
    for (int i=0;i<AVB_NUM_LISTENER_UNITS;i++) {
      int tile_id, num_streams;
      c_listener_ctl[i] :> tile_id;
      c_listener_ctl[i] :> num_streams;
      for (int j=0;j<num_streams;j++) {
        avb_sink_info_t *unsafe sink = &sinks[max_listener_stream_id];
        sink->stream.state = AVB_SINK_STATE_DISABLED;
        chanend *unsafe p_listener_ctl = &c_listener_ctl[i];
        sink->listener_ctl = p_listener_ctl;
        sink->stream.tile_id = tile_id;
        sink->stream.local_id = j;
        sink->stream.flags = 0;
        sink->reservation.vlan_id = 0;
        max_listener_stream_id++;
      }
      c_listener_ctl[i] <: max_link_id;
      max_link_id++;
    }
  }
}

static void register_media(chanend media_ctl[])
{
  unsafe {
    int input_id = 0;
    int output_id = 0;

    for (int i=0;i<AVB_NUM_MEDIA_UNITS;i++) {
      int tile_id;
      int num_in;
      int num_out;
      unsigned clk_ctl;
      media_ctl[i] :> tile_id;
      media_ctl[i] :> clk_ctl;
      media_ctl[i] :> num_in;

      for (int j=0;j<num_in;j++) {
        media_ctl[i] <: input_id;
        inputs[input_id].tile_id = tile_id;
        inputs[input_id].clk_ctl = clk_ctl;
        inputs[input_id].local_id = j;
        inputs[input_id].mapped_to = UNMAPPED;
        media_ctl[i] :> inputs[input_id].fifo;
        input_id++;

      }
      media_ctl[i] :> num_out;
      for (int j=0;j<num_out;j++) {
        media_ctl[i] <: output_id;
        outputs[output_id].tile_id = tile_id;
        outputs[output_id].clk_ctl = clk_ctl;
        outputs[output_id].local_id = j;
        outputs[output_id].mapped_to = UNMAPPED;
        media_ctl[i] :> outputs[output_id].fifo;
        output_id++;
      }
    }
  }
}

static void init_media_clock_server(client interface media_clock_if
                                    ?media_clock_ctl)
{
  if (!isnull(media_clock_ctl)) {
    for (int i=0;i<AVB_NUM_MEDIA_OUTPUTS;i++) {
      media_clock_ctl.set_buf_fifo(i, outputs[i].fifo);
    }
  }
}

void avb_init(chanend c_media_ctl[],
              chanend (&?c_listener_ctl)[],
              chanend (&?c_talker_ctl)[],
              client interface media_clock_if ?i_media_clock_ctl,
              chanend c_ptp,
              chanend c_mac_tx)
{
  unsigned char mac_addr[6];
  mac_get_macaddr(c_mac_tx, mac_addr);
  register_talkers(c_talker_ctl, mac_addr);
  register_listeners(c_listener_ctl);
}

static int valid_to_leave_vlan(int vlan)
{
  int all_streams_disabled = 1;
  for (int i=0; i < AVB_NUM_SINKS; i++) {
    if (sinks[i].stream.state != AVB_SINK_STATE_DISABLED) {
      all_streams_disabled = 0;
      break;
    }
  }

  for (int i=0; i < AVB_NUM_SOURCES; i++) {
    if (sources[i].stream.state != AVB_SINK_STATE_DISABLED) {
      all_streams_disabled = 0;
      break;
    }
  }

  return all_streams_disabled;
}

/* Copy only the matching live MSRP Talker state into the sink reservation.
 * ACMP remains authoritative for Stream ID, destination MAC and requested
 * VLAN.  AEM GET_STREAM_INFO can therefore report REGISTERING only while an
 * actual matching Talker Advertise/Talker Failed attribute is held by MSRP. */
static int refresh_sink_srp_registration(unsigned sink_num,
                                         client interface srp_interface i_srp)
{
  unsafe {
    avb_sink_info_t *sink = &sinks[sink_num];

    if (sink->stream.state == AVB_SINK_STATE_DISABLED)
      return 0;

    avb_srp_info_t registration =
        i_srp.get_attach_info(sink->reservation.stream_id);

    if ((registration.stream_id[0] == sink->reservation.stream_id[0]) &&
        (registration.stream_id[1] == sink->reservation.stream_id[1]) &&
        (registration.tspec_max_frame_size != 0))
    {
      sink->reservation.tspec_max_frame_size = registration.tspec_max_frame_size;
      sink->reservation.tspec_max_interval = registration.tspec_max_interval;
      sink->reservation.tspec = registration.tspec;
      sink->reservation.accumulated_latency = registration.accumulated_latency;
      memcpy(sink->reservation.failure_bridge_id,
             registration.failure_bridge_id,
             sizeof(sink->reservation.failure_bridge_id));
      sink->reservation.failure_code = registration.failure_code;
      return registration.failure_code ? -1 : 1;
    }
    else
    {
      sink->reservation.tspec_max_frame_size = 0;
      sink->reservation.tspec_max_interval = 0;
      sink->reservation.tspec = 0;
      sink->reservation.accumulated_latency = 0;
      memset(sink->reservation.failure_bridge_id, 0,
             sizeof(sink->reservation.failure_bridge_id));
      sink->reservation.failure_code = 0;
      return 0;
    }
  }
}

static void update_sink_state(unsigned sink_num,
                              enum avb_sink_state_t prev,
                              enum avb_sink_state_t state,
                              chanend c_mac_tx,
                              client interface media_clock_if ?i_media_clock_ctl,
                              client interface srp_interface i_srp) {
  unsafe {
    avb_sink_info_t *sink = &sinks[sink_num];
    chanend *unsafe c = sink->listener_ctl;
    if (prev == AVB_SINK_STATE_DISABLED &&
        state == AVB_SINK_STATE_POTENTIAL) {

      unsigned clk_ctl = (sink->stream.format == AVB_SOURCE_FORMAT_CRF) ?
                         sink->stream.sync : outputs[sink->map[0]].clk_ctl;
      debug_printf("Listener sink #%d chan map:\n", sink_num);
      master {
        *c <: AVB1722_CONFIGURE_LISTENER_STREAM;
        *c <: (int)sink->stream.local_id;
        *c <: (int)sink->stream.sync;
        *c <: (int)sink->stream.format;
        *c <: sink->stream.rate;
        *c <: (int)sink->stream.num_channels;

        for (int i=0;i<sink->stream.num_channels;i++) {
          if (sink->map[i] == AVB_CHANNEL_UNMAPPED) {
            *c <: 0;
            debug_printf("  %d unmapped\n", i);
          }
          else {
            *c <: outputs[sink->map[i]].fifo;
            debug_printf("  %d -> %x\n", i, sink->map[i]);
          }
        }
      }

      if (!isnull(i_media_clock_ctl) && sink->stream.format != AVB_SOURCE_FORMAT_CRF) {
          i_media_clock_ctl.register_clock(clk_ctl, sink->stream.sync);
      }

      int router_link;

      master {
        *c <: AVB1722_GET_ROUTER_LINK;
        *c :> router_link;
      }

      avb_1722_add_stream_mapping(c_mac_tx,
                                  sink->reservation.stream_id,
                                  router_link,
                                  sink->stream.local_id);

      sink->reservation.vlan_id = i_srp.register_attach_request(sink->reservation.stream_id, sink->reservation.vlan_id);

      /* Capture an attribute already present at activation.  The periodic
       * refresh below also handles the normal case where Talker Advertise is
       * learned after CONNECT_RX completes. */
      refresh_sink_srp_registration(sink_num, i_srp);

    }
    else if (prev != AVB_SINK_STATE_DISABLED &&
            state == AVB_SINK_STATE_DISABLED) {

      master {
        *c <: AVB1722_DISABLE_LISTENER_STREAM;
        *c <: (int)sink->stream.local_id;
      }

      i_srp.deregister_attach_request(sink->reservation.stream_id);

      avb_1722_remove_stream_mapping(c_mac_tx, sink->reservation.stream_id);

#if MRP_NUM_PORTS == 1
      int vid = sink->reservation.vlan_id;
      if (vid && valid_to_leave_vlan(vid)) {
        avb_leave_vlan(vid);
      }
#endif
    }
  }
}

static unsigned avb_srp_calculate_max_framesize(avb_source_info_t *source_info)
{
#if AVB_1722_FORMAT_61883_6 || AVB_1722_FORMAT_AAF
  if (source_info->stream.format == AVB_SOURCE_FORMAT_CRF)
    return AVB_CRF_HDR_SIZE + 8;
  const unsigned samples_per_packet = (source_info->stream.rate + (AVB1722_PACKET_RATE-1))/AVB1722_PACKET_RATE;
  return AVB1722_PLUS_SIP_HEADER_SIZE + (source_info->stream.num_channels * samples_per_packet * 4);
#elif AVB_1722_FORMAT_61883_4
  return AVB1722_PLUS_SIP_HEADER_SIZE + (192 * MAX_TS_PACKETS_PER_1722);
#endif
}

/* Rebuild the local producer-to-packetizer runtime for a source whose AEM/ACMP
 * state already says it is connected.  ACMP state and packetizer state are
 * deliberately separate: a controller reconnect or a rejected intermediate
 * transition must never leave an ENABLED descriptor with no FIFO/configuration
 * behind it.  This function is idempotent and reports success only after the
 * packetizer, SRP/VLAN and media-clock registrations have all been installed. */
static int configure_source_runtime(
    unsigned source_num,
    client interface media_clock_if ?i_media_clock_ctl,
    client interface srp_interface i_srp)
{
  int success = 1;

  if (source_num >= AVB_NUM_SOURCES)
    return 0;

  unsafe {
    avb_source_info_t *source = &sources[source_num];
    chanend *unsafe c = source->talker_ctl;
    int valid = 1;
    int num_channels = source->stream.num_channels;
    unsigned clk_ctl = source->stream.sync;

    if (source_configured[source_num])
      return 1;

    if (source->stream.format != AVB_SOURCE_FORMAT_CRF &&
        (num_channels <= 0 ||
         num_channels > AVB_MAX_CHANNELS_PER_TALKER_STREAM ||
         num_channels > AVB_NUM_MEDIA_INPUTS)) {
      debug_printf("Talker stream #%d rejected: invalid channel count %d\n",
                   source_num, num_channels);
      valid = 0;
    }
    if (source->reservation.vlan_id < 0) {
      debug_printf("Talker stream #%d rejected: invalid VLAN %d\n",
                   source_num, source->reservation.vlan_id);
      valid = 0;
    }

    if (valid && source->stream.format != AVB_SOURCE_FORMAT_CRF) {
      for (int i=0; i<num_channels; i++) {
        int media_input = source->map[i];
        if (media_input < 0 || media_input >= AVB_NUM_MEDIA_INPUTS ||
            media_input >= 32) {
          debug_printf("Talker stream #%d rejected: media map[%d]=%d out of range\n",
                       source_num, i, media_input);
          valid = 0;
        }
        for (int j=0; j<i; j++) {
          if (source->map[j] == media_input) {
            debug_printf("Talker stream #%d rejected: duplicate media input %d\n",
                         source_num, media_input);
            valid = 0;
          }
        }
      }
    }

    if (valid && source->stream.format != AVB_SOURCE_FORMAT_CRF) {
      clk_ctl = inputs[source->map[0]].clk_ctl;
      for (int i=0; i<num_channels; i++) {
        int media_input = source->map[i];
        if (inputs[media_input].mapped_to != UNMAPPED &&
            inputs[media_input].mapped_to != source_num) {
          debug_printf("Talker stream #%d rejected: media input %d is owned by source %d\n",
                       source_num, media_input, inputs[media_input].mapped_to);
          valid = 0;
        }
        if (inputs[media_input].clk_ctl != clk_ctl) {
          debug_printf("Talker stream #%d rejected: media input %d uses another clock\n",
                       source_num, media_input);
          valid = 0;
        }
      }
    }

    if (!valid)
      return 0;

    unsigned fifo_mask = 0;
    for (int i=0; i<AVB_NUM_MEDIA_INPUTS; i++) {
      if (inputs[i].mapped_to == source_num)
        inputs[i].mapped_to = UNMAPPED;
    }

    for (int i=0; i<num_channels; i++) {
      int media_input = source->map[i];
      inputs[media_input].mapped_to = source_num;
      fifo_mask |= (1 << media_input);
    }

    master {
      *c <: AVB1722_CONFIGURE_TALKER_STREAM;
      *c <: (int)source->stream.local_id;
      *c <: (int)source->stream.format;

      for (int i=0; i<6; i++)
        *c <: (int)source->reservation.dest_mac_addr[i];

      *c <: source_num;
      *c <: (int)source->stream.num_channels;
      *c <: fifo_mask;

      for (int i=0; i<num_channels; i++)
        *c <: inputs[source->map[i]].fifo;

      *c <: (int)source->stream.rate;
      if (source->presentation)
        *c <: source->presentation;
      else
        *c <: AVB_DEFAULT_PRESENTATION_TIME_DELAY_NS;
      *c <: (int)source->stream.sync;
    }

    source->reservation.tspec_max_frame_size =
        avb_srp_calculate_max_framesize(source);

    /* Never overwrite the requested VLAN with a negative SRP error.  Doing so
     * made a transient failure permanent because every later retry rejected
     * the now-negative descriptor value before reaching SRP again. */
    int requested_vlan = source->reservation.vlan_id;
    int registered_vlan = i_srp.register_stream_request(source->reservation);
    if (registered_vlan < 0) {
      source->reservation.vlan_id = requested_vlan;
      debug_printf("Talker stream #%d rejected: SRP registration failed (%d)\n",
                   source_num, registered_vlan);
      for (int i=0; i<AVB_NUM_MEDIA_INPUTS; i++) {
        if (inputs[i].mapped_to == source_num)
          inputs[i].mapped_to = UNMAPPED;
      }
      success = 0;
    }
    else {
      source->reservation.vlan_id = registered_vlan;
      master {
        *c <: AVB1722_SET_VLAN;
        *c <: (int)source->reservation.vlan_id;
      }

      if (!isnull(i_media_clock_ctl) &&
          source->stream.format != AVB_SOURCE_FORMAT_CRF) {
        i_media_clock_ctl.register_clock(clk_ctl, source->stream.sync);
      }

      source_configured[source_num] = 1;
      debug_printf("Talker stream #%d runtime configured (FIFO mask 0x%x)\n",
                   source_num, fifo_mask);
    }
  }

  return success;
}

static int update_source_state(unsigned source_num,
                               enum avb_source_state_t prev,
                               enum avb_source_state_t state,
                               chanend c_mac_tx,
                               client interface media_clock_if ?i_media_clock_ctl,
                               client interface srp_interface i_srp) {
  int success = 1;

  if (source_num >= AVB_NUM_SOURCES) {
    debug_printf("Talker source index %u out of range\n", source_num);
    return 0;
  }

  unsafe {
    char stream_string[] = "Talker stream";
    avb_source_info_t *source = &sources[source_num];
    chanend *unsafe c = source->talker_ctl;

    if (prev == state) {
      /* Descriptor fields may be updated while the source remains disabled.
       * A state transition is required before any packetizer side effects. */
    }
    else if (prev == AVB_SOURCE_STATE_DISABLED &&
        state == AVB_SOURCE_STATE_POTENTIAL) {
      /* Configure the complete producer-to-packetizer path before allowing a
       * later POTENTIAL -> ENABLED transition.  TX60 committed AEM state
       * first and could therefore report a running source with no GO command,
       * STREAM_START=0 and FRAMES_TX=0. */
      source_configured[source_num] = 0;
      success = configure_source_runtime(source_num, i_media_clock_ctl, i_srp);
      if (success) {
#if defined(AVB_TRANSMIT_BEFORE_RESERVATION)
        master {
          *c <: AVB1722_TALKER_GO;
          *c <: (int)source->stream.local_id;
        }
        source_counters[source_num].stream_start++;
        debug_printf("%s #%d on\n", stream_string, source_num);
#else
        debug_printf("%s #%d ready\n", stream_string, source_num);
#endif
      }
      else {
        success = 0;
      }
    }
    else if (prev == AVB_SOURCE_STATE_ENABLED &&
        state == AVB_SOURCE_STATE_POTENTIAL) {
      if (!source_configured[source_num]) {
        debug_printf("Talker stream #%d rejected: stop requested before configuration\n",
                     source_num);
        success = 0;
      }
      else {
        source_counters[source_num].stream_stop++;

        master {
          *c <: AVB1722_TALKER_STOP;
          *c <: (int)source->stream.local_id;
        }
        debug_printf("%s #%d off\n", stream_string, source_num);
      }
    }
    else if (prev == AVB_SOURCE_STATE_POTENTIAL &&
             state == AVB_SOURCE_STATE_ENABLED) {
      if (!source_configured[source_num]) {
        debug_printf("Talker stream #%d repairing missing runtime before start\n",
                     source_num);
        success = configure_source_runtime(source_num,
                                           i_media_clock_ctl,
                                           i_srp);
      }
      if (success) {
        debug_printf("%s #%d on\n", stream_string, source_num);

        master {
          *c <: AVB1722_TALKER_GO;
          *c <: (int)source->stream.local_id;
        }
        source_counters[source_num].stream_start++;
      }
    }
    else if (prev != AVB_SOURCE_STATE_DISABLED &&
             state == AVB_SOURCE_STATE_DISABLED) {
        /* Unmap by ownership rather than trusting a possibly malformed or
         * newly supplied map array. */
        if (prev == AVB_SOURCE_STATE_ENABLED) {
          source_counters[source_num].stream_stop++;
        }
        for (int i=0; i<AVB_NUM_MEDIA_INPUTS; i++) {
          if (inputs[i].mapped_to == source_num) {
            inputs[i].mapped_to = UNMAPPED;
          }
        }

        master {
          *c <: AVB1722_TALKER_STOP;
          *c <: (int)source->stream.local_id;
        }
        source_configured[source_num] = 0;

        debug_printf("%s #%d off\n", stream_string, source_num);

#if MRP_NUM_PORTS == 1
      int vid = source->reservation.vlan_id;
      if (vid && valid_to_leave_vlan(vid)) {
        avb_leave_vlan(vid);
      }
#endif

      i_srp.deregister_stream_request(source->reservation.stream_id);

    }
    else {
      debug_printf("Talker stream #%d rejected: unsupported state transition %d -> %d\n",
                   source_num, prev, state);
      success = 0;
    }
  }

  return success;
}

// Wrappers for interface calls from C
int avb_get_source_state(client interface avb_interface avb, unsigned source_num, enum avb_source_state_t &state) {
  return avb.get_source_state(source_num, state);
}

int avb_set_source_state(client interface avb_interface avb, unsigned source_num, enum avb_source_state_t state) {
  return avb.set_source_state(source_num, state);
}

int avb_get_source_vlan(client interface avb_interface avb, unsigned source_num, int &vlan) {
  return avb.get_source_vlan(source_num, vlan);
}

int avb_set_source_vlan(client interface avb_interface avb, unsigned source_num, int vlan) {
  return avb.set_source_vlan(source_num, vlan);
}

int avb_get_sink_vlan(client interface avb_interface avb, unsigned sink_num, int &vlan) {
  return avb.get_sink_vlan(sink_num, vlan);
}

int avb_set_sink_vlan(client interface avb_interface avb, unsigned sink_num, int vlan) {
  return avb.set_sink_vlan(sink_num, vlan);
}

static void read_sink_counters(unsigned sink_num,
                               avb_1722_listener_counters_t &counters)
{
  memset(&counters, 0, sizeof(counters));
  if (sink_num < AVB_NUM_SINKS) {
    unsafe {
      avb_sink_info_t *sink = &sinks[sink_num];
      chanend *unsafe c = sink->listener_ctl;
      master {
        *c <: AVB1722_GET_LISTENER_STREAM_COUNTERS;
        *c <: (int)sink->stream.local_id;
        *c :> counters.frames_rx;
        *c :> counters.seq_num_mismatch;
        *c :> counters.unsupported_format;
        *c :> counters.stream_interrupted;
        *c :> counters.timestamp_uncertain;
        *c :> counters.media_locked;
        *c :> counters.media_unlocked;
        *c :> counters.media_reset;
      }
    }
  }
}

// Set the period inbetween periodic processing to 50us based
// on the Xcore 100Mhz timer.
#define PERIODIC_POLL_TIME 5000

/* 250 ms is well below controller loss-detection intervals while adding only
 * eight MSRP reads per second for this two-input listener. */
#define SRP_REGISTRATION_REFRESH_TICKS 25000000

/* A matching Talker Failed declaration must persist for three observations
 * before recovery begins.  The two-poll delay after Leave provides a real
 * 500 ms interval for MRP to transmit the Leave and remove the failed
 * attribute before the Listener Ready declaration is recreated. */
#define CRF_SRP_FAILURE_POLLS_BEFORE_RECOVERY 3
#define CRF_SRP_REJOIN_DELAY_POLLS 2
#define CRF_SRP_MAX_RECOVERY_ATTEMPTS 3

[[combinable]]
void avb_manager(server interface avb_interface avb[num_avb_clients], unsigned num_avb_clients,
                 client interface srp_interface i_srp,
                 chanend c_media_ctl[],
                 chanend (&?c_listener_ctl)[],
                 chanend (&?c_talker_ctl)[],
                 chanend c_mac_tx,
                 client interface media_clock_if ?i_media_clock_ctl,
                 chanend c_ptp) {

  register_media(c_media_ctl);
  init_media_clock_server(i_media_clock_ctl);

  timer srp_refresh_timer;
  unsigned srp_refresh_time;
  srp_refresh_timer :> srp_refresh_time;
  srp_refresh_time += SRP_REGISTRATION_REFRESH_TICKS;

  unsigned char crf_srp_failure_polls[AVB_NUM_SINKS] = {0};
  unsigned char crf_srp_rejoin_delay[AVB_NUM_SINKS] = {0};
  unsigned char crf_srp_recovery_attempts[AVB_NUM_SINKS] = {0};

  while (1) {
    select {
    case srp_refresh_timer when timerafter(srp_refresh_time) :> void:
      srp_refresh_time += SRP_REGISTRATION_REFRESH_TICKS;
      {
        int crf_sink_num = -1;

        for (unsigned sink_num = 0; sink_num < AVB_NUM_SINKS; sink_num++) {
          int registration_state =
              refresh_sink_srp_registration(sink_num, i_srp);

          unsafe {
            avb_sink_info_t *sink = &sinks[sink_num];

            if ((sink->stream.state == AVB_SINK_STATE_DISABLED) ||
                (sink->stream.format != AVB_SOURCE_FORMAT_CRF)) {
              crf_srp_failure_polls[sink_num] = 0;
              crf_srp_rejoin_delay[sink_num] = 0;
              crf_srp_recovery_attempts[sink_num] = 0;
              continue;
            }

            if (crf_sink_num < 0)
              crf_sink_num = sink_num;

            if (crf_srp_rejoin_delay[sink_num]) {
              crf_srp_rejoin_delay[sink_num]--;
              if (!crf_srp_rejoin_delay[sink_num]) {
                short vlan_id =
                    i_srp.register_attach_request(
                        sink->reservation.stream_id,
                        sink->reservation.vlan_id);
                if (vlan_id > 0)
                  sink->reservation.vlan_id = vlan_id;
                debug_printf("CRF sink #%d MSRP rejoin attempt %d\n",
                             sink_num,
                             crf_srp_recovery_attempts[sink_num]);
              }
              continue;
            }

            if (registration_state > 0) {
              crf_srp_failure_polls[sink_num] = 0;
              crf_srp_recovery_attempts[sink_num] = 0;
            }
            else if (registration_state < 0) {
              if (crf_srp_failure_polls[sink_num] < 255)
                crf_srp_failure_polls[sink_num]++;

              if ((crf_srp_failure_polls[sink_num] >=
                       CRF_SRP_FAILURE_POLLS_BEFORE_RECOVERY) &&
                  (crf_srp_recovery_attempts[sink_num] <
                       CRF_SRP_MAX_RECOVERY_ATTEMPTS)) {
                crf_srp_failure_polls[sink_num] = 0;
                crf_srp_recovery_attempts[sink_num]++;
                i_srp.deregister_attach_request(
                    sink->reservation.stream_id);
                crf_srp_rejoin_delay[sink_num] =
                    CRF_SRP_REJOIN_DELAY_POLLS;
                debug_printf("CRF sink #%d clearing failed MSRP state\n",
                             sink_num);
              }
            }
            else {
              crf_srp_failure_polls[sink_num] = 0;
            }
          }
        }

      }
      break;
    case avb[int i].initialise(void):
      unsafe {
        avb_init(c_media_ctl, c_listener_ctl, c_talker_ctl, i_media_clock_ctl, c_ptp, c_mac_tx);
      }
      break;
    case avb[int i]._get_source_info(unsigned source_num) -> avb_source_info_t info:
      info = sources[source_num];
      break;
    case avb[int i]._set_source_info(unsigned source_num, avb_source_info_t info):
      if (source_num < AVB_NUM_SOURCES) {
        avb_source_info_t previous_info = sources[source_num];
        enum avb_source_state_t prev_state = previous_info.stream.state;
        sources[source_num] = info;
        unsafe {
          if (!update_source_state(source_num, prev_state, info.stream.state,
                                   c_mac_tx, i_media_clock_ctl, i_srp)) {
            /* Keep descriptor/AEM state consistent with the actual media
             * path.  The failed request must not appear as a running source. */
            sources[source_num] = previous_info;
          }
        }
      }
      else {
        debug_printf("Ignoring talker source update for invalid index %u\n",
                     source_num);
      }
      break;
    case avb[int i]._get_sink_info(unsigned sink_num) -> avb_sink_info_t info:
      info = sinks[sink_num];
      break;
    case avb[int i]._set_sink_info(unsigned sink_num, avb_sink_info_t info):
      enum avb_sink_state_t prev_state = sinks[sink_num].stream.state;
      sinks[sink_num] = info;
      if ((prev_state == AVB_SINK_STATE_DISABLED) ||
          (info.stream.state == AVB_SINK_STATE_DISABLED)) {
        crf_srp_failure_polls[sink_num] = 0;
        crf_srp_rejoin_delay[sink_num] = 0;
        crf_srp_recovery_attempts[sink_num] = 0;
      }
      unsafe {
        update_sink_state(sink_num, prev_state, info.stream.state, c_mac_tx,
                          i_media_clock_ctl, i_srp);
      }
      break;
    case avb[int i]._get_media_clock_info(unsigned clock_num)
      -> media_clock_info_t info:
      info = i_media_clock_ctl.get_clock_info(clock_num);
      break;
    case avb[int i]._set_media_clock_info(unsigned clock_num,
                                          media_clock_info_t info):
      i_media_clock_ctl.set_clock_info(clock_num, info);
      break;
    case avb[int i]._get_sink_counters(unsigned sink_num)
      -> avb_1722_listener_counters_t counters:
      read_sink_counters(sink_num, counters);
      break;
    case avb[int i]._get_source_counters(unsigned source_num)
      -> avb_1722_talker_counters_t counters:
      memset(&counters, 0, sizeof(counters));
      if (source_num < AVB_NUM_SOURCES) {
        counters = source_counters[source_num];
        unsafe {
          avb_source_info_t *source = &sources[source_num];
          chanend *unsafe c = source->talker_ctl;
          master {
            *c <: AVB1722_GET_TALKER_STREAM_COUNTERS;
            *c <: (int)source->stream.local_id;
            *c :> counters.media_reset;
            *c :> counters.timestamp_uncertain;
            *c :> counters.frames_tx;
          }
        }
      }
      break;
    }
  }
}

int set_avb_source_port(unsigned source_num,
                        int srcport) {
  unsafe {
  if (source_num < AVB_NUM_SOURCES) {
    avb_source_info_t *source = &sources[source_num];
    chanend *unsafe c = source->talker_ctl;
    master {
      *c <: AVB1722_SET_PORT;
      *c <: (int)source->stream.local_id;
      *c <: srcport;
    }

    return 1;
  }
  else
    return 0;
  }
}

#ifdef MEDIA_OUTPUT_FIFO_VOLUME_CONTROL
void set_avb_source_volumes(unsigned sink_num, int volumes[], int count)
{
	if (sink_num < AVB_NUM_SINKS) {
    unsafe {
      avb_sink_info_t *sink = &sinks[sink_num];
      chanend *unsafe c = sink->listener_ctl;
      *c <: AVB1722_ADJUST_LISTENER_STREAM;
      *c <: sink->stream.local_id;
      *c <: AVB1722_ADJUST_LISTENER_VOLUME;
      *c <: count;
      for (int i=0;i<count;i++) {
        *c <:  volumes[i];
      }
    }
	}
}
#endif


void avb_process_1722_control_packet(unsigned int buf0[],
                                     unsigned nbytes,
                                     chanend c_tx,
                                     client interface avb_interface i_avb,
                                     client interface avb_1722_1_control_callbacks i_1722_1_entity,
                                     client interface spi_interface ?i_spi) {
  if (nbytes == STATUS_PACKET_LEN) {
    if (((unsigned char *)buf0)[0]) { // Link up
#if NUM_ETHERNET_PORTS == 1
      unsigned char base_addr[6];
      if (!avb_1722_maap_get_base_address(base_addr)) {
        avb_1722_maap_request_addresses(AVB_NUM_SOURCES, base_addr);
      }
      else {
        avb_1722_maap_request_addresses(AVB_NUM_SOURCES, null);
      }
#endif
    }
  }
  else {
    struct ethernet_hdr_t *ethernet_hdr = (ethernet_hdr_t *) &buf0[0];

    int etype, eth_hdr_size;
    int has_qtag = ethernet_hdr->ethertype.data[1]==0x18;
    eth_hdr_size = has_qtag ? 18 : 14;

    if (has_qtag) {
      struct tagged_ethernet_hdr_t *tagged_ethernet_hdr = (tagged_ethernet_hdr_t *) &buf0[0];
      etype = (int)(tagged_ethernet_hdr->ethertype.data[0] << 8) + (int)(tagged_ethernet_hdr->ethertype.data[1]);
    }
    else {
      etype = (int)(ethernet_hdr->ethertype.data[0] << 8) + (int)(ethernet_hdr->ethertype.data[1]);
    }
    int len = nbytes - eth_hdr_size;

    unsigned char *buf = (unsigned char *) buf0;

    switch (etype) {
      case AVB_1722_ETHERTYPE:
        avb_1722_1_process_packet(&buf[eth_hdr_size], len, ethernet_hdr->src_addr, c_tx, i_avb, i_1722_1_entity, i_spi);
        avb_1722_maap_process_packet(&buf[eth_hdr_size], len, ethernet_hdr->src_addr, c_tx);
        break;
    }
  }
}

// avb_mrp.c:
extern unsigned char srp_dest_mac[6];
extern unsigned char mvrp_dest_mac[6];

void avb_process_srp_control_packet(client interface avb_interface avb, unsigned int buf0[], unsigned nbytes, chanend c_tx, unsigned int port_num)
{
  if (nbytes == STATUS_PACKET_LEN) {
    if (((unsigned char *)buf0)[0]) { // Link up
      srp_domain_join();
    }
  }
  else {
    struct ethernet_hdr_t *ethernet_hdr = (ethernet_hdr_t *) &buf0[0];

    int etype, eth_hdr_size;
    int has_qtag = ethernet_hdr->ethertype.data[1]==0x18;
    eth_hdr_size = has_qtag ? 18 : 14;

    if (has_qtag) {
      struct tagged_ethernet_hdr_t *tagged_ethernet_hdr = (tagged_ethernet_hdr_t *) &buf0[0];
      etype = (int)(tagged_ethernet_hdr->ethertype.data[0] << 8) + (int)(tagged_ethernet_hdr->ethertype.data[1]);
    }
    else {
      etype = (int)(ethernet_hdr->ethertype.data[0] << 8) + (int)(ethernet_hdr->ethertype.data[1]);
    }
    int len = nbytes - eth_hdr_size;

    unsigned char *buf = (unsigned char *) buf0;

    if (etype != AVB_SRP_ETHERTYPE && etype != AVB_MVRP_ETHERTYPE) {
      return;
    }

    if (etype == AVB_SRP_ETHERTYPE) {
      for (int i=0; i < 6; i++) {
        if (ethernet_hdr->dest_addr[i] != srp_dest_mac[i]) {
          return;
        }
      }
    }

    if (etype == AVB_MVRP_ETHERTYPE) {
      for (int i=0; i < 6; i++) {
        if (ethernet_hdr->dest_addr[i] != mvrp_dest_mac[i]) {
          return;
        }
      }
    }

    avb_mrp_process_packet(&buf[eth_hdr_size], etype, len, port_num);
  }

}

int get_avb_ptp_gm(unsigned char a0[])
{
  // ptp_get_current_grandmaster(*c_ptp, a0);
  return 1;
}

int get_avb_ptp_port_pdelay(int srcport, unsigned *pdelay)
{
  if (srcport == 0)
  {
    // ptp_get_propagation_delay(*c_ptp, pdelay);
    return 1;
  }
  else
  {
    return 0;
  }
}

unsigned avb_get_source_stream_index_from_stream_id(unsigned int stream_id[2])
{
  for (unsigned i=0; i<AVB_NUM_SOURCES; ++i) {
    if (stream_id[0] == sources[i].reservation.stream_id[0] &&
        stream_id[1] == sources[i].reservation.stream_id[1]) {
      return i;
    }
  }
  return -1u;
}

unsigned avb_get_sink_stream_index_from_stream_id(unsigned int stream_id[2])
{
  for (unsigned i=0; i<AVB_NUM_SINKS; ++i) {
    if (stream_id[0] == sinks[i].reservation.stream_id[0] &&
        stream_id[1] == sinks[i].reservation.stream_id[1]) {
      return i;
    }
  }
  return -1u;
}

unsigned avb_get_source_stream_index_from_pointer(avb_source_info_t *unsafe p)
{
	for (unsigned i=0; i<AVB_NUM_SOURCES; ++i) {
		if (p == &sources[i]) return i;
	}
	return -1u;
}

unsigned avb_get_sink_stream_index_from_pointer(avb_sink_info_t *unsafe p)
{
	for (unsigned i=0; i<AVB_NUM_SINKS; ++i) {
		if (p == &sinks[i]) return i;
	}
	return -1u;
}

void avb_get_control_packet(chanend c_rx,
                            unsigned int buf[],
                            unsigned int &nbytes,
                            unsigned int &port_num)
{
  safe_mac_rx(c_rx,
              (buf, unsigned char[]),
              nbytes,
              port_num,
              MAX_AVB_CONTROL_PACKET_SIZE);
}

int avb_register_listener_streams(chanend listener_ctl,
                                   int num_streams)
{
  int tile_id;
  int link_id;
  tile_id = get_local_tile_id();
  listener_ctl <: tile_id;
  listener_ctl <: num_streams;
  listener_ctl :> link_id;
  return link_id;
}

void avb_register_talker_streams(chanend talker_ctl,
                                 int num_streams)
{
  int tile_id;
  tile_id = get_local_tile_id();
  talker_ctl <: tile_id;
  talker_ctl <: num_streams;
}
