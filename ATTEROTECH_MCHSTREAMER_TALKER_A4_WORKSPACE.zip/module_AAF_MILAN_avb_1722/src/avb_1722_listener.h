/**
 * \file avb_1722_listener.h
 * \brief IEC 61883-6/AVB1722 Listener definitions
 */

#ifndef _AVB1722_LISTENER_H_
#define _AVB1722_LISTENER_H_ 1
#ifndef __XC__
#define streaming
#endif
#include <xccompat.h>
#include "avb_conf.h"
#include "avb_1722_def.h"
#include "gptp.h"
#include "media_output_fifo.h"
#include "avb_control_types.h"

#ifndef MAX_INCOMING_AVB_STREAMS
#define MAX_INCOMING_AVB_STREAMS (AVB_NUM_SINKS)
#endif

#ifndef AVB_MAX_CHANNELS_PER_LISTENER_STREAM
#define AVB_MAX_CHANNELS_PER_LISTENER_STREAM 8
#endif

#ifndef MAX_AVB_STREAMS_PER_LISTENER
#define MAX_AVB_STREAMS_PER_LISTENER 4
#endif

// Max. packet size for AVB AVB1722 listener
#ifdef AVB_1722_FORMAT_AAF
#define MAX_PKT_BUF_SIZE_LISTENER (AVB_ETHERNET_HDR_SIZE + AVB_TP_HDR_SIZE + TALKER_NUM_AUDIO_SAMPLES_PER_CHANNEL_PER_AVB1722_PKT * AVB_MAX_CHANNELS_PER_LISTENER_STREAM * 4 + 4)
#endif

#ifdef AVB_1722_FORMAT_61883_4
#define MAX_PKT_BUF_SIZE_LISTENER (AVB_ETHERNET_HDR_SIZE + AVB_TP_HDR_SIZE + AVB_CIP_HDR_SIZE + 192*MAX_TS_PACKETS_PER_1722 + 4)
#endif

#ifdef AVB_1722_FORMAT_61883_6
#define MAX_PKT_BUF_SIZE_LISTENER (AVB_ETHERNET_HDR_SIZE + AVB_TP_HDR_SIZE + AVB_CIP_HDR_SIZE + TALKER_NUM_AUDIO_SAMPLES_PER_CHANNEL_PER_AVB1722_PKT * AVB_MAX_CHANNELS_PER_LISTENER_STREAM * 4 + 4)
#endif

typedef struct avb_1722_stream_info_t {
  short active;                    //!< 1-bit flag to say if the stream is active
  short state;                     //!< Generic state info
  int chan_lock;                   //!< Counter for locking onto a data stream
  int rate;                        //!< The estimated rate of the audio traffic
  int prev_num_samples;            //!< Number of samples in last received 1722 packet
  int num_channels_in_payload;     //!< The number of channels in the 1722 payloads
  int num_channels;
  int format;
  int clock_num;
  int dbc;                         //!< The DBC of the last seen packet
  int last_sequence;               //!< The sequence number from the last 1722 packet
  unsigned frames_rx;              //!< Valid AVTP frames accepted by this listener stream
  unsigned seq_num_mismatch;       //!< AVTP sequence discontinuities
  unsigned unsupported_format;     //!< Packets rejected due to unsupported stream format
  unsigned stream_interrupted;     //!< Reserved for stream interruption telemetry
  unsigned timestamp_uncertain;    //!< Reserved for timestamp uncertainty telemetry
  unsigned media_locked;           //!< Count of media-lock acquisitions
  unsigned media_unlocked;         //!< Reserved for media-unlock telemetry
  unsigned media_reset;            //!< Reserved for media-reset telemetry
  unsigned media_locked_latched;   //!< Internal latch to count first valid packet as lock
  media_output_fifo_t map[AVB_MAX_CHANNELS_PER_LISTENER_STREAM];
} avb_1722_stream_info_t;

typedef struct avb_1722_listener_counters_t {
  unsigned frames_rx;
  unsigned seq_num_mismatch;
  unsigned unsupported_format;
  unsigned stream_interrupted;
  unsigned timestamp_uncertain;
  unsigned media_locked;
  unsigned media_unlocked;
  unsigned media_reset;
} avb_1722_listener_counters_t;


#ifdef __XC__
int avb_1722_listener_process_packet(chanend? buf_ctl,
                                     chanend c_crf_rx,
                                     unsigned char Buf[],
                                     int numBytes,
                                     REFERENCE_PARAM(avb_1722_stream_info_t, stream_info),
                                     NULLABLE_REFERENCE_PARAM(ptp_time_info_mod64, timeInfo),
                                     int index,
                                     REFERENCE_PARAM(int, notified_buf_ctl));
#else
int avb_1722_listener_process_packet(chanend buf_ctl,
                                     chanend c_crf_rx,
                                     unsigned char Buf[],
                                     int numBytes,
                                     REFERENCE_PARAM(avb_1722_stream_info_t, stream_info),
				                             REFERENCE_PARAM(ptp_time_info_mod64, timeInfo),
                                     int index,
                                     REFERENCE_PARAM(int, notified_buf_ctl));
#endif

typedef struct avb_1722_listener_state_s {
  avb_1722_stream_info_t listener_streams[MAX_AVB_STREAMS_PER_LISTENER];
  int notified_buf_ctl;
  int router_link;
} avb_1722_listener_state_t;


#endif
