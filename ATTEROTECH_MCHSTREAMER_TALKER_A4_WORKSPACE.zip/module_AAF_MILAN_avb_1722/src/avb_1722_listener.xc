/**
 * \file avb_1722_listener.xc
 * \brief AVB1722 Listener
 */

#include <platform.h>
#include <xs1.h>
#include <xclib.h>

#include "avb_1722_def.h"
#include "avb_1722.h"
#include "avb_1722_listener.h"
#include "media_fifo.h"
#include "ethernet_server_def.h"
#include "ethernet_tx_client.h"
#include "ethernet_rx_client.h"

#include "avb_srp.h"
#include "avb_unit.h"
#include "mac_filter.h"
#include "avb_conf.h"
 #include <debug_print.h>

#define TIMEINFO_UPDATE_INTERVAL 50000000

static transaction configure_stream(chanend c,
                             avb_1722_stream_info_t &s)
{
	int media_clock;

	c :> media_clock;
	c :> s.format;
	c :> s.rate;
	s.clock_num = media_clock;
	c :> s.num_channels;

	for(int i=0;i<s.num_channels;i++) {
		c :> s.map[i];
		if (s.map[i])
		{
			enable_media_output_fifo(s.map[i], media_clock);
		}
	}

	s.active = 1;
	s.state = 0;
	s.num_channels_in_payload = 0;
	s.chan_lock = 0;
	s.prev_num_samples = 0;
	s.dbc = -1;
	s.last_sequence = -1;
	s.frames_rx = 0;
	s.seq_num_mismatch = 0;
	s.unsupported_format = 0;
	s.stream_interrupted = 0;
	s.timestamp_uncertain = 0;
	s.media_locked = 0;
	s.media_unlocked = 0;
	s.media_reset = 0;
	s.media_locked_latched = 0;
}

static transaction adjust_stream(chanend c,
        avb_1722_stream_info_t &s)
{
	int cmd;
	c :> cmd;
	switch (cmd) {
	case AVB1722_ADJUST_LISTENER_VOLUME:
		{
#ifdef MEDIA_OUTPUT_FIFO_VOLUME_CONTROL
			int volume, count;
			c :> count;
			for(int i=0;i<count;i++) {
				c :> volume;
				if (i < s.num_channels) media_output_fifo_set_volume(s.map[i], volume);
			}
#endif
		}
		break;
	}
}


static void disable_stream(avb_1722_stream_info_t &s)
{
	for(int i=0;i<s.num_channels;i++) {
		if (s.map[i])
		{
			disable_media_output_fifo(s.map[i]);
		}
	}

	s.active = 0;
	s.state = 0;
}

void avb_1722_listener_init(chanend c_mac_rx,
                            chanend c_listener_ctl,
                            avb_1722_listener_state_t &st,
                            int num_streams)
{
  // register how many streams this listener unit has
  st.router_link = avb_register_listener_streams(c_listener_ctl, num_streams);

  st.notified_buf_ctl = 0;

  for (int i=0;i<MAX_AVB_STREAMS_PER_LISTENER;i++) {
    st.listener_streams[i].active = 0;
    st.listener_streams[i].state = 0;
    st.listener_streams[i].chan_lock = 0;
    st.listener_streams[i].rate = 0;
    st.listener_streams[i].prev_num_samples = 0;
    st.listener_streams[i].num_channels_in_payload = 0;
    st.listener_streams[i].num_channels = 0;
    st.listener_streams[i].format = 0;
    st.listener_streams[i].clock_num = 0;
    st.listener_streams[i].dbc = -1;
    st.listener_streams[i].last_sequence = -1;
    st.listener_streams[i].frames_rx = 0;
    st.listener_streams[i].seq_num_mismatch = 0;
    st.listener_streams[i].unsupported_format = 0;
    st.listener_streams[i].stream_interrupted = 0;
    st.listener_streams[i].timestamp_uncertain = 0;
    st.listener_streams[i].media_locked = 0;
    st.listener_streams[i].media_unlocked = 0;
    st.listener_streams[i].media_reset = 0;
    st.listener_streams[i].media_locked_latched = 0;
  }

  // initialisation
  mac_set_queue_size(c_mac_rx, num_streams+2);
  mac_set_custom_filter(c_mac_rx, ROUTER_LINK(st.router_link));
}


#pragma select handler
void avb_1722_listener_handle_packet(chanend c_mac_rx,
                                     chanend ?c_buf_ctl,
                                     chanend c_crf_rx,
                                     avb_1722_listener_state_t &st,
                                     ptp_time_info_mod64 &?timeInfo)
{
  unsigned pktByteCnt;
  unsigned int RxBuf[(MAX_PKT_BUF_SIZE_LISTENER+3)/4];
  unsigned int src_port;
  int stream_id;

  mac_rx_offset2(c_mac_rx,
                 (RxBuf, unsigned char[]),
                 pktByteCnt,
                 stream_id,
                 src_port);
  pktByteCnt -= 4;

  // process the audio packet if enabled.
  if (stream_id < MAX_AVB_STREAMS_PER_LISTENER &&
      st.listener_streams[stream_id].active) {
    // process the current packet
    avb_1722_listener_process_packet(c_buf_ctl,
                                     c_crf_rx,
                                     (RxBuf, unsigned char[]),
                                     pktByteCnt,
                                     st.listener_streams[stream_id],
                                     timeInfo,
                                     stream_id,
                                     st.notified_buf_ctl);
  }
}

void avb_1722_push_crf_event(chanend c_crf_rx, int clock_num, unsigned rate,
                             unsigned interval, unsigned hi, unsigned lo)
{
  /* The media-clock server receives these as an ordinary five-word channel
   * message.  Do not wrap this in a master transaction: without a matching
   * slave transaction at the receiver, the listener can deadlock as soon as
   * the first CRF packet reaches Input 1. */
  c_crf_rx <: clock_num;
  c_crf_rx <: rate;
  c_crf_rx <: interval;
  c_crf_rx <: hi;
  c_crf_rx <: lo;
}


#pragma select handler
void avb_1722_listener_handle_cmd(chanend c_listener_ctl,
                                  avb_1722_listener_state_t &st)
{
  int cmd;
  slave {
    c_listener_ctl :> cmd;
    switch (cmd)
      {
      case AVB1722_CONFIGURE_LISTENER_STREAM:
        {
          int stream_num;
          c_listener_ctl :> stream_num;
          configure_stream(c_listener_ctl,
                           st.listener_streams[stream_num]);
          break;
        }
      case AVB1722_ADJUST_LISTENER_STREAM:
        {
          int stream_num;
          c_listener_ctl :> stream_num;
          adjust_stream(c_listener_ctl,
                        st.listener_streams[stream_num]);
          break;
        }
      case AVB1722_DISABLE_LISTENER_STREAM:
        {
          int stream_num;
          c_listener_ctl :> stream_num;
          disable_stream(st.listener_streams[stream_num]);
          break;
        }
      case AVB1722_GET_ROUTER_LINK:
        c_listener_ctl <: st.router_link;
        break;
      case AVB1722_GET_LISTENER_STREAM_COUNTERS:
        {
          int stream_num;
          c_listener_ctl :> stream_num;
          if (stream_num < MAX_AVB_STREAMS_PER_LISTENER) {
            c_listener_ctl <: st.listener_streams[stream_num].frames_rx;
            c_listener_ctl <: st.listener_streams[stream_num].seq_num_mismatch;
            c_listener_ctl <: st.listener_streams[stream_num].unsupported_format;
            c_listener_ctl <: st.listener_streams[stream_num].stream_interrupted;
            c_listener_ctl <: st.listener_streams[stream_num].timestamp_uncertain;
            c_listener_ctl <: st.listener_streams[stream_num].media_locked;
            c_listener_ctl <: st.listener_streams[stream_num].media_unlocked;
            c_listener_ctl <: st.listener_streams[stream_num].media_reset;
          } else {
            for (int i = 0; i < 8; i++) c_listener_ctl <: 0;
          }
          break;
        }
      default:
        break;
      }
    }
}


#pragma unsafe arrays
void avb_1722_listener(chanend c_mac_rx,
                       chanend? c_buf_ctl,
                       chanend? c_ptp,
                       chanend c_listener_ctl,
                       int num_streams,
                       chanend c_crf_rx)
{
  avb_1722_listener_state_t st;
  timer tmr;

#if AVB_1722_FORMAT_61883_4
  unsigned t;
  int pending_timeinfo = 0;
  ptp_time_info_mod64 timeInfo;
#endif
  set_thread_fast_mode_on();
  avb_1722_listener_init(c_mac_rx, c_listener_ctl, st, num_streams);

#if AVB_1722_FORMAT_61883_4
  ptp_request_time_info_mod64(c_ptp);
  ptp_get_requested_time_info_mod64(c_ptp, timeInfo);
  tmr	:> t;
  t+=TIMEINFO_UPDATE_INTERVAL;
#endif

  // main loop.
  while (1) {

#pragma ordered
    select
      {
#if !AVB_1722_FORMAT_61883_4
      case !isnull(c_buf_ctl) => c_buf_ctl :> int stream_num:
          media_output_fifo_handle_buf_ctl(c_buf_ctl, stream_num, st.notified_buf_ctl, tmr);
        break;
#endif

#if AVB_1722_FORMAT_61883_4
        // The PTP server has sent new time information
      case !isnull(c_ptp) => ptp_get_requested_time_info_mod64(c_ptp, timeInfo):
        pending_timeinfo = 0;
        break;
#endif

        case avb_1722_listener_handle_packet(c_mac_rx,
                                           c_buf_ctl,
                                           c_crf_rx,
                                           st,
                                           #ifdef AVB_1722_FORMAT_61883_4
                                           timeInfo
                                           #else
                                           null
                                           #endif
                                           ):
        break;


#if AVB_1722_FORMAT_61883_4
        // Periodically ask the PTP server for new time information
      case !isnull(c_ptp) => tmr when timerafter(t) :> t:
        if (!pending_timeinfo) {
          ptp_request_time_info_mod64(c_ptp);
          pending_timeinfo = 1;
        }
        t+=TIMEINFO_UPDATE_INTERVAL;
        break;
#endif

      case avb_1722_listener_handle_cmd(c_listener_ctl, st):
        break;
      }
  }
}
