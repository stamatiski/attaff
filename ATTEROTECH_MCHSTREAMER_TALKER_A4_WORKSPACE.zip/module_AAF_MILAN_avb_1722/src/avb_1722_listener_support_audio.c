/**
 * \file avb_1722_listener_support.c
 * \brief IEC 61883-6/AVB1722 Listener support C functions
 */
#define streaming
#include "avb_1722_listener.h"
#include "avb_1722_common.h"
#include "gptp.h"
#include "avb_1722_def.h"
#include "media_output_fifo.h"
#include <string.h>
#include <xs1.h>
 #include <xscope.h>
#include "avb_conf.h"
#include "debug_print.h"

#if (AVB_1722_FORMAT_AAF || AVB_1722_FORMAT_61883_6)

void avb_1722_push_crf_event(chanend c_crf_rx, int clock_num, unsigned rate,
                             unsigned interval, unsigned hi, unsigned lo);

/* Represent five hundred 2 ms CRF packets with one timing observation. */
#define CRF_CONTROL_DECIMATION 500
static unsigned int crf_control_count[AVB_NUM_SINKS];

#if AVB_1722_RECORD_ERRORS
static unsigned char prev_seq_num = 0;
#endif

int avb_1722_listener_process_packet(chanend buf_ctl,
                                     chanend c_crf_rx,
                                     unsigned char Buf0[],
                                     int numBytes,
                                     avb_1722_stream_info_t *stream_info,
                                     ptp_time_info_mod64* timeInfo,
                                     int index,
                                     int *notified_buf_ctl)
{
  int pktDataLength, dbc_value;
  AVB_DataHeader_t *pAVBHdr;
  AVB_AVB1722_CIP_Header_t *pAVB1722Hdr;
  unsigned char *Buf = &Buf0[2];
  int avb_ethernet_hdr_size = (Buf[12]==0x81) ? 18 : 14;
  int num_samples_in_payload, num_channels_in_payload;
  pAVBHdr = (AVB_DataHeader_t *) &(Buf[avb_ethernet_hdr_size]);
  pAVB1722Hdr = (AVB_AVB1722_CIP_Header_t *) &(Buf[avb_ethernet_hdr_size + AVB_TP_HDR_SIZE]);
  unsigned char *sample_ptr;
  int i;
  int num_channels = stream_info->num_channels;
  media_output_fifo_t *map = &stream_info->map[0];
  int stride;
#if !AVB_1722_FORMAT_AAF
  int dbc_diff;
#endif

  if (stream_info->format == AVB_SOURCE_FORMAT_CRF)
  {
    AVB_CRF_Header_t *crf = (AVB_CRF_Header_t *)&Buf[avb_ethernet_hdr_size];
    unsigned rate, interval, hi, lo;
    if (numBytes < avb_ethernet_hdr_size + AVB_CRF_HDR_SIZE + 8 ||
        crf->subtype != AVBTP_SUBTYPE_CRF || AVBTP_CRF_SV(crf) != 1 ||
        crf->type != AVBTP_CRF_TYPE_AUDIO_SAMPLE || AVBTP_CRF_PULL(crf) != 0 ||
        AVBTP_CRF_DATA_LENGTH(crf) != 8) {
      stream_info->unsupported_format++;
      return 0;
    }
    rate = AVBTP_CRF_BASE_FREQUENCY(crf);
    interval = AVBTP_CRF_TIMESTAMP_INTERVAL(crf);
    if (!(rate == 48000 && interval == 96)) {
      stream_info->unsupported_format++;
      return 0;
    }
    if (stream_info->last_sequence >= 0 &&
        (unsigned char)(crf->sequence_number - (unsigned char)stream_info->last_sequence) != 1) {
      stream_info->seq_num_mismatch++;
    }
    stream_info->last_sequence = crf->sequence_number;
    hi = ntoh_32(&Buf[avb_ethernet_hdr_size + AVB_CRF_HDR_SIZE]);
    lo = ntoh_32(&Buf[avb_ethernet_hdr_size + AVB_CRF_HDR_SIZE + 4]);
    if (++crf_control_count[index] >= CRF_CONTROL_DECIMATION) {
      crf_control_count[index] = 0;
      avb_1722_push_crf_event(c_crf_rx, stream_info->clock_num,
                              rate, interval * CRF_CONTROL_DECIMATION, hi, lo);
    }
    stream_info->rate = rate;
    stream_info->frames_rx++;
    if (!stream_info->media_locked_latched) {
      stream_info->media_locked++;
      stream_info->media_locked_latched = 1;
    }
    return 1;
  }

  // sanity check on number bytes in payload
#if AVB_1722_FORMAT_AAF
  if (numBytes <= avb_ethernet_hdr_size + AVB_TP_HDR_SIZE)
#else
  if (numBytes <= avb_ethernet_hdr_size + AVB_TP_HDR_SIZE + AVB_CIP_HDR_SIZE)
#endif
  {
    return (0);
  }
  if (AVBTP_VERSION(pAVBHdr) != 0)
  {
    return (0);
  }
  if (AVBTP_CD(pAVBHdr) != AVBTP_CD_DATA)
  {
    return (0);
  }
  if (AVBTP_SV(pAVBHdr) == 0)
  {
    return (0);
  }

#if AVB_1722_FORMAT_AAF
  /* AAF describes the stream in every packet, so no DBC-based format
   * estimation is required.  This implementation consumes INT_32 audio and
   * supports the sample rates exposed by the AVB-DG hardware. */
  if (AVBTP_SUBTYPE(pAVBHdr) != AVBTP_SUBTYPE_AAF ||
      AVBTP_AAF_FORMAT(pAVBHdr) != AVBTP_AAF_FORMAT_INT_32 ||
      AVBTP_AAF_BIT_DEPTH_FIELD(pAVBHdr) == 0 ||
      AVBTP_AAF_BIT_DEPTH_FIELD(pAVBHdr) > 32)
  {
    stream_info->unsupported_format++;
    return 0;
  }

  num_channels_in_payload = AVBTP_AAF_CHANNELS(pAVBHdr);
  if (num_channels_in_payload == 0 ||
      num_channels_in_payload > AVB_MAX_CHANNELS_PER_LISTENER_STREAM)
  {
    return 0;
  }

  switch (AVBTP_AAF_NSR(pAVBHdr))
  {
    case AVBTP_AAF_NSR_48000: stream_info->rate = 48000; break;
    default:
      stream_info->unsupported_format++;
      return 0;
  }
  stream_info->num_channels_in_payload = num_channels_in_payload;
  stream_info->chan_lock = 16;
#endif

#if AVB_1722_RECORD_ERRORS
  unsigned char seq_num = AVBTP_SEQUENCE_NUMBER(pAVBHdr);
  if (stream_info->last_sequence >= 0 &&
      (unsigned char)((unsigned char)seq_num - (unsigned char)stream_info->last_sequence) != 1) {
    stream_info->seq_num_mismatch++;
    xscope_char(LISTENER_1722_SEQ_NUM_MISMATCH, seq_num - prev_seq_num);
  }
  stream_info->last_sequence = seq_num;
  prev_seq_num = seq_num;
#endif

#if !AVB_1722_FORMAT_AAF
  dbc_value = (int) pAVB1722Hdr->DBC;
  dbc_diff = dbc_value - stream_info->dbc;
  stream_info->dbc = dbc_value;

  if (dbc_diff < 0)
    dbc_diff += 0x100;
#endif

  pktDataLength = NTOH_U16(pAVBHdr->packet_data_length);
#if AVB_1722_FORMAT_AAF
  num_samples_in_payload = pktDataLength>>2;
  if ((pktDataLength & 3) != 0 ||
      (num_samples_in_payload % stream_info->num_channels_in_payload) != 0) {
    stream_info->unsupported_format++;
    return 0;
  }
#else
  num_samples_in_payload = (pktDataLength-8)>>2;
#endif

  int prev_num_samples = stream_info->prev_num_samples;
  stream_info->prev_num_samples = num_samples_in_payload;

  if (stream_info->chan_lock < 16)
  {
    int num_channels;

#if !AVB_1722_FORMAT_AAF
    if (!prev_num_samples || dbc_diff == 0)
      return 0;
#endif

#if AVB_1722_FORMAT_AAF
    num_channels = AVBTP_PROTOCOL_SPECIFIC(pAVBHdr);
#else
    num_channels = prev_num_samples / dbc_diff;
#endif

    if (!stream_info->num_channels_in_payload ||
        stream_info->num_channels_in_payload != num_channels)
    {
      stream_info->num_channels_in_payload = num_channels;
      stream_info->chan_lock = 0;
      stream_info->rate = 0;
    }

    stream_info->rate += num_samples_in_payload;

    stream_info->chan_lock++;

#if !AVB_1722_FORMAT_AAF
    if (stream_info->chan_lock == 16)
    {
      stream_info->rate = (stream_info->rate / stream_info->num_channels_in_payload / 16);

      switch (stream_info->rate)
      {
      case 1: stream_info->rate = 8000; break;
      case 2: stream_info->rate = 16000; break;
      case 4: stream_info->rate = 32000; break;
      case 5: stream_info->rate = 44100; break;
      case 6: stream_info->rate = 48000; break;
      case 11: stream_info->rate = 88200; break;
      case 12: stream_info->rate = 96000; break;
      default: stream_info->rate = 0; break;
      }
    }
#endif

    return 0;
  }

#if AVB_1722_FORMAT_AAF
  if ((AVBTP_TV(pAVBHdr)==1))
  {
    unsigned sample_num = 0;
#else
  if ((AVBTP_TV(pAVBHdr)==1))
  {
    // See 61883-6 section 6.2 which explains that the receiver can calculate
    // which data block (sample) the timestamp refers to using the formula:
    //   index = (SYT_INTERVAL - dbc % SYT_INTERVAL) % SYT_INTERVAL

    unsigned syt_interval, sample_num;

    switch (stream_info->rate)
    {
    case 8000:   syt_interval = 1; break;
    case 16000:  syt_interval = 2; break;
    case 32000:  syt_interval = 8; break;
    case 44100:  syt_interval = 8; break;
    case 48000:  syt_interval = 8; break;
    case 88200:  syt_interval = 16; break;
    case 96000:  syt_interval = 16; break;
    case 176400: syt_interval = 32; break;
    case 192000: syt_interval = 32; break;
    default: break;
    }
    sample_num = (syt_interval - (dbc_value & (syt_interval-1))) & (syt_interval-1);
#endif
    // register timestamp
    for (int i=0; i<num_channels; i++)
    {
      if (map[i])
      {
        media_output_fifo_set_ptp_timestamp(map[i], AVBTP_TIMESTAMP(pAVBHdr), sample_num);
      }
    }
  }

  for (i=0; i<num_channels; i++)
  {
    if (map[i])
    {
      media_output_fifo_maintain(map[i], buf_ctl, notified_buf_ctl);
    }
  }


  // now send the samples
#if AVB_1722_FORMAT_AAF
  sample_ptr = (unsigned char *) &Buf[(avb_ethernet_hdr_size +
                                       AVB_TP_HDR_SIZE)];
#else
  sample_ptr = (unsigned char *) &Buf[(avb_ethernet_hdr_size +
                                       AVB_TP_HDR_SIZE +
                                       AVB_CIP_HDR_SIZE)];
#endif

  num_channels_in_payload = stream_info->num_channels_in_payload;
  stream_info->frames_rx++;
  if (!stream_info->media_locked_latched) {
    stream_info->media_locked++;
    stream_info->media_locked_latched = 1;
  }

  stride = num_channels_in_payload;

  num_channels =
    num_channels < num_channels_in_payload ?
    num_channels :
    num_channels_in_payload;

  for(i=0; i<num_channels; i++)
  {
    if (map[i])
    {
      media_output_fifo_strided_push(map[i], (unsigned int *) sample_ptr,
                                   stride, num_samples_in_payload,
                                   AVBTP_AAF_BIT_DEPTH_FIELD(pAVBHdr));
    }
    sample_ptr += 4;
  }

  return(1);
}

#endif
