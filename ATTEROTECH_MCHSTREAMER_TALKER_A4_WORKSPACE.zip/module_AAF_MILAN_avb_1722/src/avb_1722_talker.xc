/** \file avb_1722_talker.xc
 *  \brief IEC 61883-6/AVB1722 Audio over 1722 AVB Transport.
 */

#include <platform.h>
#include <xs1.h>
#include <xclib.h>
#include <print.h>
#include <xscope.h>

#include "avb_1722_def.h"
#include "avb_1722.h"
#include "avb_1722_listener.h"
#include "avb_1722_talker.h"
#include "media_fifo.h"
#include "ethernet_server_def.h"
#include "ethernet_tx_client.h"
#include "ethernet_rx_client.h"
#include "avb_srp.h"
#include "avb_unit.h"
#include "avb_conf.h"
#include "debug_print.h"

#if AVB_NUM_SOURCES != 0

static transaction configure_stream(chanend avb1722_tx_config,
               avb1722_Talker_StreamConfig_t &stream,
               unsigned char mac_addr[MAC_ADRS_BYTE_COUNT]) {
  unsigned int streamIdExt;
  unsigned int rate;
  unsigned int tmp;
  int samplesPerPacket;
  avb1722_tx_config :> stream.sampleType;

  for (int i = 0; i < MAC_ADRS_BYTE_COUNT; i++) {
    int x;
    avb1722_tx_config :> x;
    stream.destMACAdrs[i] = x;
    stream.srcMACAdrs[i] = mac_addr[i];
  }

  stream.streamId[1] = ntoh_32(stream.srcMACAdrs);

  stream.streamId[0] =
  ((unsigned) stream.srcMACAdrs[4] << 24) |
  ((unsigned) stream.srcMACAdrs[5] << 16);

  avb1722_tx_config :> streamIdExt;

  stream.streamId[0] |= streamIdExt;

  avb1722_tx_config :> stream.num_channels;

  avb1722_tx_config :> stream.fifo_mask;

  for (int i=0;i<stream.num_channels;i++) {
    avb1722_tx_config :> stream.map[i];
  }

  avb1722_tx_config :> rate;
  stream.rate = rate;

  for (int i=0;i<stream.num_channels;i++) {
    samplesPerPacket = media_input_fifo_enable(stream.map[i], rate);
  }

  avb1722_tx_config :> stream.presentation_delay;
  avb1722_tx_config :> stream.clock_num;

  if (stream.sampleType == AVB_SOURCE_FORMAT_CRF) {
    stream.samples_per_fifo_packet = 0;
    stream.samples_per_packet_base = 0;
    stream.samples_per_packet_fractional = 0;
    stream.rem = 0;
    stream.samples_left_in_fifo_packet = 0;
    stream.initial = 1;
    stream.dbc_at_start_of_last_fifo_packet = 0;
    stream.active = 1;
    stream.transmit_ok = 1;
    stream.sequence_number = 0;
    stream.txport = 0;
    return;
  }

  stream.samples_per_fifo_packet = samplesPerPacket;

  tmp = ((rate / 100) << 16) / (AVB1722_PACKET_RATE / 100);
  stream.samples_per_packet_base = tmp >> 16;
  stream.samples_per_packet_fractional = tmp & 0xffff;
  stream.rem = 0;

  stream.samples_left_in_fifo_packet = 0;
  stream.initial = 1;
  stream.dbc_at_start_of_last_fifo_packet = 0;
  stream.active = 1;
  stream.transmit_ok = 1;
  stream.sequence_number = 0;
#if NUM_ETHERNET_PORTS > 1
  stream.txport = AVB1722_PORT_UNINITIALIZED;
#else
  stream.txport = 0;
#endif
}

static void disable_stream(avb1722_Talker_StreamConfig_t &stream) {
  /* Stop the packetizer before changing the producer request.  The old
   * implementation invalidated each FIFO immediately, while the packetizer
   * could still be traversing it.  That teardown race can trap this core and
   * take AVDECC/ACMP offline after a disconnect. */
  stream.active = 0;
  stream.samples_left_in_fifo_packet = 0;
  stream.initial = 1;
  stream.transmit_ok = 1;
  media_input_fifo_disable_fifos(stream.fifo_mask);
  stream.streamId[1] = 0;
  stream.streamId[0] = 0;
}


static void start_stream(avb1722_Talker_StreamConfig_t &stream) {
  /* Start from the controller's GO command without waiting for every mapped
   * FIFO to acknowledge a synthetic disable/enable generation.  That TX48
   * barrier could never complete on this board even though the producer and
   * local I2S path were alive, leaving STREAM_START=1 but FRAMES_TX=0.
   *
   * Disconnect remains safe because stop_stream() quiesces packetization
   * before withdrawing the producer request. */
  stream.samples_left_in_fifo_packet = 0;
  stream.sequence_number = 0;
  stream.initial = 1;
  stream.transmit_ok = 1;
  media_input_fifo_enable_fifos(stream.fifo_mask);
  stream.active = 2;
}

static void stop_stream(avb1722_Talker_StreamConfig_t &stream) {
  /* Packetization must be quiescent before the I2S producer sees disable. */
  stream.active = 1;
  stream.samples_left_in_fifo_packet = 0;
  stream.initial = 1;
  stream.transmit_ok = 1;
  media_input_fifo_disable_fifos(stream.fifo_mask);
}


void avb_1722_talker_init(chanend c_talker_ctl,
                          chanend c_mac_tx,
                          avb_1722_talker_state_t &st,
                          int num_streams)
 {
  st.vlan = 0;
  st.cur_avb_stream = 0;
  st.max_active_avb_stream = 0;

  for (unsigned n=0; n<(MAX_PKT_BUF_SIZE_TALKER + 3) / 4; ++n)
    st.TxBuf[n] = 0;

  // register how many streams this talker unit has
  avb_register_talker_streams(c_talker_ctl, num_streams);

  // Initialise local data structure.
  mac_get_macaddr(c_mac_tx, st.mac_addr);

  for (int i = 0; i < AVB_MAX_STREAMS_PER_TALKER_UNIT; i++) {
    st.talker_streams[i].active = 0;
    st.talker_streams[i].frames_tx = 0;
    st.talker_streams[i].media_reset = 0;
    st.talker_streams[i].timestamp_uncertain = 0;
  }
}


#pragma select handler
void avb_1722_talker_handle_cmd(chanend c_talker_ctl,
                                avb_1722_talker_state_t &st)
{
  int cmd;
  slave {
    c_talker_ctl :> cmd;
    switch (cmd)
    {
    case AVB1722_CONFIGURE_TALKER_STREAM:
      {
        int stream_num;
        c_talker_ctl :> stream_num;
        configure_stream(c_talker_ctl,
                         st.talker_streams[stream_num],
                         st.mac_addr);
        if (stream_num > st.max_active_avb_stream)
          st.max_active_avb_stream = stream_num;

        // Eventually this will have to be changed
        // to create per-stream headers
        // for now assume sampling rate etc. the same
        // on all streams
        AVB1722_Talker_bufInit((st.TxBuf,unsigned char[]),
                               st.talker_streams[stream_num],
                               st.vlan);

    }
    break;
    case AVB1722_DISABLE_TALKER_STREAM:
    {
      int stream_num;
      c_talker_ctl :> stream_num;
      disable_stream(st.talker_streams[stream_num]);
    }
    break;
    case AVB1722_TALKER_GO:
    {
      int stream_num;
      c_talker_ctl :> stream_num;
      start_stream(st.talker_streams[stream_num]);
    }
    break;
    case AVB1722_TALKER_STOP:
    {
      int stream_num;
      c_talker_ctl :> stream_num;
      stop_stream(st.talker_streams[stream_num]);
    }
    break;
    case AVB1722_SET_PORT:
    {
      int stream_num;
      c_talker_ctl :> stream_num;
      c_talker_ctl :> st.talker_streams[stream_num].txport;
#if NUM_ETHERNET_PORTS > 1
      debug_printf("Setting stream %d 1722 TX port to %d\n", stream_num, st.talker_streams[stream_num].txport);
#endif
      break;
    }
    case AVB1722_SET_VLAN:
      c_talker_ctl :> st.vlan;
      avb1722_set_buffer_vlan(st.vlan,(st.TxBuf,unsigned char[]));
      break;
    case AVB1722_GET_TALKER_STREAM_COUNTERS:
    {
      int stream_num;
      int media_reset = 0;
      int timestamp_uncertain = 0;
      int frames_tx = 0;
      c_talker_ctl :> stream_num;
      if ((stream_num >= 0) &&
          (stream_num < AVB_MAX_STREAMS_PER_TALKER_UNIT)) {
        media_reset = st.talker_streams[stream_num].media_reset;
        timestamp_uncertain =
            st.talker_streams[stream_num].timestamp_uncertain;
        frames_tx = st.talker_streams[stream_num].frames_tx;
      }
      c_talker_ctl <: media_reset;
      c_talker_ctl <: timestamp_uncertain;
      c_talker_ctl <: frames_tx;
      break;
    }
    default:
      break;
    }
  }
}


static void advance_current_stream(avb_1722_talker_state_t &st)
{
  st.cur_avb_stream++;
  if (st.cur_avb_stream > st.max_active_avb_stream)
    st.cur_avb_stream = 0;
}

void avb_1722_talker_send_packets(chanend c_mac_tx,
                                  avb_1722_talker_state_t &st,
                                  ptp_time_info_mod64 &timeInfo,
                                  timer tmr,
                                  chanend c_crf_tx)
{
  if (st.max_active_avb_stream == -1)
      return;

  int active = st.talker_streams[st.cur_avb_stream].active;
  if (active==2) {
    int packet_size;
    int t;

    tmr :> t;
    AVB1722_Talker_bufInit((st.TxBuf,unsigned char[]),
                           st.talker_streams[st.cur_avb_stream], st.vlan);
    if (st.talker_streams[st.cur_avb_stream].sampleType == AVB_SOURCE_FORMAT_CRF) {
      int elapsed = t - st.talker_streams[st.cur_avb_stream].last_transmit_time;
      if (!st.talker_streams[st.cur_avb_stream].initial && elapsed < 200000)
        packet_size = 0;
      else {
        unsigned hi, lo, interval;
        c_crf_tx <: st.talker_streams[st.cur_avb_stream].clock_num;
        c_crf_tx <: st.talker_streams[st.cur_avb_stream].rate;
        c_crf_tx :> hi;
        c_crf_tx :> lo;
        c_crf_tx :> interval;
        packet_size = avb1722_create_crf_packet((st.TxBuf, unsigned char[]),
                            st.talker_streams[st.cur_avb_stream], hi, lo, interval);
        st.talker_streams[st.cur_avb_stream].initial = 0;
      }
    } else {
      packet_size = avb1722_create_packet((st.TxBuf, unsigned char[]),
                            st.talker_streams[st.cur_avb_stream],
                            timeInfo,
                            t);
    }
    if (packet_size) {
      if (packet_size < 60) packet_size = 60;
      ethernet_send_frame_offset2(c_mac_tx,
                                  st.TxBuf,
                                  packet_size,
                                  st.talker_streams[st.cur_avb_stream].txport);
      st.talker_streams[st.cur_avb_stream].last_transmit_time = t;
      st.talker_streams[st.cur_avb_stream].frames_tx++;
#if MCH_I2S_CAPTURE_DIAGNOSTICS
      /* This is deliberately placed after the Ethernet submit call: it is a
       * packetizer/send-path observation, not a synthetic activity counter. */
      /* Keep xSCOPE observational: emit approximately once per second at
       * 48 kHz/6 samples-per-packet, rather than for every AVTP packet. */
      if ((st.talker_streams[st.cur_avb_stream].frames_tx & 0x1fff) == 0) {
        xscope_probe_data(13, st.talker_streams[st.cur_avb_stream].frames_tx);
      }
#endif
    }
    if (packet_size || st.talker_streams[st.cur_avb_stream].initial)
    {
      advance_current_stream(st);
    }
  }
  else
  {
    advance_current_stream(st);
  }
}



#define TIMEINFO_UPDATE_INTERVAL 50000000
/** This packetizes Audio samples into an AVB payload and transmit it across
 *  Ethernet.
 *
 *  1. Get audio samples from ADC fifo.
 *  2. Convert the local timer value to global PTP timestamp.
 *  3. AVB payload generation and transmit to Ethernet.
 */
void avb_1722_talker(chanend c_ptp, chanend c_mac_tx,
                     chanend c_talker_ctl, int num_streams,
                     chanend c_crf_tx) {
  avb_1722_talker_state_t st;
  ptp_time_info_mod64 timeInfo;
  timer tmr;
  unsigned t;
  int pending_timeinfo = 0;

  set_thread_fast_mode_on();
  avb_1722_talker_init(c_talker_ctl, c_mac_tx, st, num_streams);

  ptp_request_time_info_mod64(c_ptp);
  ptp_get_requested_time_info_mod64_use_timer(c_ptp, timeInfo, tmr);

  tmr :> t;
  t+=TIMEINFO_UPDATE_INTERVAL;

  // main loop.
  while (1)
  {
    select
    {
        // Process commands from the AVB control/application thread
      case avb_1722_talker_handle_cmd(c_talker_ctl, st): break;

        // Periodically ask the PTP server for new time information
      case tmr when timerafter(t) :> t:
        if (!pending_timeinfo) {
          ptp_request_time_info_mod64(c_ptp);
          pending_timeinfo = 1;
        }
        t+=TIMEINFO_UPDATE_INTERVAL;
        break;

        // The PTP server has sent new time information
      case ptp_get_requested_time_info_mod64_use_timer(c_ptp, timeInfo, tmr):
        pending_timeinfo = 0;
        break;


        // Call the 1722 packet construction
      default:
        avb_1722_talker_send_packets(c_mac_tx, st, timeInfo, tmr, c_crf_tx);
        break;
    }
  }
}

#endif // AVB_NUM_SOURCES != 0
